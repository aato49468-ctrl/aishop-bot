# Удаление решётки 64x64x64. Встаньте туда же, где строили.
kill @e[type=marker,tag=lat_small_rm]
forceload add ~-34 ~-34 ~34 ~34
summon marker ~ ~ ~ {Tags:["lat_small_rm"]}
schedule function pyramid:lattice_remove_small_go 40t
