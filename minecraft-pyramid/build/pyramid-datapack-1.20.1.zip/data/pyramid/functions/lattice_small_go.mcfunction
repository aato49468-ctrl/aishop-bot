execute as @e[type=marker,tag=lat_small,limit=1] at @s run function pyramid:lattice_small_build
execute as @e[type=marker,tag=lat_small,limit=1] at @s run forceload remove ~-34 ~-34 ~34 ~34
kill @e[type=marker,tag=lat_small]
tellraw @a {"text":"Готово! Свет может догружаться несколько секунд.","color":"green"}
