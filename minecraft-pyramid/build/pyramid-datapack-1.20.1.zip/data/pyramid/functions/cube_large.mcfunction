# Куб 61x61x62 (с полом и потолком). Центр пола — там, где стоит игрок.
tellraw @s {"text":"Строю куб...","color":"gold"}
fill ~-29 ~0 ~-29 ~29 ~0 ~29 minecraft:air
fill ~-29 ~1 ~-29 ~29 ~1 ~29 minecraft:air
fill ~-29 ~2 ~-29 ~29 ~2 ~29 minecraft:air
fill ~-29 ~3 ~-29 ~29 ~3 ~29 minecraft:air
fill ~-29 ~4 ~-29 ~29 ~4 ~29 minecraft:air
fill ~-29 ~5 ~-29 ~29 ~5 ~29 minecraft:air
fill ~-29 ~6 ~-29 ~29 ~6 ~29 minecraft:air
fill ~-29 ~7 ~-29 ~29 ~7 ~29 minecraft:air
fill ~-29 ~8 ~-29 ~29 ~8 ~29 minecraft:air
fill ~-29 ~9 ~-29 ~29 ~9 ~29 minecraft:air
fill ~-29 ~10 ~-29 ~29 ~10 ~29 minecraft:air
fill ~-29 ~11 ~-29 ~29 ~11 ~29 minecraft:air
fill ~-29 ~12 ~-29 ~29 ~12 ~29 minecraft:air
fill ~-29 ~13 ~-29 ~29 ~13 ~29 minecraft:air
fill ~-29 ~14 ~-29 ~29 ~14 ~29 minecraft:air
fill ~-29 ~15 ~-29 ~29 ~15 ~29 minecraft:air
fill ~-29 ~16 ~-29 ~29 ~16 ~29 minecraft:air
fill ~-29 ~17 ~-29 ~29 ~17 ~29 minecraft:air
fill ~-29 ~18 ~-29 ~29 ~18 ~29 minecraft:air
fill ~-29 ~19 ~-29 ~29 ~19 ~29 minecraft:air
fill ~-29 ~20 ~-29 ~29 ~20 ~29 minecraft:air
fill ~-29 ~21 ~-29 ~29 ~21 ~29 minecraft:air
fill ~-29 ~22 ~-29 ~29 ~22 ~29 minecraft:air
fill ~-29 ~23 ~-29 ~29 ~23 ~29 minecraft:air
fill ~-29 ~24 ~-29 ~29 ~24 ~29 minecraft:air
fill ~-29 ~25 ~-29 ~29 ~25 ~29 minecraft:air
fill ~-29 ~26 ~-29 ~29 ~26 ~29 minecraft:air
fill ~-29 ~27 ~-29 ~29 ~27 ~29 minecraft:air
fill ~-29 ~28 ~-29 ~29 ~28 ~29 minecraft:air
fill ~-29 ~29 ~-29 ~29 ~29 ~29 minecraft:air
fill ~-29 ~30 ~-29 ~29 ~30 ~29 minecraft:air
fill ~-29 ~31 ~-29 ~29 ~31 ~29 minecraft:air
fill ~-29 ~32 ~-29 ~29 ~32 ~29 minecraft:air
fill ~-29 ~33 ~-29 ~29 ~33 ~29 minecraft:air
fill ~-29 ~34 ~-29 ~29 ~34 ~29 minecraft:air
fill ~-29 ~35 ~-29 ~29 ~35 ~29 minecraft:air
fill ~-29 ~36 ~-29 ~29 ~36 ~29 minecraft:air
fill ~-29 ~37 ~-29 ~29 ~37 ~29 minecraft:air
fill ~-29 ~38 ~-29 ~29 ~38 ~29 minecraft:air
fill ~-29 ~39 ~-29 ~29 ~39 ~29 minecraft:air
fill ~-29 ~40 ~-29 ~29 ~40 ~29 minecraft:air
fill ~-29 ~41 ~-29 ~29 ~41 ~29 minecraft:air
fill ~-29 ~42 ~-29 ~29 ~42 ~29 minecraft:air
fill ~-29 ~43 ~-29 ~29 ~43 ~29 minecraft:air
fill ~-29 ~44 ~-29 ~29 ~44 ~29 minecraft:air
fill ~-29 ~45 ~-29 ~29 ~45 ~29 minecraft:air
fill ~-29 ~46 ~-29 ~29 ~46 ~29 minecraft:air
fill ~-29 ~47 ~-29 ~29 ~47 ~29 minecraft:air
fill ~-29 ~48 ~-29 ~29 ~48 ~29 minecraft:air
fill ~-29 ~49 ~-29 ~29 ~49 ~29 minecraft:air
fill ~-29 ~50 ~-29 ~29 ~50 ~29 minecraft:air
fill ~-29 ~51 ~-29 ~29 ~51 ~29 minecraft:air
fill ~-29 ~52 ~-29 ~29 ~52 ~29 minecraft:air
fill ~-29 ~53 ~-29 ~29 ~53 ~29 minecraft:air
fill ~-29 ~54 ~-29 ~29 ~54 ~29 minecraft:air
fill ~-29 ~55 ~-29 ~29 ~55 ~29 minecraft:air
fill ~-29 ~56 ~-29 ~29 ~56 ~29 minecraft:air
fill ~-29 ~57 ~-29 ~29 ~57 ~29 minecraft:air
fill ~-29 ~58 ~-29 ~29 ~58 ~29 minecraft:air
fill ~-29 ~59 ~-29 ~29 ~59 ~29 minecraft:air
fill ~-30 ~-1 ~-30 ~30 ~-1 ~30 minecraft:black_concrete
fill ~-30 ~60 ~-30 ~30 ~60 ~30 minecraft:glass
fill ~-30 ~0 ~-30 ~30 ~59 ~-30 minecraft:glass
fill ~-30 ~0 ~30 ~30 ~59 ~30 minecraft:glass
fill ~-30 ~0 ~-30 ~-30 ~59 ~30 minecraft:glass
fill ~30 ~0 ~-30 ~30 ~59 ~30 minecraft:glass
setblock ~-29 ~0 ~-29 minecraft:lantern
setblock ~-29 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-29 minecraft:lantern
setblock ~29 ~0 ~-29 minecraft:lantern
setblock ~-27 ~0 ~-29 minecraft:lantern
setblock ~-27 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-27 minecraft:lantern
setblock ~29 ~0 ~-27 minecraft:lantern
setblock ~-25 ~0 ~-29 minecraft:lantern
setblock ~-25 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-25 minecraft:lantern
setblock ~29 ~0 ~-25 minecraft:lantern
setblock ~-23 ~0 ~-29 minecraft:lantern
setblock ~-23 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-23 minecraft:lantern
setblock ~29 ~0 ~-23 minecraft:lantern
setblock ~-21 ~0 ~-29 minecraft:lantern
setblock ~-21 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-21 minecraft:lantern
setblock ~29 ~0 ~-21 minecraft:lantern
setblock ~-19 ~0 ~-29 minecraft:lantern
setblock ~-19 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-19 minecraft:lantern
setblock ~29 ~0 ~-19 minecraft:lantern
setblock ~-17 ~0 ~-29 minecraft:lantern
setblock ~-17 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-17 minecraft:lantern
setblock ~29 ~0 ~-17 minecraft:lantern
setblock ~-15 ~0 ~-29 minecraft:lantern
setblock ~-15 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-15 minecraft:lantern
setblock ~29 ~0 ~-15 minecraft:lantern
setblock ~-13 ~0 ~-29 minecraft:lantern
setblock ~-13 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-13 minecraft:lantern
setblock ~29 ~0 ~-13 minecraft:lantern
setblock ~-11 ~0 ~-29 minecraft:lantern
setblock ~-11 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-11 minecraft:lantern
setblock ~29 ~0 ~-11 minecraft:lantern
setblock ~-9 ~0 ~-29 minecraft:lantern
setblock ~-9 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-9 minecraft:lantern
setblock ~29 ~0 ~-9 minecraft:lantern
setblock ~-7 ~0 ~-29 minecraft:lantern
setblock ~-7 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-7 minecraft:lantern
setblock ~29 ~0 ~-7 minecraft:lantern
setblock ~-5 ~0 ~-29 minecraft:lantern
setblock ~-5 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-5 minecraft:lantern
setblock ~29 ~0 ~-5 minecraft:lantern
setblock ~-3 ~0 ~-29 minecraft:lantern
setblock ~-3 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-3 minecraft:lantern
setblock ~29 ~0 ~-3 minecraft:lantern
setblock ~-1 ~0 ~-29 minecraft:lantern
setblock ~-1 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~-1 minecraft:lantern
setblock ~29 ~0 ~-1 minecraft:lantern
setblock ~1 ~0 ~-29 minecraft:lantern
setblock ~1 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~1 minecraft:lantern
setblock ~29 ~0 ~1 minecraft:lantern
setblock ~3 ~0 ~-29 minecraft:lantern
setblock ~3 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~3 minecraft:lantern
setblock ~29 ~0 ~3 minecraft:lantern
setblock ~5 ~0 ~-29 minecraft:lantern
setblock ~5 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~5 minecraft:lantern
setblock ~29 ~0 ~5 minecraft:lantern
setblock ~7 ~0 ~-29 minecraft:lantern
setblock ~7 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~7 minecraft:lantern
setblock ~29 ~0 ~7 minecraft:lantern
setblock ~9 ~0 ~-29 minecraft:lantern
setblock ~9 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~9 minecraft:lantern
setblock ~29 ~0 ~9 minecraft:lantern
setblock ~11 ~0 ~-29 minecraft:lantern
setblock ~11 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~11 minecraft:lantern
setblock ~29 ~0 ~11 minecraft:lantern
setblock ~13 ~0 ~-29 minecraft:lantern
setblock ~13 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~13 minecraft:lantern
setblock ~29 ~0 ~13 minecraft:lantern
setblock ~15 ~0 ~-29 minecraft:lantern
setblock ~15 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~15 minecraft:lantern
setblock ~29 ~0 ~15 minecraft:lantern
setblock ~17 ~0 ~-29 minecraft:lantern
setblock ~17 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~17 minecraft:lantern
setblock ~29 ~0 ~17 minecraft:lantern
setblock ~19 ~0 ~-29 minecraft:lantern
setblock ~19 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~19 minecraft:lantern
setblock ~29 ~0 ~19 minecraft:lantern
setblock ~21 ~0 ~-29 minecraft:lantern
setblock ~21 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~21 minecraft:lantern
setblock ~29 ~0 ~21 minecraft:lantern
setblock ~23 ~0 ~-29 minecraft:lantern
setblock ~23 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~23 minecraft:lantern
setblock ~29 ~0 ~23 minecraft:lantern
setblock ~25 ~0 ~-29 minecraft:lantern
setblock ~25 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~25 minecraft:lantern
setblock ~29 ~0 ~25 minecraft:lantern
setblock ~27 ~0 ~-29 minecraft:lantern
setblock ~27 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~27 minecraft:lantern
setblock ~29 ~0 ~27 minecraft:lantern
setblock ~29 ~0 ~-29 minecraft:lantern
setblock ~29 ~0 ~29 minecraft:lantern
setblock ~-29 ~0 ~29 minecraft:lantern
setblock ~29 ~0 ~29 minecraft:lantern
setblock ~-31 ~-1 ~-31 minecraft:black_concrete
setblock ~-31 ~0 ~-31 minecraft:lantern
setblock ~-31 ~-1 ~31 minecraft:black_concrete
setblock ~-31 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-31 minecraft:black_concrete
setblock ~-31 ~0 ~-31 minecraft:lantern
setblock ~31 ~-1 ~-31 minecraft:black_concrete
setblock ~31 ~0 ~-31 minecraft:lantern
setblock ~-29 ~-1 ~-31 minecraft:black_concrete
setblock ~-29 ~0 ~-31 minecraft:lantern
setblock ~-29 ~-1 ~31 minecraft:black_concrete
setblock ~-29 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-29 minecraft:black_concrete
setblock ~-31 ~0 ~-29 minecraft:lantern
setblock ~31 ~-1 ~-29 minecraft:black_concrete
setblock ~31 ~0 ~-29 minecraft:lantern
setblock ~-27 ~-1 ~-31 minecraft:black_concrete
setblock ~-27 ~0 ~-31 minecraft:lantern
setblock ~-27 ~-1 ~31 minecraft:black_concrete
setblock ~-27 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-27 minecraft:black_concrete
setblock ~-31 ~0 ~-27 minecraft:lantern
setblock ~31 ~-1 ~-27 minecraft:black_concrete
setblock ~31 ~0 ~-27 minecraft:lantern
setblock ~-25 ~-1 ~-31 minecraft:black_concrete
setblock ~-25 ~0 ~-31 minecraft:lantern
setblock ~-25 ~-1 ~31 minecraft:black_concrete
setblock ~-25 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-25 minecraft:black_concrete
setblock ~-31 ~0 ~-25 minecraft:lantern
setblock ~31 ~-1 ~-25 minecraft:black_concrete
setblock ~31 ~0 ~-25 minecraft:lantern
setblock ~-23 ~-1 ~-31 minecraft:black_concrete
setblock ~-23 ~0 ~-31 minecraft:lantern
setblock ~-23 ~-1 ~31 minecraft:black_concrete
setblock ~-23 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-23 minecraft:black_concrete
setblock ~-31 ~0 ~-23 minecraft:lantern
setblock ~31 ~-1 ~-23 minecraft:black_concrete
setblock ~31 ~0 ~-23 minecraft:lantern
setblock ~-21 ~-1 ~-31 minecraft:black_concrete
setblock ~-21 ~0 ~-31 minecraft:lantern
setblock ~-21 ~-1 ~31 minecraft:black_concrete
setblock ~-21 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-21 minecraft:black_concrete
setblock ~-31 ~0 ~-21 minecraft:lantern
setblock ~31 ~-1 ~-21 minecraft:black_concrete
setblock ~31 ~0 ~-21 minecraft:lantern
setblock ~-19 ~-1 ~-31 minecraft:black_concrete
setblock ~-19 ~0 ~-31 minecraft:lantern
setblock ~-19 ~-1 ~31 minecraft:black_concrete
setblock ~-19 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-19 minecraft:black_concrete
setblock ~-31 ~0 ~-19 minecraft:lantern
setblock ~31 ~-1 ~-19 minecraft:black_concrete
setblock ~31 ~0 ~-19 minecraft:lantern
setblock ~-17 ~-1 ~-31 minecraft:black_concrete
setblock ~-17 ~0 ~-31 minecraft:lantern
setblock ~-17 ~-1 ~31 minecraft:black_concrete
setblock ~-17 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-17 minecraft:black_concrete
setblock ~-31 ~0 ~-17 minecraft:lantern
setblock ~31 ~-1 ~-17 minecraft:black_concrete
setblock ~31 ~0 ~-17 minecraft:lantern
setblock ~-15 ~-1 ~-31 minecraft:black_concrete
setblock ~-15 ~0 ~-31 minecraft:lantern
setblock ~-15 ~-1 ~31 minecraft:black_concrete
setblock ~-15 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-15 minecraft:black_concrete
setblock ~-31 ~0 ~-15 minecraft:lantern
setblock ~31 ~-1 ~-15 minecraft:black_concrete
setblock ~31 ~0 ~-15 minecraft:lantern
setblock ~-13 ~-1 ~-31 minecraft:black_concrete
setblock ~-13 ~0 ~-31 minecraft:lantern
setblock ~-13 ~-1 ~31 minecraft:black_concrete
setblock ~-13 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-13 minecraft:black_concrete
setblock ~-31 ~0 ~-13 minecraft:lantern
setblock ~31 ~-1 ~-13 minecraft:black_concrete
setblock ~31 ~0 ~-13 minecraft:lantern
setblock ~-11 ~-1 ~-31 minecraft:black_concrete
setblock ~-11 ~0 ~-31 minecraft:lantern
setblock ~-11 ~-1 ~31 minecraft:black_concrete
setblock ~-11 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-11 minecraft:black_concrete
setblock ~-31 ~0 ~-11 minecraft:lantern
setblock ~31 ~-1 ~-11 minecraft:black_concrete
setblock ~31 ~0 ~-11 minecraft:lantern
setblock ~-9 ~-1 ~-31 minecraft:black_concrete
setblock ~-9 ~0 ~-31 minecraft:lantern
setblock ~-9 ~-1 ~31 minecraft:black_concrete
setblock ~-9 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-9 minecraft:black_concrete
setblock ~-31 ~0 ~-9 minecraft:lantern
setblock ~31 ~-1 ~-9 minecraft:black_concrete
setblock ~31 ~0 ~-9 minecraft:lantern
setblock ~-7 ~-1 ~-31 minecraft:black_concrete
setblock ~-7 ~0 ~-31 minecraft:lantern
setblock ~-7 ~-1 ~31 minecraft:black_concrete
setblock ~-7 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-7 minecraft:black_concrete
setblock ~-31 ~0 ~-7 minecraft:lantern
setblock ~31 ~-1 ~-7 minecraft:black_concrete
setblock ~31 ~0 ~-7 minecraft:lantern
setblock ~-5 ~-1 ~-31 minecraft:black_concrete
setblock ~-5 ~0 ~-31 minecraft:lantern
setblock ~-5 ~-1 ~31 minecraft:black_concrete
setblock ~-5 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-5 minecraft:black_concrete
setblock ~-31 ~0 ~-5 minecraft:lantern
setblock ~31 ~-1 ~-5 minecraft:black_concrete
setblock ~31 ~0 ~-5 minecraft:lantern
setblock ~-3 ~-1 ~-31 minecraft:black_concrete
setblock ~-3 ~0 ~-31 minecraft:lantern
setblock ~-3 ~-1 ~31 minecraft:black_concrete
setblock ~-3 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-3 minecraft:black_concrete
setblock ~-31 ~0 ~-3 minecraft:lantern
setblock ~31 ~-1 ~-3 minecraft:black_concrete
setblock ~31 ~0 ~-3 minecraft:lantern
setblock ~-1 ~-1 ~-31 minecraft:black_concrete
setblock ~-1 ~0 ~-31 minecraft:lantern
setblock ~-1 ~-1 ~31 minecraft:black_concrete
setblock ~-1 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~-1 minecraft:black_concrete
setblock ~-31 ~0 ~-1 minecraft:lantern
setblock ~31 ~-1 ~-1 minecraft:black_concrete
setblock ~31 ~0 ~-1 minecraft:lantern
setblock ~1 ~-1 ~-31 minecraft:black_concrete
setblock ~1 ~0 ~-31 minecraft:lantern
setblock ~1 ~-1 ~31 minecraft:black_concrete
setblock ~1 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~1 minecraft:black_concrete
setblock ~-31 ~0 ~1 minecraft:lantern
setblock ~31 ~-1 ~1 minecraft:black_concrete
setblock ~31 ~0 ~1 minecraft:lantern
setblock ~3 ~-1 ~-31 minecraft:black_concrete
setblock ~3 ~0 ~-31 minecraft:lantern
setblock ~3 ~-1 ~31 minecraft:black_concrete
setblock ~3 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~3 minecraft:black_concrete
setblock ~-31 ~0 ~3 minecraft:lantern
setblock ~31 ~-1 ~3 minecraft:black_concrete
setblock ~31 ~0 ~3 minecraft:lantern
setblock ~5 ~-1 ~-31 minecraft:black_concrete
setblock ~5 ~0 ~-31 minecraft:lantern
setblock ~5 ~-1 ~31 minecraft:black_concrete
setblock ~5 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~5 minecraft:black_concrete
setblock ~-31 ~0 ~5 minecraft:lantern
setblock ~31 ~-1 ~5 minecraft:black_concrete
setblock ~31 ~0 ~5 minecraft:lantern
setblock ~7 ~-1 ~-31 minecraft:black_concrete
setblock ~7 ~0 ~-31 minecraft:lantern
setblock ~7 ~-1 ~31 minecraft:black_concrete
setblock ~7 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~7 minecraft:black_concrete
setblock ~-31 ~0 ~7 minecraft:lantern
setblock ~31 ~-1 ~7 minecraft:black_concrete
setblock ~31 ~0 ~7 minecraft:lantern
setblock ~9 ~-1 ~-31 minecraft:black_concrete
setblock ~9 ~0 ~-31 minecraft:lantern
setblock ~9 ~-1 ~31 minecraft:black_concrete
setblock ~9 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~9 minecraft:black_concrete
setblock ~-31 ~0 ~9 minecraft:lantern
setblock ~31 ~-1 ~9 minecraft:black_concrete
setblock ~31 ~0 ~9 minecraft:lantern
setblock ~11 ~-1 ~-31 minecraft:black_concrete
setblock ~11 ~0 ~-31 minecraft:lantern
setblock ~11 ~-1 ~31 minecraft:black_concrete
setblock ~11 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~11 minecraft:black_concrete
setblock ~-31 ~0 ~11 minecraft:lantern
setblock ~31 ~-1 ~11 minecraft:black_concrete
setblock ~31 ~0 ~11 minecraft:lantern
setblock ~13 ~-1 ~-31 minecraft:black_concrete
setblock ~13 ~0 ~-31 minecraft:lantern
setblock ~13 ~-1 ~31 minecraft:black_concrete
setblock ~13 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~13 minecraft:black_concrete
setblock ~-31 ~0 ~13 minecraft:lantern
setblock ~31 ~-1 ~13 minecraft:black_concrete
setblock ~31 ~0 ~13 minecraft:lantern
setblock ~15 ~-1 ~-31 minecraft:black_concrete
setblock ~15 ~0 ~-31 minecraft:lantern
setblock ~15 ~-1 ~31 minecraft:black_concrete
setblock ~15 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~15 minecraft:black_concrete
setblock ~-31 ~0 ~15 minecraft:lantern
setblock ~31 ~-1 ~15 minecraft:black_concrete
setblock ~31 ~0 ~15 minecraft:lantern
setblock ~17 ~-1 ~-31 minecraft:black_concrete
setblock ~17 ~0 ~-31 minecraft:lantern
setblock ~17 ~-1 ~31 minecraft:black_concrete
setblock ~17 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~17 minecraft:black_concrete
setblock ~-31 ~0 ~17 minecraft:lantern
setblock ~31 ~-1 ~17 minecraft:black_concrete
setblock ~31 ~0 ~17 minecraft:lantern
setblock ~19 ~-1 ~-31 minecraft:black_concrete
setblock ~19 ~0 ~-31 minecraft:lantern
setblock ~19 ~-1 ~31 minecraft:black_concrete
setblock ~19 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~19 minecraft:black_concrete
setblock ~-31 ~0 ~19 minecraft:lantern
setblock ~31 ~-1 ~19 minecraft:black_concrete
setblock ~31 ~0 ~19 minecraft:lantern
setblock ~21 ~-1 ~-31 minecraft:black_concrete
setblock ~21 ~0 ~-31 minecraft:lantern
setblock ~21 ~-1 ~31 minecraft:black_concrete
setblock ~21 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~21 minecraft:black_concrete
setblock ~-31 ~0 ~21 minecraft:lantern
setblock ~31 ~-1 ~21 minecraft:black_concrete
setblock ~31 ~0 ~21 minecraft:lantern
setblock ~23 ~-1 ~-31 minecraft:black_concrete
setblock ~23 ~0 ~-31 minecraft:lantern
setblock ~23 ~-1 ~31 minecraft:black_concrete
setblock ~23 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~23 minecraft:black_concrete
setblock ~-31 ~0 ~23 minecraft:lantern
setblock ~31 ~-1 ~23 minecraft:black_concrete
setblock ~31 ~0 ~23 minecraft:lantern
setblock ~25 ~-1 ~-31 minecraft:black_concrete
setblock ~25 ~0 ~-31 minecraft:lantern
setblock ~25 ~-1 ~31 minecraft:black_concrete
setblock ~25 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~25 minecraft:black_concrete
setblock ~-31 ~0 ~25 minecraft:lantern
setblock ~31 ~-1 ~25 minecraft:black_concrete
setblock ~31 ~0 ~25 minecraft:lantern
setblock ~27 ~-1 ~-31 minecraft:black_concrete
setblock ~27 ~0 ~-31 minecraft:lantern
setblock ~27 ~-1 ~31 minecraft:black_concrete
setblock ~27 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~27 minecraft:black_concrete
setblock ~-31 ~0 ~27 minecraft:lantern
setblock ~31 ~-1 ~27 minecraft:black_concrete
setblock ~31 ~0 ~27 minecraft:lantern
setblock ~29 ~-1 ~-31 minecraft:black_concrete
setblock ~29 ~0 ~-31 minecraft:lantern
setblock ~29 ~-1 ~31 minecraft:black_concrete
setblock ~29 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~29 minecraft:black_concrete
setblock ~-31 ~0 ~29 minecraft:lantern
setblock ~31 ~-1 ~29 minecraft:black_concrete
setblock ~31 ~0 ~29 minecraft:lantern
setblock ~31 ~-1 ~-31 minecraft:black_concrete
setblock ~31 ~0 ~-31 minecraft:lantern
setblock ~31 ~-1 ~31 minecraft:black_concrete
setblock ~31 ~0 ~31 minecraft:lantern
setblock ~-31 ~-1 ~31 minecraft:black_concrete
setblock ~-31 ~0 ~31 minecraft:lantern
setblock ~31 ~-1 ~31 minecraft:black_concrete
setblock ~31 ~0 ~31 minecraft:lantern
setblock ~-28 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-28 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-24 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-20 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-16 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-12 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-8 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~-4 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~0 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~4 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~8 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~12 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~16 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~20 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~24 ~59 ~28 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-28 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-24 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-20 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-16 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-12 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-8 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~-4 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~0 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~4 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~8 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~12 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~16 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~20 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~24 minecraft:lantern[hanging=true]
setblock ~28 ~59 ~28 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
