# Пирамида: основание 51x51, высота 26. Центр — там, где стоит игрок.
tellraw @s {"text":"Строю пирамиду...","color":"gold"}
fill ~-25 ~-1 ~-25 ~25 ~-1 ~25 minecraft:black_concrete
fill ~-25 ~0 ~-25 ~25 ~0 ~25 minecraft:glass
fill ~-24 ~0 ~-24 ~24 ~0 ~24 minecraft:air
fill ~-24 ~1 ~-24 ~24 ~1 ~24 minecraft:glass
fill ~-23 ~1 ~-23 ~23 ~1 ~23 minecraft:air
fill ~-23 ~2 ~-23 ~23 ~2 ~23 minecraft:glass
fill ~-22 ~2 ~-22 ~22 ~2 ~22 minecraft:air
fill ~-22 ~3 ~-22 ~22 ~3 ~22 minecraft:glass
fill ~-21 ~3 ~-21 ~21 ~3 ~21 minecraft:air
fill ~-21 ~4 ~-21 ~21 ~4 ~21 minecraft:glass
fill ~-20 ~4 ~-20 ~20 ~4 ~20 minecraft:air
fill ~-20 ~5 ~-20 ~20 ~5 ~20 minecraft:glass
fill ~-19 ~5 ~-19 ~19 ~5 ~19 minecraft:air
fill ~-19 ~6 ~-19 ~19 ~6 ~19 minecraft:glass
fill ~-18 ~6 ~-18 ~18 ~6 ~18 minecraft:air
fill ~-18 ~7 ~-18 ~18 ~7 ~18 minecraft:glass
fill ~-17 ~7 ~-17 ~17 ~7 ~17 minecraft:air
fill ~-17 ~8 ~-17 ~17 ~8 ~17 minecraft:glass
fill ~-16 ~8 ~-16 ~16 ~8 ~16 minecraft:air
fill ~-16 ~9 ~-16 ~16 ~9 ~16 minecraft:glass
fill ~-15 ~9 ~-15 ~15 ~9 ~15 minecraft:air
fill ~-15 ~10 ~-15 ~15 ~10 ~15 minecraft:glass
fill ~-14 ~10 ~-14 ~14 ~10 ~14 minecraft:air
fill ~-14 ~11 ~-14 ~14 ~11 ~14 minecraft:glass
fill ~-13 ~11 ~-13 ~13 ~11 ~13 minecraft:air
fill ~-13 ~12 ~-13 ~13 ~12 ~13 minecraft:glass
fill ~-12 ~12 ~-12 ~12 ~12 ~12 minecraft:air
fill ~-12 ~13 ~-12 ~12 ~13 ~12 minecraft:glass
fill ~-11 ~13 ~-11 ~11 ~13 ~11 minecraft:air
fill ~-11 ~14 ~-11 ~11 ~14 ~11 minecraft:glass
fill ~-10 ~14 ~-10 ~10 ~14 ~10 minecraft:air
fill ~-10 ~15 ~-10 ~10 ~15 ~10 minecraft:glass
fill ~-9 ~15 ~-9 ~9 ~15 ~9 minecraft:air
fill ~-9 ~16 ~-9 ~9 ~16 ~9 minecraft:glass
fill ~-8 ~16 ~-8 ~8 ~16 ~8 minecraft:air
fill ~-8 ~17 ~-8 ~8 ~17 ~8 minecraft:glass
fill ~-7 ~17 ~-7 ~7 ~17 ~7 minecraft:air
fill ~-7 ~18 ~-7 ~7 ~18 ~7 minecraft:glass
fill ~-6 ~18 ~-6 ~6 ~18 ~6 minecraft:air
fill ~-6 ~19 ~-6 ~6 ~19 ~6 minecraft:glass
fill ~-5 ~19 ~-5 ~5 ~19 ~5 minecraft:air
fill ~-5 ~20 ~-5 ~5 ~20 ~5 minecraft:glass
fill ~-4 ~20 ~-4 ~4 ~20 ~4 minecraft:air
fill ~-4 ~21 ~-4 ~4 ~21 ~4 minecraft:glass
fill ~-3 ~21 ~-3 ~3 ~21 ~3 minecraft:air
fill ~-3 ~22 ~-3 ~3 ~22 ~3 minecraft:glass
fill ~-2 ~22 ~-2 ~2 ~22 ~2 minecraft:air
fill ~-2 ~23 ~-2 ~2 ~23 ~2 minecraft:glass
fill ~-1 ~23 ~-1 ~1 ~23 ~1 minecraft:air
fill ~-1 ~24 ~-1 ~1 ~24 ~1 minecraft:glass
fill ~-0 ~24 ~-0 ~0 ~24 ~0 minecraft:air
fill ~-0 ~25 ~-0 ~0 ~25 ~0 minecraft:glass
setblock ~-24 ~0 ~-24 minecraft:lantern
setblock ~-24 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-24 minecraft:lantern
setblock ~24 ~0 ~-24 minecraft:lantern
setblock ~-22 ~0 ~-24 minecraft:lantern
setblock ~-22 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-22 minecraft:lantern
setblock ~24 ~0 ~-22 minecraft:lantern
setblock ~-20 ~0 ~-24 minecraft:lantern
setblock ~-20 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-20 minecraft:lantern
setblock ~24 ~0 ~-20 minecraft:lantern
setblock ~-18 ~0 ~-24 minecraft:lantern
setblock ~-18 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-18 minecraft:lantern
setblock ~24 ~0 ~-18 minecraft:lantern
setblock ~-16 ~0 ~-24 minecraft:lantern
setblock ~-16 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-16 minecraft:lantern
setblock ~24 ~0 ~-16 minecraft:lantern
setblock ~-14 ~0 ~-24 minecraft:lantern
setblock ~-14 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-14 minecraft:lantern
setblock ~24 ~0 ~-14 minecraft:lantern
setblock ~-12 ~0 ~-24 minecraft:lantern
setblock ~-12 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-12 minecraft:lantern
setblock ~24 ~0 ~-12 minecraft:lantern
setblock ~-10 ~0 ~-24 minecraft:lantern
setblock ~-10 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-10 minecraft:lantern
setblock ~24 ~0 ~-10 minecraft:lantern
setblock ~-8 ~0 ~-24 minecraft:lantern
setblock ~-8 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-8 minecraft:lantern
setblock ~24 ~0 ~-8 minecraft:lantern
setblock ~-6 ~0 ~-24 minecraft:lantern
setblock ~-6 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-6 minecraft:lantern
setblock ~24 ~0 ~-6 minecraft:lantern
setblock ~-4 ~0 ~-24 minecraft:lantern
setblock ~-4 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-4 minecraft:lantern
setblock ~24 ~0 ~-4 minecraft:lantern
setblock ~-2 ~0 ~-24 minecraft:lantern
setblock ~-2 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~-2 minecraft:lantern
setblock ~24 ~0 ~-2 minecraft:lantern
setblock ~0 ~0 ~-24 minecraft:lantern
setblock ~0 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~0 minecraft:lantern
setblock ~24 ~0 ~0 minecraft:lantern
setblock ~2 ~0 ~-24 minecraft:lantern
setblock ~2 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~2 minecraft:lantern
setblock ~24 ~0 ~2 minecraft:lantern
setblock ~4 ~0 ~-24 minecraft:lantern
setblock ~4 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~4 minecraft:lantern
setblock ~24 ~0 ~4 minecraft:lantern
setblock ~6 ~0 ~-24 minecraft:lantern
setblock ~6 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~6 minecraft:lantern
setblock ~24 ~0 ~6 minecraft:lantern
setblock ~8 ~0 ~-24 minecraft:lantern
setblock ~8 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~8 minecraft:lantern
setblock ~24 ~0 ~8 minecraft:lantern
setblock ~10 ~0 ~-24 minecraft:lantern
setblock ~10 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~10 minecraft:lantern
setblock ~24 ~0 ~10 minecraft:lantern
setblock ~12 ~0 ~-24 minecraft:lantern
setblock ~12 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~12 minecraft:lantern
setblock ~24 ~0 ~12 minecraft:lantern
setblock ~14 ~0 ~-24 minecraft:lantern
setblock ~14 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~14 minecraft:lantern
setblock ~24 ~0 ~14 minecraft:lantern
setblock ~16 ~0 ~-24 minecraft:lantern
setblock ~16 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~16 minecraft:lantern
setblock ~24 ~0 ~16 minecraft:lantern
setblock ~18 ~0 ~-24 minecraft:lantern
setblock ~18 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~18 minecraft:lantern
setblock ~24 ~0 ~18 minecraft:lantern
setblock ~20 ~0 ~-24 minecraft:lantern
setblock ~20 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~20 minecraft:lantern
setblock ~24 ~0 ~20 minecraft:lantern
setblock ~22 ~0 ~-24 minecraft:lantern
setblock ~22 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~22 minecraft:lantern
setblock ~24 ~0 ~22 minecraft:lantern
setblock ~24 ~0 ~-24 minecraft:lantern
setblock ~24 ~0 ~24 minecraft:lantern
setblock ~-24 ~0 ~24 minecraft:lantern
setblock ~24 ~0 ~24 minecraft:lantern
setblock ~-21 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-21 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-21 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-21 minecraft:lantern[hanging=true]
setblock ~-17 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-17 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-17 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-17 minecraft:lantern[hanging=true]
setblock ~-13 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-13 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-13 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-13 minecraft:lantern[hanging=true]
setblock ~-9 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-9 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-9 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-5 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-5 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~-1 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~-1 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~3 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~3 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~7 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~7 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~7 minecraft:lantern[hanging=true]
setblock ~11 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~11 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~11 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~11 minecraft:lantern[hanging=true]
setblock ~15 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~15 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~15 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~15 minecraft:lantern[hanging=true]
setblock ~19 ~2 ~-22 minecraft:lantern[hanging=true]
setblock ~19 ~2 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~2 ~19 minecraft:lantern[hanging=true]
setblock ~22 ~2 ~19 minecraft:lantern[hanging=true]
setblock ~-18 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~-18 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~-18 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-18 minecraft:lantern[hanging=true]
setblock ~-14 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~-14 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~-14 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-14 minecraft:lantern[hanging=true]
setblock ~-10 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~-10 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~-10 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-10 minecraft:lantern[hanging=true]
setblock ~-6 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~-6 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~-6 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~-2 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~-2 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~2 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~2 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~6 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~6 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~6 minecraft:lantern[hanging=true]
setblock ~10 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~10 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~10 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~10 minecraft:lantern[hanging=true]
setblock ~14 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~14 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~14 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~14 minecraft:lantern[hanging=true]
setblock ~18 ~5 ~-19 minecraft:lantern[hanging=true]
setblock ~18 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~5 ~18 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~18 minecraft:lantern[hanging=true]
setblock ~-15 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~-15 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~-15 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~-15 minecraft:lantern[hanging=true]
setblock ~-11 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~-11 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~-11 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~-11 minecraft:lantern[hanging=true]
setblock ~-7 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~-7 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~-7 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~-7 minecraft:lantern[hanging=true]
setblock ~-3 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~-3 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~-3 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~1 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~1 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~1 minecraft:lantern[hanging=true]
setblock ~5 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~5 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~5 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~5 minecraft:lantern[hanging=true]
setblock ~9 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~9 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~9 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~9 minecraft:lantern[hanging=true]
setblock ~13 ~8 ~-16 minecraft:lantern[hanging=true]
setblock ~13 ~8 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~8 ~13 minecraft:lantern[hanging=true]
setblock ~16 ~8 ~13 minecraft:lantern[hanging=true]
setblock ~-12 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~-12 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~-12 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~-12 minecraft:lantern[hanging=true]
setblock ~-8 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~-8 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~-8 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~-4 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~-4 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~0 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~0 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~4 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~4 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~8 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~8 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~8 minecraft:lantern[hanging=true]
setblock ~12 ~11 ~-13 minecraft:lantern[hanging=true]
setblock ~12 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~11 ~12 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~12 minecraft:lantern[hanging=true]
setblock ~-9 ~14 ~-10 minecraft:lantern[hanging=true]
setblock ~-9 ~14 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~14 ~-9 minecraft:lantern[hanging=true]
setblock ~10 ~14 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~14 ~-10 minecraft:lantern[hanging=true]
setblock ~-5 ~14 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~14 ~-5 minecraft:lantern[hanging=true]
setblock ~10 ~14 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~14 ~-10 minecraft:lantern[hanging=true]
setblock ~-1 ~14 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~14 ~-1 minecraft:lantern[hanging=true]
setblock ~10 ~14 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~14 ~-10 minecraft:lantern[hanging=true]
setblock ~3 ~14 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~14 ~3 minecraft:lantern[hanging=true]
setblock ~10 ~14 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~14 ~-10 minecraft:lantern[hanging=true]
setblock ~7 ~14 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~14 ~7 minecraft:lantern[hanging=true]
setblock ~10 ~14 ~7 minecraft:lantern[hanging=true]
setblock ~-6 ~17 ~-7 minecraft:lantern[hanging=true]
setblock ~-6 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~17 ~-6 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~17 ~-7 minecraft:lantern[hanging=true]
setblock ~-2 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~17 ~-2 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~17 ~-7 minecraft:lantern[hanging=true]
setblock ~2 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~17 ~2 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~17 ~-7 minecraft:lantern[hanging=true]
setblock ~6 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~17 ~6 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~6 minecraft:lantern[hanging=true]
setblock ~-3 ~20 ~-4 minecraft:lantern[hanging=true]
setblock ~-3 ~20 ~4 minecraft:lantern[hanging=true]
setblock ~-4 ~20 ~-3 minecraft:lantern[hanging=true]
setblock ~4 ~20 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~20 ~-4 minecraft:lantern[hanging=true]
setblock ~1 ~20 ~4 minecraft:lantern[hanging=true]
setblock ~-4 ~20 ~1 minecraft:lantern[hanging=true]
setblock ~4 ~20 ~1 minecraft:lantern[hanging=true]
setblock ~0 ~24 ~0 minecraft:chain
setblock ~0 ~23 ~0 minecraft:chain
setblock ~0 ~22 ~0 minecraft:chain
setblock ~0 ~21 ~0 minecraft:chain
setblock ~0 ~20 ~0 minecraft:chain
setblock ~0 ~19 ~0 minecraft:chain
setblock ~0 ~18 ~0 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
