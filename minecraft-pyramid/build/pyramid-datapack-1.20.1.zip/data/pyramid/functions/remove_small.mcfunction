# Удаляет пирамиду размера R=15 вокруг игрока (стоять там же, где строили)
fill ~-15 ~0 ~-15 ~15 ~15 ~15 minecraft:air
fill ~-15 ~-1 ~-15 ~15 ~-1 ~15 minecraft:grass_block
tellraw @s {"text":"Пирамида удалена","color":"yellow"}
