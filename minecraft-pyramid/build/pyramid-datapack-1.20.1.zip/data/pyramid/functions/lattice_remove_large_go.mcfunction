execute as @e[type=marker,tag=lat_large_rm,limit=1] at @s run function pyramid:lattice_remove_large_do
execute as @e[type=marker,tag=lat_large_rm,limit=1] at @s run forceload remove ~-98 ~-98 ~98 ~98
kill @e[type=marker,tag=lat_large_rm]
tellraw @a {"text":"Решётка удалена","color":"yellow"}
