# Удаляет пирамиду размера R=40 вокруг игрока (стоять там же, где строили)
fill ~-40 ~0 ~-40 ~40 ~40 ~40 minecraft:air
fill ~-40 ~-1 ~-40 ~40 ~-1 ~40 minecraft:grass_block
tellraw @s {"text":"Пирамида удалена","color":"yellow"}
