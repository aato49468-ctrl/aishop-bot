# Куб 31x31x32 (с полом и потолком). Центр пола — там, где стоит игрок.
tellraw @s {"text":"Строю куб...","color":"gold"}
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:air
fill ~-14 ~1 ~-14 ~14 ~1 ~14 minecraft:air
fill ~-14 ~2 ~-14 ~14 ~2 ~14 minecraft:air
fill ~-14 ~3 ~-14 ~14 ~3 ~14 minecraft:air
fill ~-14 ~4 ~-14 ~14 ~4 ~14 minecraft:air
fill ~-14 ~5 ~-14 ~14 ~5 ~14 minecraft:air
fill ~-14 ~6 ~-14 ~14 ~6 ~14 minecraft:air
fill ~-14 ~7 ~-14 ~14 ~7 ~14 minecraft:air
fill ~-14 ~8 ~-14 ~14 ~8 ~14 minecraft:air
fill ~-14 ~9 ~-14 ~14 ~9 ~14 minecraft:air
fill ~-14 ~10 ~-14 ~14 ~10 ~14 minecraft:air
fill ~-14 ~11 ~-14 ~14 ~11 ~14 minecraft:air
fill ~-14 ~12 ~-14 ~14 ~12 ~14 minecraft:air
fill ~-14 ~13 ~-14 ~14 ~13 ~14 minecraft:air
fill ~-14 ~14 ~-14 ~14 ~14 ~14 minecraft:air
fill ~-14 ~15 ~-14 ~14 ~15 ~14 minecraft:air
fill ~-14 ~16 ~-14 ~14 ~16 ~14 minecraft:air
fill ~-14 ~17 ~-14 ~14 ~17 ~14 minecraft:air
fill ~-14 ~18 ~-14 ~14 ~18 ~14 minecraft:air
fill ~-14 ~19 ~-14 ~14 ~19 ~14 minecraft:air
fill ~-14 ~20 ~-14 ~14 ~20 ~14 minecraft:air
fill ~-14 ~21 ~-14 ~14 ~21 ~14 minecraft:air
fill ~-14 ~22 ~-14 ~14 ~22 ~14 minecraft:air
fill ~-14 ~23 ~-14 ~14 ~23 ~14 minecraft:air
fill ~-14 ~24 ~-14 ~14 ~24 ~14 minecraft:air
fill ~-14 ~25 ~-14 ~14 ~25 ~14 minecraft:air
fill ~-14 ~26 ~-14 ~14 ~26 ~14 minecraft:air
fill ~-14 ~27 ~-14 ~14 ~27 ~14 minecraft:air
fill ~-14 ~28 ~-14 ~14 ~28 ~14 minecraft:air
fill ~-14 ~29 ~-14 ~14 ~29 ~14 minecraft:air
fill ~-15 ~-1 ~-15 ~15 ~-1 ~15 minecraft:black_concrete
fill ~-15 ~30 ~-15 ~15 ~30 ~15 minecraft:glass
fill ~-15 ~0 ~-15 ~15 ~29 ~-15 minecraft:glass
fill ~-15 ~0 ~15 ~15 ~29 ~15 minecraft:glass
fill ~-15 ~0 ~-15 ~-15 ~29 ~15 minecraft:glass
fill ~15 ~0 ~-15 ~15 ~29 ~15 minecraft:glass
setblock ~-14 ~0 ~-14 minecraft:lantern
setblock ~-14 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-14 minecraft:lantern
setblock ~14 ~0 ~-14 minecraft:lantern
setblock ~-12 ~0 ~-14 minecraft:lantern
setblock ~-12 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-12 minecraft:lantern
setblock ~14 ~0 ~-12 minecraft:lantern
setblock ~-10 ~0 ~-14 minecraft:lantern
setblock ~-10 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-10 minecraft:lantern
setblock ~14 ~0 ~-10 minecraft:lantern
setblock ~-8 ~0 ~-14 minecraft:lantern
setblock ~-8 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-8 minecraft:lantern
setblock ~14 ~0 ~-8 minecraft:lantern
setblock ~-6 ~0 ~-14 minecraft:lantern
setblock ~-6 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-6 minecraft:lantern
setblock ~14 ~0 ~-6 minecraft:lantern
setblock ~-4 ~0 ~-14 minecraft:lantern
setblock ~-4 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-4 minecraft:lantern
setblock ~14 ~0 ~-4 minecraft:lantern
setblock ~-2 ~0 ~-14 minecraft:lantern
setblock ~-2 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-2 minecraft:lantern
setblock ~14 ~0 ~-2 minecraft:lantern
setblock ~0 ~0 ~-14 minecraft:lantern
setblock ~0 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~0 minecraft:lantern
setblock ~14 ~0 ~0 minecraft:lantern
setblock ~2 ~0 ~-14 minecraft:lantern
setblock ~2 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~2 minecraft:lantern
setblock ~14 ~0 ~2 minecraft:lantern
setblock ~4 ~0 ~-14 minecraft:lantern
setblock ~4 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~4 minecraft:lantern
setblock ~14 ~0 ~4 minecraft:lantern
setblock ~6 ~0 ~-14 minecraft:lantern
setblock ~6 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~6 minecraft:lantern
setblock ~14 ~0 ~6 minecraft:lantern
setblock ~8 ~0 ~-14 minecraft:lantern
setblock ~8 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~8 minecraft:lantern
setblock ~14 ~0 ~8 minecraft:lantern
setblock ~10 ~0 ~-14 minecraft:lantern
setblock ~10 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~10 minecraft:lantern
setblock ~14 ~0 ~10 minecraft:lantern
setblock ~12 ~0 ~-14 minecraft:lantern
setblock ~12 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~12 minecraft:lantern
setblock ~14 ~0 ~12 minecraft:lantern
setblock ~14 ~0 ~-14 minecraft:lantern
setblock ~14 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~14 minecraft:lantern
setblock ~14 ~0 ~14 minecraft:lantern
setblock ~-16 ~-1 ~-16 minecraft:black_concrete
setblock ~-16 ~0 ~-16 minecraft:lantern
setblock ~-16 ~-1 ~16 minecraft:black_concrete
setblock ~-16 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-16 minecraft:black_concrete
setblock ~-16 ~0 ~-16 minecraft:lantern
setblock ~16 ~-1 ~-16 minecraft:black_concrete
setblock ~16 ~0 ~-16 minecraft:lantern
setblock ~-14 ~-1 ~-16 minecraft:black_concrete
setblock ~-14 ~0 ~-16 minecraft:lantern
setblock ~-14 ~-1 ~16 minecraft:black_concrete
setblock ~-14 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-14 minecraft:black_concrete
setblock ~-16 ~0 ~-14 minecraft:lantern
setblock ~16 ~-1 ~-14 minecraft:black_concrete
setblock ~16 ~0 ~-14 minecraft:lantern
setblock ~-12 ~-1 ~-16 minecraft:black_concrete
setblock ~-12 ~0 ~-16 minecraft:lantern
setblock ~-12 ~-1 ~16 minecraft:black_concrete
setblock ~-12 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-12 minecraft:black_concrete
setblock ~-16 ~0 ~-12 minecraft:lantern
setblock ~16 ~-1 ~-12 minecraft:black_concrete
setblock ~16 ~0 ~-12 minecraft:lantern
setblock ~-10 ~-1 ~-16 minecraft:black_concrete
setblock ~-10 ~0 ~-16 minecraft:lantern
setblock ~-10 ~-1 ~16 minecraft:black_concrete
setblock ~-10 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-10 minecraft:black_concrete
setblock ~-16 ~0 ~-10 minecraft:lantern
setblock ~16 ~-1 ~-10 minecraft:black_concrete
setblock ~16 ~0 ~-10 minecraft:lantern
setblock ~-8 ~-1 ~-16 minecraft:black_concrete
setblock ~-8 ~0 ~-16 minecraft:lantern
setblock ~-8 ~-1 ~16 minecraft:black_concrete
setblock ~-8 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-8 minecraft:black_concrete
setblock ~-16 ~0 ~-8 minecraft:lantern
setblock ~16 ~-1 ~-8 minecraft:black_concrete
setblock ~16 ~0 ~-8 minecraft:lantern
setblock ~-6 ~-1 ~-16 minecraft:black_concrete
setblock ~-6 ~0 ~-16 minecraft:lantern
setblock ~-6 ~-1 ~16 minecraft:black_concrete
setblock ~-6 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-6 minecraft:black_concrete
setblock ~-16 ~0 ~-6 minecraft:lantern
setblock ~16 ~-1 ~-6 minecraft:black_concrete
setblock ~16 ~0 ~-6 minecraft:lantern
setblock ~-4 ~-1 ~-16 minecraft:black_concrete
setblock ~-4 ~0 ~-16 minecraft:lantern
setblock ~-4 ~-1 ~16 minecraft:black_concrete
setblock ~-4 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-4 minecraft:black_concrete
setblock ~-16 ~0 ~-4 minecraft:lantern
setblock ~16 ~-1 ~-4 minecraft:black_concrete
setblock ~16 ~0 ~-4 minecraft:lantern
setblock ~-2 ~-1 ~-16 minecraft:black_concrete
setblock ~-2 ~0 ~-16 minecraft:lantern
setblock ~-2 ~-1 ~16 minecraft:black_concrete
setblock ~-2 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~-2 minecraft:black_concrete
setblock ~-16 ~0 ~-2 minecraft:lantern
setblock ~16 ~-1 ~-2 minecraft:black_concrete
setblock ~16 ~0 ~-2 minecraft:lantern
setblock ~0 ~-1 ~-16 minecraft:black_concrete
setblock ~0 ~0 ~-16 minecraft:lantern
setblock ~0 ~-1 ~16 minecraft:black_concrete
setblock ~0 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~0 minecraft:black_concrete
setblock ~-16 ~0 ~0 minecraft:lantern
setblock ~16 ~-1 ~0 minecraft:black_concrete
setblock ~16 ~0 ~0 minecraft:lantern
setblock ~2 ~-1 ~-16 minecraft:black_concrete
setblock ~2 ~0 ~-16 minecraft:lantern
setblock ~2 ~-1 ~16 minecraft:black_concrete
setblock ~2 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~2 minecraft:black_concrete
setblock ~-16 ~0 ~2 minecraft:lantern
setblock ~16 ~-1 ~2 minecraft:black_concrete
setblock ~16 ~0 ~2 minecraft:lantern
setblock ~4 ~-1 ~-16 minecraft:black_concrete
setblock ~4 ~0 ~-16 minecraft:lantern
setblock ~4 ~-1 ~16 minecraft:black_concrete
setblock ~4 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~4 minecraft:black_concrete
setblock ~-16 ~0 ~4 minecraft:lantern
setblock ~16 ~-1 ~4 minecraft:black_concrete
setblock ~16 ~0 ~4 minecraft:lantern
setblock ~6 ~-1 ~-16 minecraft:black_concrete
setblock ~6 ~0 ~-16 minecraft:lantern
setblock ~6 ~-1 ~16 minecraft:black_concrete
setblock ~6 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~6 minecraft:black_concrete
setblock ~-16 ~0 ~6 minecraft:lantern
setblock ~16 ~-1 ~6 minecraft:black_concrete
setblock ~16 ~0 ~6 minecraft:lantern
setblock ~8 ~-1 ~-16 minecraft:black_concrete
setblock ~8 ~0 ~-16 minecraft:lantern
setblock ~8 ~-1 ~16 minecraft:black_concrete
setblock ~8 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~8 minecraft:black_concrete
setblock ~-16 ~0 ~8 minecraft:lantern
setblock ~16 ~-1 ~8 minecraft:black_concrete
setblock ~16 ~0 ~8 minecraft:lantern
setblock ~10 ~-1 ~-16 minecraft:black_concrete
setblock ~10 ~0 ~-16 minecraft:lantern
setblock ~10 ~-1 ~16 minecraft:black_concrete
setblock ~10 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~10 minecraft:black_concrete
setblock ~-16 ~0 ~10 minecraft:lantern
setblock ~16 ~-1 ~10 minecraft:black_concrete
setblock ~16 ~0 ~10 minecraft:lantern
setblock ~12 ~-1 ~-16 minecraft:black_concrete
setblock ~12 ~0 ~-16 minecraft:lantern
setblock ~12 ~-1 ~16 minecraft:black_concrete
setblock ~12 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~12 minecraft:black_concrete
setblock ~-16 ~0 ~12 minecraft:lantern
setblock ~16 ~-1 ~12 minecraft:black_concrete
setblock ~16 ~0 ~12 minecraft:lantern
setblock ~14 ~-1 ~-16 minecraft:black_concrete
setblock ~14 ~0 ~-16 minecraft:lantern
setblock ~14 ~-1 ~16 minecraft:black_concrete
setblock ~14 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~14 minecraft:black_concrete
setblock ~-16 ~0 ~14 minecraft:lantern
setblock ~16 ~-1 ~14 minecraft:black_concrete
setblock ~16 ~0 ~14 minecraft:lantern
setblock ~16 ~-1 ~-16 minecraft:black_concrete
setblock ~16 ~0 ~-16 minecraft:lantern
setblock ~16 ~-1 ~16 minecraft:black_concrete
setblock ~16 ~0 ~16 minecraft:lantern
setblock ~-16 ~-1 ~16 minecraft:black_concrete
setblock ~-16 ~0 ~16 minecraft:lantern
setblock ~16 ~-1 ~16 minecraft:black_concrete
setblock ~16 ~0 ~16 minecraft:lantern
setblock ~-13 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~-13 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~11 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~-13 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~11 ~29 ~11 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
