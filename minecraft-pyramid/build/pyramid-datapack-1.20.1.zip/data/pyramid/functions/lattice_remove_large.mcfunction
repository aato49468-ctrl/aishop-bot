# Удаление решётки 192x192x192. Встаньте туда же, где строили.
kill @e[type=marker,tag=lat_large_rm]
forceload add ~-98 ~-98 ~98 ~98
summon marker ~ ~ ~ {Tags:["lat_large_rm"]}
schedule function pyramid:lattice_remove_large_go 40t
