# Куб 41x41x42 (с полом и потолком). Центр пола — там, где стоит игрок.
tellraw @s {"text":"Строю куб...","color":"gold"}
fill ~-19 ~0 ~-19 ~19 ~0 ~19 minecraft:air
fill ~-19 ~1 ~-19 ~19 ~1 ~19 minecraft:air
fill ~-19 ~2 ~-19 ~19 ~2 ~19 minecraft:air
fill ~-19 ~3 ~-19 ~19 ~3 ~19 minecraft:air
fill ~-19 ~4 ~-19 ~19 ~4 ~19 minecraft:air
fill ~-19 ~5 ~-19 ~19 ~5 ~19 minecraft:air
fill ~-19 ~6 ~-19 ~19 ~6 ~19 minecraft:air
fill ~-19 ~7 ~-19 ~19 ~7 ~19 minecraft:air
fill ~-19 ~8 ~-19 ~19 ~8 ~19 minecraft:air
fill ~-19 ~9 ~-19 ~19 ~9 ~19 minecraft:air
fill ~-19 ~10 ~-19 ~19 ~10 ~19 minecraft:air
fill ~-19 ~11 ~-19 ~19 ~11 ~19 minecraft:air
fill ~-19 ~12 ~-19 ~19 ~12 ~19 minecraft:air
fill ~-19 ~13 ~-19 ~19 ~13 ~19 minecraft:air
fill ~-19 ~14 ~-19 ~19 ~14 ~19 minecraft:air
fill ~-19 ~15 ~-19 ~19 ~15 ~19 minecraft:air
fill ~-19 ~16 ~-19 ~19 ~16 ~19 minecraft:air
fill ~-19 ~17 ~-19 ~19 ~17 ~19 minecraft:air
fill ~-19 ~18 ~-19 ~19 ~18 ~19 minecraft:air
fill ~-19 ~19 ~-19 ~19 ~19 ~19 minecraft:air
fill ~-19 ~20 ~-19 ~19 ~20 ~19 minecraft:air
fill ~-19 ~21 ~-19 ~19 ~21 ~19 minecraft:air
fill ~-19 ~22 ~-19 ~19 ~22 ~19 minecraft:air
fill ~-19 ~23 ~-19 ~19 ~23 ~19 minecraft:air
fill ~-19 ~24 ~-19 ~19 ~24 ~19 minecraft:air
fill ~-19 ~25 ~-19 ~19 ~25 ~19 minecraft:air
fill ~-19 ~26 ~-19 ~19 ~26 ~19 minecraft:air
fill ~-19 ~27 ~-19 ~19 ~27 ~19 minecraft:air
fill ~-19 ~28 ~-19 ~19 ~28 ~19 minecraft:air
fill ~-19 ~29 ~-19 ~19 ~29 ~19 minecraft:air
fill ~-19 ~30 ~-19 ~19 ~30 ~19 minecraft:air
fill ~-19 ~31 ~-19 ~19 ~31 ~19 minecraft:air
fill ~-19 ~32 ~-19 ~19 ~32 ~19 minecraft:air
fill ~-19 ~33 ~-19 ~19 ~33 ~19 minecraft:air
fill ~-19 ~34 ~-19 ~19 ~34 ~19 minecraft:air
fill ~-19 ~35 ~-19 ~19 ~35 ~19 minecraft:air
fill ~-19 ~36 ~-19 ~19 ~36 ~19 minecraft:air
fill ~-19 ~37 ~-19 ~19 ~37 ~19 minecraft:air
fill ~-19 ~38 ~-19 ~19 ~38 ~19 minecraft:air
fill ~-19 ~39 ~-19 ~19 ~39 ~19 minecraft:air
fill ~-20 ~-1 ~-20 ~20 ~-1 ~20 minecraft:black_concrete
fill ~-20 ~40 ~-20 ~20 ~40 ~20 minecraft:glass
fill ~-20 ~0 ~-20 ~20 ~39 ~-20 minecraft:glass
fill ~-20 ~0 ~20 ~20 ~39 ~20 minecraft:glass
fill ~-20 ~0 ~-20 ~-20 ~39 ~20 minecraft:glass
fill ~20 ~0 ~-20 ~20 ~39 ~20 minecraft:glass
setblock ~-19 ~0 ~-19 minecraft:lantern
setblock ~-19 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-19 minecraft:lantern
setblock ~19 ~0 ~-19 minecraft:lantern
setblock ~-17 ~0 ~-19 minecraft:lantern
setblock ~-17 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-17 minecraft:lantern
setblock ~19 ~0 ~-17 minecraft:lantern
setblock ~-15 ~0 ~-19 minecraft:lantern
setblock ~-15 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-15 minecraft:lantern
setblock ~19 ~0 ~-15 minecraft:lantern
setblock ~-13 ~0 ~-19 minecraft:lantern
setblock ~-13 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-13 minecraft:lantern
setblock ~19 ~0 ~-13 minecraft:lantern
setblock ~-11 ~0 ~-19 minecraft:lantern
setblock ~-11 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-11 minecraft:lantern
setblock ~19 ~0 ~-11 minecraft:lantern
setblock ~-9 ~0 ~-19 minecraft:lantern
setblock ~-9 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-9 minecraft:lantern
setblock ~19 ~0 ~-9 minecraft:lantern
setblock ~-7 ~0 ~-19 minecraft:lantern
setblock ~-7 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-7 minecraft:lantern
setblock ~19 ~0 ~-7 minecraft:lantern
setblock ~-5 ~0 ~-19 minecraft:lantern
setblock ~-5 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-5 minecraft:lantern
setblock ~19 ~0 ~-5 minecraft:lantern
setblock ~-3 ~0 ~-19 minecraft:lantern
setblock ~-3 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-3 minecraft:lantern
setblock ~19 ~0 ~-3 minecraft:lantern
setblock ~-1 ~0 ~-19 minecraft:lantern
setblock ~-1 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~-1 minecraft:lantern
setblock ~19 ~0 ~-1 minecraft:lantern
setblock ~1 ~0 ~-19 minecraft:lantern
setblock ~1 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~1 minecraft:lantern
setblock ~19 ~0 ~1 minecraft:lantern
setblock ~3 ~0 ~-19 minecraft:lantern
setblock ~3 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~3 minecraft:lantern
setblock ~19 ~0 ~3 minecraft:lantern
setblock ~5 ~0 ~-19 minecraft:lantern
setblock ~5 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~5 minecraft:lantern
setblock ~19 ~0 ~5 minecraft:lantern
setblock ~7 ~0 ~-19 minecraft:lantern
setblock ~7 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~7 minecraft:lantern
setblock ~19 ~0 ~7 minecraft:lantern
setblock ~9 ~0 ~-19 minecraft:lantern
setblock ~9 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~9 minecraft:lantern
setblock ~19 ~0 ~9 minecraft:lantern
setblock ~11 ~0 ~-19 minecraft:lantern
setblock ~11 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~11 minecraft:lantern
setblock ~19 ~0 ~11 minecraft:lantern
setblock ~13 ~0 ~-19 minecraft:lantern
setblock ~13 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~13 minecraft:lantern
setblock ~19 ~0 ~13 minecraft:lantern
setblock ~15 ~0 ~-19 minecraft:lantern
setblock ~15 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~15 minecraft:lantern
setblock ~19 ~0 ~15 minecraft:lantern
setblock ~17 ~0 ~-19 minecraft:lantern
setblock ~17 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~17 minecraft:lantern
setblock ~19 ~0 ~17 minecraft:lantern
setblock ~19 ~0 ~-19 minecraft:lantern
setblock ~19 ~0 ~19 minecraft:lantern
setblock ~-19 ~0 ~19 minecraft:lantern
setblock ~19 ~0 ~19 minecraft:lantern
setblock ~-21 ~-1 ~-21 minecraft:black_concrete
setblock ~-21 ~0 ~-21 minecraft:lantern
setblock ~-21 ~-1 ~21 minecraft:black_concrete
setblock ~-21 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-21 minecraft:black_concrete
setblock ~-21 ~0 ~-21 minecraft:lantern
setblock ~21 ~-1 ~-21 minecraft:black_concrete
setblock ~21 ~0 ~-21 minecraft:lantern
setblock ~-19 ~-1 ~-21 minecraft:black_concrete
setblock ~-19 ~0 ~-21 minecraft:lantern
setblock ~-19 ~-1 ~21 minecraft:black_concrete
setblock ~-19 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-19 minecraft:black_concrete
setblock ~-21 ~0 ~-19 minecraft:lantern
setblock ~21 ~-1 ~-19 minecraft:black_concrete
setblock ~21 ~0 ~-19 minecraft:lantern
setblock ~-17 ~-1 ~-21 minecraft:black_concrete
setblock ~-17 ~0 ~-21 minecraft:lantern
setblock ~-17 ~-1 ~21 minecraft:black_concrete
setblock ~-17 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-17 minecraft:black_concrete
setblock ~-21 ~0 ~-17 minecraft:lantern
setblock ~21 ~-1 ~-17 minecraft:black_concrete
setblock ~21 ~0 ~-17 minecraft:lantern
setblock ~-15 ~-1 ~-21 minecraft:black_concrete
setblock ~-15 ~0 ~-21 minecraft:lantern
setblock ~-15 ~-1 ~21 minecraft:black_concrete
setblock ~-15 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-15 minecraft:black_concrete
setblock ~-21 ~0 ~-15 minecraft:lantern
setblock ~21 ~-1 ~-15 minecraft:black_concrete
setblock ~21 ~0 ~-15 minecraft:lantern
setblock ~-13 ~-1 ~-21 minecraft:black_concrete
setblock ~-13 ~0 ~-21 minecraft:lantern
setblock ~-13 ~-1 ~21 minecraft:black_concrete
setblock ~-13 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-13 minecraft:black_concrete
setblock ~-21 ~0 ~-13 minecraft:lantern
setblock ~21 ~-1 ~-13 minecraft:black_concrete
setblock ~21 ~0 ~-13 minecraft:lantern
setblock ~-11 ~-1 ~-21 minecraft:black_concrete
setblock ~-11 ~0 ~-21 minecraft:lantern
setblock ~-11 ~-1 ~21 minecraft:black_concrete
setblock ~-11 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-11 minecraft:black_concrete
setblock ~-21 ~0 ~-11 minecraft:lantern
setblock ~21 ~-1 ~-11 minecraft:black_concrete
setblock ~21 ~0 ~-11 minecraft:lantern
setblock ~-9 ~-1 ~-21 minecraft:black_concrete
setblock ~-9 ~0 ~-21 minecraft:lantern
setblock ~-9 ~-1 ~21 minecraft:black_concrete
setblock ~-9 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-9 minecraft:black_concrete
setblock ~-21 ~0 ~-9 minecraft:lantern
setblock ~21 ~-1 ~-9 minecraft:black_concrete
setblock ~21 ~0 ~-9 minecraft:lantern
setblock ~-7 ~-1 ~-21 minecraft:black_concrete
setblock ~-7 ~0 ~-21 minecraft:lantern
setblock ~-7 ~-1 ~21 minecraft:black_concrete
setblock ~-7 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-7 minecraft:black_concrete
setblock ~-21 ~0 ~-7 minecraft:lantern
setblock ~21 ~-1 ~-7 minecraft:black_concrete
setblock ~21 ~0 ~-7 minecraft:lantern
setblock ~-5 ~-1 ~-21 minecraft:black_concrete
setblock ~-5 ~0 ~-21 minecraft:lantern
setblock ~-5 ~-1 ~21 minecraft:black_concrete
setblock ~-5 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-5 minecraft:black_concrete
setblock ~-21 ~0 ~-5 minecraft:lantern
setblock ~21 ~-1 ~-5 minecraft:black_concrete
setblock ~21 ~0 ~-5 minecraft:lantern
setblock ~-3 ~-1 ~-21 minecraft:black_concrete
setblock ~-3 ~0 ~-21 minecraft:lantern
setblock ~-3 ~-1 ~21 minecraft:black_concrete
setblock ~-3 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-3 minecraft:black_concrete
setblock ~-21 ~0 ~-3 minecraft:lantern
setblock ~21 ~-1 ~-3 minecraft:black_concrete
setblock ~21 ~0 ~-3 minecraft:lantern
setblock ~-1 ~-1 ~-21 minecraft:black_concrete
setblock ~-1 ~0 ~-21 minecraft:lantern
setblock ~-1 ~-1 ~21 minecraft:black_concrete
setblock ~-1 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~-1 minecraft:black_concrete
setblock ~-21 ~0 ~-1 minecraft:lantern
setblock ~21 ~-1 ~-1 minecraft:black_concrete
setblock ~21 ~0 ~-1 minecraft:lantern
setblock ~1 ~-1 ~-21 minecraft:black_concrete
setblock ~1 ~0 ~-21 minecraft:lantern
setblock ~1 ~-1 ~21 minecraft:black_concrete
setblock ~1 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~1 minecraft:black_concrete
setblock ~-21 ~0 ~1 minecraft:lantern
setblock ~21 ~-1 ~1 minecraft:black_concrete
setblock ~21 ~0 ~1 minecraft:lantern
setblock ~3 ~-1 ~-21 minecraft:black_concrete
setblock ~3 ~0 ~-21 minecraft:lantern
setblock ~3 ~-1 ~21 minecraft:black_concrete
setblock ~3 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~3 minecraft:black_concrete
setblock ~-21 ~0 ~3 minecraft:lantern
setblock ~21 ~-1 ~3 minecraft:black_concrete
setblock ~21 ~0 ~3 minecraft:lantern
setblock ~5 ~-1 ~-21 minecraft:black_concrete
setblock ~5 ~0 ~-21 minecraft:lantern
setblock ~5 ~-1 ~21 minecraft:black_concrete
setblock ~5 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~5 minecraft:black_concrete
setblock ~-21 ~0 ~5 minecraft:lantern
setblock ~21 ~-1 ~5 minecraft:black_concrete
setblock ~21 ~0 ~5 minecraft:lantern
setblock ~7 ~-1 ~-21 minecraft:black_concrete
setblock ~7 ~0 ~-21 minecraft:lantern
setblock ~7 ~-1 ~21 minecraft:black_concrete
setblock ~7 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~7 minecraft:black_concrete
setblock ~-21 ~0 ~7 minecraft:lantern
setblock ~21 ~-1 ~7 minecraft:black_concrete
setblock ~21 ~0 ~7 minecraft:lantern
setblock ~9 ~-1 ~-21 minecraft:black_concrete
setblock ~9 ~0 ~-21 minecraft:lantern
setblock ~9 ~-1 ~21 minecraft:black_concrete
setblock ~9 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~9 minecraft:black_concrete
setblock ~-21 ~0 ~9 minecraft:lantern
setblock ~21 ~-1 ~9 minecraft:black_concrete
setblock ~21 ~0 ~9 minecraft:lantern
setblock ~11 ~-1 ~-21 minecraft:black_concrete
setblock ~11 ~0 ~-21 minecraft:lantern
setblock ~11 ~-1 ~21 minecraft:black_concrete
setblock ~11 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~11 minecraft:black_concrete
setblock ~-21 ~0 ~11 minecraft:lantern
setblock ~21 ~-1 ~11 minecraft:black_concrete
setblock ~21 ~0 ~11 minecraft:lantern
setblock ~13 ~-1 ~-21 minecraft:black_concrete
setblock ~13 ~0 ~-21 minecraft:lantern
setblock ~13 ~-1 ~21 minecraft:black_concrete
setblock ~13 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~13 minecraft:black_concrete
setblock ~-21 ~0 ~13 minecraft:lantern
setblock ~21 ~-1 ~13 minecraft:black_concrete
setblock ~21 ~0 ~13 minecraft:lantern
setblock ~15 ~-1 ~-21 minecraft:black_concrete
setblock ~15 ~0 ~-21 minecraft:lantern
setblock ~15 ~-1 ~21 minecraft:black_concrete
setblock ~15 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~15 minecraft:black_concrete
setblock ~-21 ~0 ~15 minecraft:lantern
setblock ~21 ~-1 ~15 minecraft:black_concrete
setblock ~21 ~0 ~15 minecraft:lantern
setblock ~17 ~-1 ~-21 minecraft:black_concrete
setblock ~17 ~0 ~-21 minecraft:lantern
setblock ~17 ~-1 ~21 minecraft:black_concrete
setblock ~17 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~17 minecraft:black_concrete
setblock ~-21 ~0 ~17 minecraft:lantern
setblock ~21 ~-1 ~17 minecraft:black_concrete
setblock ~21 ~0 ~17 minecraft:lantern
setblock ~19 ~-1 ~-21 minecraft:black_concrete
setblock ~19 ~0 ~-21 minecraft:lantern
setblock ~19 ~-1 ~21 minecraft:black_concrete
setblock ~19 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~19 minecraft:black_concrete
setblock ~-21 ~0 ~19 minecraft:lantern
setblock ~21 ~-1 ~19 minecraft:black_concrete
setblock ~21 ~0 ~19 minecraft:lantern
setblock ~21 ~-1 ~-21 minecraft:black_concrete
setblock ~21 ~0 ~-21 minecraft:lantern
setblock ~21 ~-1 ~21 minecraft:black_concrete
setblock ~21 ~0 ~21 minecraft:lantern
setblock ~-21 ~-1 ~21 minecraft:black_concrete
setblock ~-21 ~0 ~21 minecraft:lantern
setblock ~21 ~-1 ~21 minecraft:black_concrete
setblock ~21 ~0 ~21 minecraft:lantern
setblock ~-18 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~-18 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~-14 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~-10 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~-6 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~-2 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~2 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~6 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~10 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~14 ~39 ~18 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~-18 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~-14 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~-10 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~-6 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~-2 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~2 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~6 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~10 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~14 minecraft:lantern[hanging=true]
setblock ~18 ~39 ~18 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
