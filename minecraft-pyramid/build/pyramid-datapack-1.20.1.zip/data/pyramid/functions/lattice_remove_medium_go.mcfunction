execute as @e[type=marker,tag=lat_medium_rm,limit=1] at @s run function pyramid:lattice_remove_medium_do
execute as @e[type=marker,tag=lat_medium_rm,limit=1] at @s run forceload remove ~-66 ~-66 ~66 ~66
kill @e[type=marker,tag=lat_medium_rm]
tellraw @a {"text":"Решётка удалена","color":"yellow"}
