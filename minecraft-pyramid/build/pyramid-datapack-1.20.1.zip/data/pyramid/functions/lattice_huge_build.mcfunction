# Решётка 224x224x224, угол (~-112, ~0, ~-112)
fill ~-112 ~-1 ~-112 ~-81 ~-1 ~-81 minecraft:black_concrete
fill ~-112 ~0 ~-112 ~-81 ~31 ~-81 minecraft:air
fill ~-112 ~32 ~-112 ~-81 ~63 ~-81 minecraft:air
fill ~-112 ~64 ~-112 ~-81 ~95 ~-81 minecraft:air
fill ~-112 ~96 ~-112 ~-81 ~127 ~-81 minecraft:air
fill ~-112 ~128 ~-112 ~-81 ~159 ~-81 minecraft:air
fill ~-112 ~160 ~-112 ~-81 ~191 ~-81 minecraft:air
fill ~-112 ~192 ~-112 ~-81 ~223 ~-81 minecraft:air
fill ~-112 ~-1 ~-80 ~-81 ~-1 ~-49 minecraft:black_concrete
fill ~-112 ~0 ~-80 ~-81 ~31 ~-49 minecraft:air
fill ~-112 ~32 ~-80 ~-81 ~63 ~-49 minecraft:air
fill ~-112 ~64 ~-80 ~-81 ~95 ~-49 minecraft:air
fill ~-112 ~96 ~-80 ~-81 ~127 ~-49 minecraft:air
fill ~-112 ~128 ~-80 ~-81 ~159 ~-49 minecraft:air
fill ~-112 ~160 ~-80 ~-81 ~191 ~-49 minecraft:air
fill ~-112 ~192 ~-80 ~-81 ~223 ~-49 minecraft:air
fill ~-112 ~-1 ~-48 ~-81 ~-1 ~-17 minecraft:black_concrete
fill ~-112 ~0 ~-48 ~-81 ~31 ~-17 minecraft:air
fill ~-112 ~32 ~-48 ~-81 ~63 ~-17 minecraft:air
fill ~-112 ~64 ~-48 ~-81 ~95 ~-17 minecraft:air
fill ~-112 ~96 ~-48 ~-81 ~127 ~-17 minecraft:air
fill ~-112 ~128 ~-48 ~-81 ~159 ~-17 minecraft:air
fill ~-112 ~160 ~-48 ~-81 ~191 ~-17 minecraft:air
fill ~-112 ~192 ~-48 ~-81 ~223 ~-17 minecraft:air
fill ~-112 ~-1 ~-16 ~-81 ~-1 ~15 minecraft:black_concrete
fill ~-112 ~0 ~-16 ~-81 ~31 ~15 minecraft:air
fill ~-112 ~32 ~-16 ~-81 ~63 ~15 minecraft:air
fill ~-112 ~64 ~-16 ~-81 ~95 ~15 minecraft:air
fill ~-112 ~96 ~-16 ~-81 ~127 ~15 minecraft:air
fill ~-112 ~128 ~-16 ~-81 ~159 ~15 minecraft:air
fill ~-112 ~160 ~-16 ~-81 ~191 ~15 minecraft:air
fill ~-112 ~192 ~-16 ~-81 ~223 ~15 minecraft:air
fill ~-112 ~-1 ~16 ~-81 ~-1 ~47 minecraft:black_concrete
fill ~-112 ~0 ~16 ~-81 ~31 ~47 minecraft:air
fill ~-112 ~32 ~16 ~-81 ~63 ~47 minecraft:air
fill ~-112 ~64 ~16 ~-81 ~95 ~47 minecraft:air
fill ~-112 ~96 ~16 ~-81 ~127 ~47 minecraft:air
fill ~-112 ~128 ~16 ~-81 ~159 ~47 minecraft:air
fill ~-112 ~160 ~16 ~-81 ~191 ~47 minecraft:air
fill ~-112 ~192 ~16 ~-81 ~223 ~47 minecraft:air
fill ~-112 ~-1 ~48 ~-81 ~-1 ~79 minecraft:black_concrete
fill ~-112 ~0 ~48 ~-81 ~31 ~79 minecraft:air
fill ~-112 ~32 ~48 ~-81 ~63 ~79 minecraft:air
fill ~-112 ~64 ~48 ~-81 ~95 ~79 minecraft:air
fill ~-112 ~96 ~48 ~-81 ~127 ~79 minecraft:air
fill ~-112 ~128 ~48 ~-81 ~159 ~79 minecraft:air
fill ~-112 ~160 ~48 ~-81 ~191 ~79 minecraft:air
fill ~-112 ~192 ~48 ~-81 ~223 ~79 minecraft:air
fill ~-112 ~-1 ~80 ~-81 ~-1 ~111 minecraft:black_concrete
fill ~-112 ~0 ~80 ~-81 ~31 ~111 minecraft:air
fill ~-112 ~32 ~80 ~-81 ~63 ~111 minecraft:air
fill ~-112 ~64 ~80 ~-81 ~95 ~111 minecraft:air
fill ~-112 ~96 ~80 ~-81 ~127 ~111 minecraft:air
fill ~-112 ~128 ~80 ~-81 ~159 ~111 minecraft:air
fill ~-112 ~160 ~80 ~-81 ~191 ~111 minecraft:air
fill ~-112 ~192 ~80 ~-81 ~223 ~111 minecraft:air
fill ~-80 ~-1 ~-112 ~-49 ~-1 ~-81 minecraft:black_concrete
fill ~-80 ~0 ~-112 ~-49 ~31 ~-81 minecraft:air
fill ~-80 ~32 ~-112 ~-49 ~63 ~-81 minecraft:air
fill ~-80 ~64 ~-112 ~-49 ~95 ~-81 minecraft:air
fill ~-80 ~96 ~-112 ~-49 ~127 ~-81 minecraft:air
fill ~-80 ~128 ~-112 ~-49 ~159 ~-81 minecraft:air
fill ~-80 ~160 ~-112 ~-49 ~191 ~-81 minecraft:air
fill ~-80 ~192 ~-112 ~-49 ~223 ~-81 minecraft:air
fill ~-80 ~-1 ~-80 ~-49 ~-1 ~-49 minecraft:black_concrete
fill ~-80 ~0 ~-80 ~-49 ~31 ~-49 minecraft:air
fill ~-80 ~32 ~-80 ~-49 ~63 ~-49 minecraft:air
fill ~-80 ~64 ~-80 ~-49 ~95 ~-49 minecraft:air
fill ~-80 ~96 ~-80 ~-49 ~127 ~-49 minecraft:air
fill ~-80 ~128 ~-80 ~-49 ~159 ~-49 minecraft:air
fill ~-80 ~160 ~-80 ~-49 ~191 ~-49 minecraft:air
fill ~-80 ~192 ~-80 ~-49 ~223 ~-49 minecraft:air
fill ~-80 ~-1 ~-48 ~-49 ~-1 ~-17 minecraft:black_concrete
fill ~-80 ~0 ~-48 ~-49 ~31 ~-17 minecraft:air
fill ~-80 ~32 ~-48 ~-49 ~63 ~-17 minecraft:air
fill ~-80 ~64 ~-48 ~-49 ~95 ~-17 minecraft:air
fill ~-80 ~96 ~-48 ~-49 ~127 ~-17 minecraft:air
fill ~-80 ~128 ~-48 ~-49 ~159 ~-17 minecraft:air
fill ~-80 ~160 ~-48 ~-49 ~191 ~-17 minecraft:air
fill ~-80 ~192 ~-48 ~-49 ~223 ~-17 minecraft:air
fill ~-80 ~-1 ~-16 ~-49 ~-1 ~15 minecraft:black_concrete
fill ~-80 ~0 ~-16 ~-49 ~31 ~15 minecraft:air
fill ~-80 ~32 ~-16 ~-49 ~63 ~15 minecraft:air
fill ~-80 ~64 ~-16 ~-49 ~95 ~15 minecraft:air
fill ~-80 ~96 ~-16 ~-49 ~127 ~15 minecraft:air
fill ~-80 ~128 ~-16 ~-49 ~159 ~15 minecraft:air
fill ~-80 ~160 ~-16 ~-49 ~191 ~15 minecraft:air
fill ~-80 ~192 ~-16 ~-49 ~223 ~15 minecraft:air
fill ~-80 ~-1 ~16 ~-49 ~-1 ~47 minecraft:black_concrete
fill ~-80 ~0 ~16 ~-49 ~31 ~47 minecraft:air
fill ~-80 ~32 ~16 ~-49 ~63 ~47 minecraft:air
fill ~-80 ~64 ~16 ~-49 ~95 ~47 minecraft:air
fill ~-80 ~96 ~16 ~-49 ~127 ~47 minecraft:air
fill ~-80 ~128 ~16 ~-49 ~159 ~47 minecraft:air
fill ~-80 ~160 ~16 ~-49 ~191 ~47 minecraft:air
fill ~-80 ~192 ~16 ~-49 ~223 ~47 minecraft:air
fill ~-80 ~-1 ~48 ~-49 ~-1 ~79 minecraft:black_concrete
fill ~-80 ~0 ~48 ~-49 ~31 ~79 minecraft:air
fill ~-80 ~32 ~48 ~-49 ~63 ~79 minecraft:air
fill ~-80 ~64 ~48 ~-49 ~95 ~79 minecraft:air
fill ~-80 ~96 ~48 ~-49 ~127 ~79 minecraft:air
fill ~-80 ~128 ~48 ~-49 ~159 ~79 minecraft:air
fill ~-80 ~160 ~48 ~-49 ~191 ~79 minecraft:air
fill ~-80 ~192 ~48 ~-49 ~223 ~79 minecraft:air
fill ~-80 ~-1 ~80 ~-49 ~-1 ~111 minecraft:black_concrete
fill ~-80 ~0 ~80 ~-49 ~31 ~111 minecraft:air
fill ~-80 ~32 ~80 ~-49 ~63 ~111 minecraft:air
fill ~-80 ~64 ~80 ~-49 ~95 ~111 minecraft:air
fill ~-80 ~96 ~80 ~-49 ~127 ~111 minecraft:air
fill ~-80 ~128 ~80 ~-49 ~159 ~111 minecraft:air
fill ~-80 ~160 ~80 ~-49 ~191 ~111 minecraft:air
fill ~-80 ~192 ~80 ~-49 ~223 ~111 minecraft:air
fill ~-48 ~-1 ~-112 ~-17 ~-1 ~-81 minecraft:black_concrete
fill ~-48 ~0 ~-112 ~-17 ~31 ~-81 minecraft:air
fill ~-48 ~32 ~-112 ~-17 ~63 ~-81 minecraft:air
fill ~-48 ~64 ~-112 ~-17 ~95 ~-81 minecraft:air
fill ~-48 ~96 ~-112 ~-17 ~127 ~-81 minecraft:air
fill ~-48 ~128 ~-112 ~-17 ~159 ~-81 minecraft:air
fill ~-48 ~160 ~-112 ~-17 ~191 ~-81 minecraft:air
fill ~-48 ~192 ~-112 ~-17 ~223 ~-81 minecraft:air
fill ~-48 ~-1 ~-80 ~-17 ~-1 ~-49 minecraft:black_concrete
fill ~-48 ~0 ~-80 ~-17 ~31 ~-49 minecraft:air
fill ~-48 ~32 ~-80 ~-17 ~63 ~-49 minecraft:air
fill ~-48 ~64 ~-80 ~-17 ~95 ~-49 minecraft:air
fill ~-48 ~96 ~-80 ~-17 ~127 ~-49 minecraft:air
fill ~-48 ~128 ~-80 ~-17 ~159 ~-49 minecraft:air
fill ~-48 ~160 ~-80 ~-17 ~191 ~-49 minecraft:air
fill ~-48 ~192 ~-80 ~-17 ~223 ~-49 minecraft:air
fill ~-48 ~-1 ~-48 ~-17 ~-1 ~-17 minecraft:black_concrete
fill ~-48 ~0 ~-48 ~-17 ~31 ~-17 minecraft:air
fill ~-48 ~32 ~-48 ~-17 ~63 ~-17 minecraft:air
fill ~-48 ~64 ~-48 ~-17 ~95 ~-17 minecraft:air
fill ~-48 ~96 ~-48 ~-17 ~127 ~-17 minecraft:air
fill ~-48 ~128 ~-48 ~-17 ~159 ~-17 minecraft:air
fill ~-48 ~160 ~-48 ~-17 ~191 ~-17 minecraft:air
fill ~-48 ~192 ~-48 ~-17 ~223 ~-17 minecraft:air
fill ~-48 ~-1 ~-16 ~-17 ~-1 ~15 minecraft:black_concrete
fill ~-48 ~0 ~-16 ~-17 ~31 ~15 minecraft:air
fill ~-48 ~32 ~-16 ~-17 ~63 ~15 minecraft:air
fill ~-48 ~64 ~-16 ~-17 ~95 ~15 minecraft:air
fill ~-48 ~96 ~-16 ~-17 ~127 ~15 minecraft:air
fill ~-48 ~128 ~-16 ~-17 ~159 ~15 minecraft:air
fill ~-48 ~160 ~-16 ~-17 ~191 ~15 minecraft:air
fill ~-48 ~192 ~-16 ~-17 ~223 ~15 minecraft:air
fill ~-48 ~-1 ~16 ~-17 ~-1 ~47 minecraft:black_concrete
fill ~-48 ~0 ~16 ~-17 ~31 ~47 minecraft:air
fill ~-48 ~32 ~16 ~-17 ~63 ~47 minecraft:air
fill ~-48 ~64 ~16 ~-17 ~95 ~47 minecraft:air
fill ~-48 ~96 ~16 ~-17 ~127 ~47 minecraft:air
fill ~-48 ~128 ~16 ~-17 ~159 ~47 minecraft:air
fill ~-48 ~160 ~16 ~-17 ~191 ~47 minecraft:air
fill ~-48 ~192 ~16 ~-17 ~223 ~47 minecraft:air
fill ~-48 ~-1 ~48 ~-17 ~-1 ~79 minecraft:black_concrete
fill ~-48 ~0 ~48 ~-17 ~31 ~79 minecraft:air
fill ~-48 ~32 ~48 ~-17 ~63 ~79 minecraft:air
fill ~-48 ~64 ~48 ~-17 ~95 ~79 minecraft:air
fill ~-48 ~96 ~48 ~-17 ~127 ~79 minecraft:air
fill ~-48 ~128 ~48 ~-17 ~159 ~79 minecraft:air
fill ~-48 ~160 ~48 ~-17 ~191 ~79 minecraft:air
fill ~-48 ~192 ~48 ~-17 ~223 ~79 minecraft:air
fill ~-48 ~-1 ~80 ~-17 ~-1 ~111 minecraft:black_concrete
fill ~-48 ~0 ~80 ~-17 ~31 ~111 minecraft:air
fill ~-48 ~32 ~80 ~-17 ~63 ~111 minecraft:air
fill ~-48 ~64 ~80 ~-17 ~95 ~111 minecraft:air
fill ~-48 ~96 ~80 ~-17 ~127 ~111 minecraft:air
fill ~-48 ~128 ~80 ~-17 ~159 ~111 minecraft:air
fill ~-48 ~160 ~80 ~-17 ~191 ~111 minecraft:air
fill ~-48 ~192 ~80 ~-17 ~223 ~111 minecraft:air
fill ~-16 ~-1 ~-112 ~15 ~-1 ~-81 minecraft:black_concrete
fill ~-16 ~0 ~-112 ~15 ~31 ~-81 minecraft:air
fill ~-16 ~32 ~-112 ~15 ~63 ~-81 minecraft:air
fill ~-16 ~64 ~-112 ~15 ~95 ~-81 minecraft:air
fill ~-16 ~96 ~-112 ~15 ~127 ~-81 minecraft:air
fill ~-16 ~128 ~-112 ~15 ~159 ~-81 minecraft:air
fill ~-16 ~160 ~-112 ~15 ~191 ~-81 minecraft:air
fill ~-16 ~192 ~-112 ~15 ~223 ~-81 minecraft:air
fill ~-16 ~-1 ~-80 ~15 ~-1 ~-49 minecraft:black_concrete
fill ~-16 ~0 ~-80 ~15 ~31 ~-49 minecraft:air
fill ~-16 ~32 ~-80 ~15 ~63 ~-49 minecraft:air
fill ~-16 ~64 ~-80 ~15 ~95 ~-49 minecraft:air
fill ~-16 ~96 ~-80 ~15 ~127 ~-49 minecraft:air
fill ~-16 ~128 ~-80 ~15 ~159 ~-49 minecraft:air
fill ~-16 ~160 ~-80 ~15 ~191 ~-49 minecraft:air
fill ~-16 ~192 ~-80 ~15 ~223 ~-49 minecraft:air
fill ~-16 ~-1 ~-48 ~15 ~-1 ~-17 minecraft:black_concrete
fill ~-16 ~0 ~-48 ~15 ~31 ~-17 minecraft:air
fill ~-16 ~32 ~-48 ~15 ~63 ~-17 minecraft:air
fill ~-16 ~64 ~-48 ~15 ~95 ~-17 minecraft:air
fill ~-16 ~96 ~-48 ~15 ~127 ~-17 minecraft:air
fill ~-16 ~128 ~-48 ~15 ~159 ~-17 minecraft:air
fill ~-16 ~160 ~-48 ~15 ~191 ~-17 minecraft:air
fill ~-16 ~192 ~-48 ~15 ~223 ~-17 minecraft:air
fill ~-16 ~-1 ~-16 ~15 ~-1 ~15 minecraft:black_concrete
fill ~-16 ~0 ~-16 ~15 ~31 ~15 minecraft:air
fill ~-16 ~32 ~-16 ~15 ~63 ~15 minecraft:air
fill ~-16 ~64 ~-16 ~15 ~95 ~15 minecraft:air
fill ~-16 ~96 ~-16 ~15 ~127 ~15 minecraft:air
fill ~-16 ~128 ~-16 ~15 ~159 ~15 minecraft:air
fill ~-16 ~160 ~-16 ~15 ~191 ~15 minecraft:air
fill ~-16 ~192 ~-16 ~15 ~223 ~15 minecraft:air
fill ~-16 ~-1 ~16 ~15 ~-1 ~47 minecraft:black_concrete
fill ~-16 ~0 ~16 ~15 ~31 ~47 minecraft:air
fill ~-16 ~32 ~16 ~15 ~63 ~47 minecraft:air
fill ~-16 ~64 ~16 ~15 ~95 ~47 minecraft:air
fill ~-16 ~96 ~16 ~15 ~127 ~47 minecraft:air
fill ~-16 ~128 ~16 ~15 ~159 ~47 minecraft:air
fill ~-16 ~160 ~16 ~15 ~191 ~47 minecraft:air
fill ~-16 ~192 ~16 ~15 ~223 ~47 minecraft:air
fill ~-16 ~-1 ~48 ~15 ~-1 ~79 minecraft:black_concrete
fill ~-16 ~0 ~48 ~15 ~31 ~79 minecraft:air
fill ~-16 ~32 ~48 ~15 ~63 ~79 minecraft:air
fill ~-16 ~64 ~48 ~15 ~95 ~79 minecraft:air
fill ~-16 ~96 ~48 ~15 ~127 ~79 minecraft:air
fill ~-16 ~128 ~48 ~15 ~159 ~79 minecraft:air
fill ~-16 ~160 ~48 ~15 ~191 ~79 minecraft:air
fill ~-16 ~192 ~48 ~15 ~223 ~79 minecraft:air
fill ~-16 ~-1 ~80 ~15 ~-1 ~111 minecraft:black_concrete
fill ~-16 ~0 ~80 ~15 ~31 ~111 minecraft:air
fill ~-16 ~32 ~80 ~15 ~63 ~111 minecraft:air
fill ~-16 ~64 ~80 ~15 ~95 ~111 minecraft:air
fill ~-16 ~96 ~80 ~15 ~127 ~111 minecraft:air
fill ~-16 ~128 ~80 ~15 ~159 ~111 minecraft:air
fill ~-16 ~160 ~80 ~15 ~191 ~111 minecraft:air
fill ~-16 ~192 ~80 ~15 ~223 ~111 minecraft:air
fill ~16 ~-1 ~-112 ~47 ~-1 ~-81 minecraft:black_concrete
fill ~16 ~0 ~-112 ~47 ~31 ~-81 minecraft:air
fill ~16 ~32 ~-112 ~47 ~63 ~-81 minecraft:air
fill ~16 ~64 ~-112 ~47 ~95 ~-81 minecraft:air
fill ~16 ~96 ~-112 ~47 ~127 ~-81 minecraft:air
fill ~16 ~128 ~-112 ~47 ~159 ~-81 minecraft:air
fill ~16 ~160 ~-112 ~47 ~191 ~-81 minecraft:air
fill ~16 ~192 ~-112 ~47 ~223 ~-81 minecraft:air
fill ~16 ~-1 ~-80 ~47 ~-1 ~-49 minecraft:black_concrete
fill ~16 ~0 ~-80 ~47 ~31 ~-49 minecraft:air
fill ~16 ~32 ~-80 ~47 ~63 ~-49 minecraft:air
fill ~16 ~64 ~-80 ~47 ~95 ~-49 minecraft:air
fill ~16 ~96 ~-80 ~47 ~127 ~-49 minecraft:air
fill ~16 ~128 ~-80 ~47 ~159 ~-49 minecraft:air
fill ~16 ~160 ~-80 ~47 ~191 ~-49 minecraft:air
fill ~16 ~192 ~-80 ~47 ~223 ~-49 minecraft:air
fill ~16 ~-1 ~-48 ~47 ~-1 ~-17 minecraft:black_concrete
fill ~16 ~0 ~-48 ~47 ~31 ~-17 minecraft:air
fill ~16 ~32 ~-48 ~47 ~63 ~-17 minecraft:air
fill ~16 ~64 ~-48 ~47 ~95 ~-17 minecraft:air
fill ~16 ~96 ~-48 ~47 ~127 ~-17 minecraft:air
fill ~16 ~128 ~-48 ~47 ~159 ~-17 minecraft:air
fill ~16 ~160 ~-48 ~47 ~191 ~-17 minecraft:air
fill ~16 ~192 ~-48 ~47 ~223 ~-17 minecraft:air
fill ~16 ~-1 ~-16 ~47 ~-1 ~15 minecraft:black_concrete
fill ~16 ~0 ~-16 ~47 ~31 ~15 minecraft:air
fill ~16 ~32 ~-16 ~47 ~63 ~15 minecraft:air
fill ~16 ~64 ~-16 ~47 ~95 ~15 minecraft:air
fill ~16 ~96 ~-16 ~47 ~127 ~15 minecraft:air
fill ~16 ~128 ~-16 ~47 ~159 ~15 minecraft:air
fill ~16 ~160 ~-16 ~47 ~191 ~15 minecraft:air
fill ~16 ~192 ~-16 ~47 ~223 ~15 minecraft:air
fill ~16 ~-1 ~16 ~47 ~-1 ~47 minecraft:black_concrete
fill ~16 ~0 ~16 ~47 ~31 ~47 minecraft:air
fill ~16 ~32 ~16 ~47 ~63 ~47 minecraft:air
fill ~16 ~64 ~16 ~47 ~95 ~47 minecraft:air
fill ~16 ~96 ~16 ~47 ~127 ~47 minecraft:air
fill ~16 ~128 ~16 ~47 ~159 ~47 minecraft:air
fill ~16 ~160 ~16 ~47 ~191 ~47 minecraft:air
fill ~16 ~192 ~16 ~47 ~223 ~47 minecraft:air
fill ~16 ~-1 ~48 ~47 ~-1 ~79 minecraft:black_concrete
fill ~16 ~0 ~48 ~47 ~31 ~79 minecraft:air
fill ~16 ~32 ~48 ~47 ~63 ~79 minecraft:air
fill ~16 ~64 ~48 ~47 ~95 ~79 minecraft:air
fill ~16 ~96 ~48 ~47 ~127 ~79 minecraft:air
fill ~16 ~128 ~48 ~47 ~159 ~79 minecraft:air
fill ~16 ~160 ~48 ~47 ~191 ~79 minecraft:air
fill ~16 ~192 ~48 ~47 ~223 ~79 minecraft:air
fill ~16 ~-1 ~80 ~47 ~-1 ~111 minecraft:black_concrete
fill ~16 ~0 ~80 ~47 ~31 ~111 minecraft:air
fill ~16 ~32 ~80 ~47 ~63 ~111 minecraft:air
fill ~16 ~64 ~80 ~47 ~95 ~111 minecraft:air
fill ~16 ~96 ~80 ~47 ~127 ~111 minecraft:air
fill ~16 ~128 ~80 ~47 ~159 ~111 minecraft:air
fill ~16 ~160 ~80 ~47 ~191 ~111 minecraft:air
fill ~16 ~192 ~80 ~47 ~223 ~111 minecraft:air
fill ~48 ~-1 ~-112 ~79 ~-1 ~-81 minecraft:black_concrete
fill ~48 ~0 ~-112 ~79 ~31 ~-81 minecraft:air
fill ~48 ~32 ~-112 ~79 ~63 ~-81 minecraft:air
fill ~48 ~64 ~-112 ~79 ~95 ~-81 minecraft:air
fill ~48 ~96 ~-112 ~79 ~127 ~-81 minecraft:air
fill ~48 ~128 ~-112 ~79 ~159 ~-81 minecraft:air
fill ~48 ~160 ~-112 ~79 ~191 ~-81 minecraft:air
fill ~48 ~192 ~-112 ~79 ~223 ~-81 minecraft:air
fill ~48 ~-1 ~-80 ~79 ~-1 ~-49 minecraft:black_concrete
fill ~48 ~0 ~-80 ~79 ~31 ~-49 minecraft:air
fill ~48 ~32 ~-80 ~79 ~63 ~-49 minecraft:air
fill ~48 ~64 ~-80 ~79 ~95 ~-49 minecraft:air
fill ~48 ~96 ~-80 ~79 ~127 ~-49 minecraft:air
fill ~48 ~128 ~-80 ~79 ~159 ~-49 minecraft:air
fill ~48 ~160 ~-80 ~79 ~191 ~-49 minecraft:air
fill ~48 ~192 ~-80 ~79 ~223 ~-49 minecraft:air
fill ~48 ~-1 ~-48 ~79 ~-1 ~-17 minecraft:black_concrete
fill ~48 ~0 ~-48 ~79 ~31 ~-17 minecraft:air
fill ~48 ~32 ~-48 ~79 ~63 ~-17 minecraft:air
fill ~48 ~64 ~-48 ~79 ~95 ~-17 minecraft:air
fill ~48 ~96 ~-48 ~79 ~127 ~-17 minecraft:air
fill ~48 ~128 ~-48 ~79 ~159 ~-17 minecraft:air
fill ~48 ~160 ~-48 ~79 ~191 ~-17 minecraft:air
fill ~48 ~192 ~-48 ~79 ~223 ~-17 minecraft:air
fill ~48 ~-1 ~-16 ~79 ~-1 ~15 minecraft:black_concrete
fill ~48 ~0 ~-16 ~79 ~31 ~15 minecraft:air
fill ~48 ~32 ~-16 ~79 ~63 ~15 minecraft:air
fill ~48 ~64 ~-16 ~79 ~95 ~15 minecraft:air
fill ~48 ~96 ~-16 ~79 ~127 ~15 minecraft:air
fill ~48 ~128 ~-16 ~79 ~159 ~15 minecraft:air
fill ~48 ~160 ~-16 ~79 ~191 ~15 minecraft:air
fill ~48 ~192 ~-16 ~79 ~223 ~15 minecraft:air
fill ~48 ~-1 ~16 ~79 ~-1 ~47 minecraft:black_concrete
fill ~48 ~0 ~16 ~79 ~31 ~47 minecraft:air
fill ~48 ~32 ~16 ~79 ~63 ~47 minecraft:air
fill ~48 ~64 ~16 ~79 ~95 ~47 minecraft:air
fill ~48 ~96 ~16 ~79 ~127 ~47 minecraft:air
fill ~48 ~128 ~16 ~79 ~159 ~47 minecraft:air
fill ~48 ~160 ~16 ~79 ~191 ~47 minecraft:air
fill ~48 ~192 ~16 ~79 ~223 ~47 minecraft:air
fill ~48 ~-1 ~48 ~79 ~-1 ~79 minecraft:black_concrete
fill ~48 ~0 ~48 ~79 ~31 ~79 minecraft:air
fill ~48 ~32 ~48 ~79 ~63 ~79 minecraft:air
fill ~48 ~64 ~48 ~79 ~95 ~79 minecraft:air
fill ~48 ~96 ~48 ~79 ~127 ~79 minecraft:air
fill ~48 ~128 ~48 ~79 ~159 ~79 minecraft:air
fill ~48 ~160 ~48 ~79 ~191 ~79 minecraft:air
fill ~48 ~192 ~48 ~79 ~223 ~79 minecraft:air
fill ~48 ~-1 ~80 ~79 ~-1 ~111 minecraft:black_concrete
fill ~48 ~0 ~80 ~79 ~31 ~111 minecraft:air
fill ~48 ~32 ~80 ~79 ~63 ~111 minecraft:air
fill ~48 ~64 ~80 ~79 ~95 ~111 minecraft:air
fill ~48 ~96 ~80 ~79 ~127 ~111 minecraft:air
fill ~48 ~128 ~80 ~79 ~159 ~111 minecraft:air
fill ~48 ~160 ~80 ~79 ~191 ~111 minecraft:air
fill ~48 ~192 ~80 ~79 ~223 ~111 minecraft:air
fill ~80 ~-1 ~-112 ~111 ~-1 ~-81 minecraft:black_concrete
fill ~80 ~0 ~-112 ~111 ~31 ~-81 minecraft:air
fill ~80 ~32 ~-112 ~111 ~63 ~-81 minecraft:air
fill ~80 ~64 ~-112 ~111 ~95 ~-81 minecraft:air
fill ~80 ~96 ~-112 ~111 ~127 ~-81 minecraft:air
fill ~80 ~128 ~-112 ~111 ~159 ~-81 minecraft:air
fill ~80 ~160 ~-112 ~111 ~191 ~-81 minecraft:air
fill ~80 ~192 ~-112 ~111 ~223 ~-81 minecraft:air
fill ~80 ~-1 ~-80 ~111 ~-1 ~-49 minecraft:black_concrete
fill ~80 ~0 ~-80 ~111 ~31 ~-49 minecraft:air
fill ~80 ~32 ~-80 ~111 ~63 ~-49 minecraft:air
fill ~80 ~64 ~-80 ~111 ~95 ~-49 minecraft:air
fill ~80 ~96 ~-80 ~111 ~127 ~-49 minecraft:air
fill ~80 ~128 ~-80 ~111 ~159 ~-49 minecraft:air
fill ~80 ~160 ~-80 ~111 ~191 ~-49 minecraft:air
fill ~80 ~192 ~-80 ~111 ~223 ~-49 minecraft:air
fill ~80 ~-1 ~-48 ~111 ~-1 ~-17 minecraft:black_concrete
fill ~80 ~0 ~-48 ~111 ~31 ~-17 minecraft:air
fill ~80 ~32 ~-48 ~111 ~63 ~-17 minecraft:air
fill ~80 ~64 ~-48 ~111 ~95 ~-17 minecraft:air
fill ~80 ~96 ~-48 ~111 ~127 ~-17 minecraft:air
fill ~80 ~128 ~-48 ~111 ~159 ~-17 minecraft:air
fill ~80 ~160 ~-48 ~111 ~191 ~-17 minecraft:air
fill ~80 ~192 ~-48 ~111 ~223 ~-17 minecraft:air
fill ~80 ~-1 ~-16 ~111 ~-1 ~15 minecraft:black_concrete
fill ~80 ~0 ~-16 ~111 ~31 ~15 minecraft:air
fill ~80 ~32 ~-16 ~111 ~63 ~15 minecraft:air
fill ~80 ~64 ~-16 ~111 ~95 ~15 minecraft:air
fill ~80 ~96 ~-16 ~111 ~127 ~15 minecraft:air
fill ~80 ~128 ~-16 ~111 ~159 ~15 minecraft:air
fill ~80 ~160 ~-16 ~111 ~191 ~15 minecraft:air
fill ~80 ~192 ~-16 ~111 ~223 ~15 minecraft:air
fill ~80 ~-1 ~16 ~111 ~-1 ~47 minecraft:black_concrete
fill ~80 ~0 ~16 ~111 ~31 ~47 minecraft:air
fill ~80 ~32 ~16 ~111 ~63 ~47 minecraft:air
fill ~80 ~64 ~16 ~111 ~95 ~47 minecraft:air
fill ~80 ~96 ~16 ~111 ~127 ~47 minecraft:air
fill ~80 ~128 ~16 ~111 ~159 ~47 minecraft:air
fill ~80 ~160 ~16 ~111 ~191 ~47 minecraft:air
fill ~80 ~192 ~16 ~111 ~223 ~47 minecraft:air
fill ~80 ~-1 ~48 ~111 ~-1 ~79 minecraft:black_concrete
fill ~80 ~0 ~48 ~111 ~31 ~79 minecraft:air
fill ~80 ~32 ~48 ~111 ~63 ~79 minecraft:air
fill ~80 ~64 ~48 ~111 ~95 ~79 minecraft:air
fill ~80 ~96 ~48 ~111 ~127 ~79 minecraft:air
fill ~80 ~128 ~48 ~111 ~159 ~79 minecraft:air
fill ~80 ~160 ~48 ~111 ~191 ~79 minecraft:air
fill ~80 ~192 ~48 ~111 ~223 ~79 minecraft:air
fill ~80 ~-1 ~80 ~111 ~-1 ~111 minecraft:black_concrete
fill ~80 ~0 ~80 ~111 ~31 ~111 minecraft:air
fill ~80 ~32 ~80 ~111 ~63 ~111 minecraft:air
fill ~80 ~64 ~80 ~111 ~95 ~111 minecraft:air
fill ~80 ~96 ~80 ~111 ~127 ~111 minecraft:air
fill ~80 ~128 ~80 ~111 ~159 ~111 minecraft:air
fill ~80 ~160 ~80 ~111 ~191 ~111 minecraft:air
fill ~80 ~192 ~80 ~111 ~223 ~111 minecraft:air
setblock ~-114 ~-1 ~-114 minecraft:black_concrete
setblock ~-114 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-114 minecraft:black_concrete
setblock ~113 ~-1 ~-114 minecraft:black_concrete
setblock ~-114 ~-1 ~-113 minecraft:black_concrete
setblock ~-114 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-114 minecraft:black_concrete
setblock ~112 ~-1 ~-114 minecraft:black_concrete
setblock ~-113 ~-1 ~-114 minecraft:black_concrete
setblock ~-113 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-113 minecraft:black_concrete
setblock ~113 ~-1 ~-113 minecraft:black_concrete
setblock ~-113 ~-1 ~-113 minecraft:black_concrete
setblock ~-113 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-113 minecraft:black_concrete
setblock ~112 ~-1 ~-113 minecraft:black_concrete
setblock ~-112 ~-1 ~-114 minecraft:black_concrete
setblock ~-112 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-112 minecraft:black_concrete
setblock ~113 ~-1 ~-112 minecraft:black_concrete
setblock ~-112 ~-1 ~-113 minecraft:black_concrete
setblock ~-112 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-112 minecraft:black_concrete
setblock ~112 ~-1 ~-112 minecraft:black_concrete
setblock ~-111 ~-1 ~-114 minecraft:black_concrete
setblock ~-111 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-111 minecraft:black_concrete
setblock ~113 ~-1 ~-111 minecraft:black_concrete
setblock ~-111 ~-1 ~-113 minecraft:black_concrete
setblock ~-111 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-111 minecraft:black_concrete
setblock ~112 ~-1 ~-111 minecraft:black_concrete
setblock ~-110 ~-1 ~-114 minecraft:black_concrete
setblock ~-110 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-110 minecraft:black_concrete
setblock ~113 ~-1 ~-110 minecraft:black_concrete
setblock ~-110 ~-1 ~-113 minecraft:black_concrete
setblock ~-110 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-110 minecraft:black_concrete
setblock ~112 ~-1 ~-110 minecraft:black_concrete
setblock ~-109 ~-1 ~-114 minecraft:black_concrete
setblock ~-109 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-109 minecraft:black_concrete
setblock ~113 ~-1 ~-109 minecraft:black_concrete
setblock ~-109 ~-1 ~-113 minecraft:black_concrete
setblock ~-109 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-109 minecraft:black_concrete
setblock ~112 ~-1 ~-109 minecraft:black_concrete
setblock ~-108 ~-1 ~-114 minecraft:black_concrete
setblock ~-108 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-108 minecraft:black_concrete
setblock ~113 ~-1 ~-108 minecraft:black_concrete
setblock ~-108 ~-1 ~-113 minecraft:black_concrete
setblock ~-108 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-108 minecraft:black_concrete
setblock ~112 ~-1 ~-108 minecraft:black_concrete
setblock ~-107 ~-1 ~-114 minecraft:black_concrete
setblock ~-107 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-107 minecraft:black_concrete
setblock ~113 ~-1 ~-107 minecraft:black_concrete
setblock ~-107 ~-1 ~-113 minecraft:black_concrete
setblock ~-107 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-107 minecraft:black_concrete
setblock ~112 ~-1 ~-107 minecraft:black_concrete
setblock ~-106 ~-1 ~-114 minecraft:black_concrete
setblock ~-106 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-106 minecraft:black_concrete
setblock ~113 ~-1 ~-106 minecraft:black_concrete
setblock ~-106 ~-1 ~-113 minecraft:black_concrete
setblock ~-106 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-106 minecraft:black_concrete
setblock ~112 ~-1 ~-106 minecraft:black_concrete
setblock ~-105 ~-1 ~-114 minecraft:black_concrete
setblock ~-105 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-105 minecraft:black_concrete
setblock ~113 ~-1 ~-105 minecraft:black_concrete
setblock ~-105 ~-1 ~-113 minecraft:black_concrete
setblock ~-105 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-105 minecraft:black_concrete
setblock ~112 ~-1 ~-105 minecraft:black_concrete
setblock ~-104 ~-1 ~-114 minecraft:black_concrete
setblock ~-104 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-104 minecraft:black_concrete
setblock ~113 ~-1 ~-104 minecraft:black_concrete
setblock ~-104 ~-1 ~-113 minecraft:black_concrete
setblock ~-104 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-104 minecraft:black_concrete
setblock ~112 ~-1 ~-104 minecraft:black_concrete
setblock ~-103 ~-1 ~-114 minecraft:black_concrete
setblock ~-103 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-103 minecraft:black_concrete
setblock ~113 ~-1 ~-103 minecraft:black_concrete
setblock ~-103 ~-1 ~-113 minecraft:black_concrete
setblock ~-103 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-103 minecraft:black_concrete
setblock ~112 ~-1 ~-103 minecraft:black_concrete
setblock ~-102 ~-1 ~-114 minecraft:black_concrete
setblock ~-102 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-102 minecraft:black_concrete
setblock ~113 ~-1 ~-102 minecraft:black_concrete
setblock ~-102 ~-1 ~-113 minecraft:black_concrete
setblock ~-102 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-102 minecraft:black_concrete
setblock ~112 ~-1 ~-102 minecraft:black_concrete
setblock ~-101 ~-1 ~-114 minecraft:black_concrete
setblock ~-101 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-101 minecraft:black_concrete
setblock ~113 ~-1 ~-101 minecraft:black_concrete
setblock ~-101 ~-1 ~-113 minecraft:black_concrete
setblock ~-101 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-101 minecraft:black_concrete
setblock ~112 ~-1 ~-101 minecraft:black_concrete
setblock ~-100 ~-1 ~-114 minecraft:black_concrete
setblock ~-100 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-100 minecraft:black_concrete
setblock ~113 ~-1 ~-100 minecraft:black_concrete
setblock ~-100 ~-1 ~-113 minecraft:black_concrete
setblock ~-100 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-100 minecraft:black_concrete
setblock ~112 ~-1 ~-100 minecraft:black_concrete
setblock ~-99 ~-1 ~-114 minecraft:black_concrete
setblock ~-99 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-99 minecraft:black_concrete
setblock ~113 ~-1 ~-99 minecraft:black_concrete
setblock ~-99 ~-1 ~-113 minecraft:black_concrete
setblock ~-99 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-99 minecraft:black_concrete
setblock ~112 ~-1 ~-99 minecraft:black_concrete
setblock ~-98 ~-1 ~-114 minecraft:black_concrete
setblock ~-98 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-98 minecraft:black_concrete
setblock ~113 ~-1 ~-98 minecraft:black_concrete
setblock ~-98 ~-1 ~-113 minecraft:black_concrete
setblock ~-98 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-98 minecraft:black_concrete
setblock ~112 ~-1 ~-98 minecraft:black_concrete
setblock ~-97 ~-1 ~-114 minecraft:black_concrete
setblock ~-97 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-97 minecraft:black_concrete
setblock ~113 ~-1 ~-97 minecraft:black_concrete
setblock ~-97 ~-1 ~-113 minecraft:black_concrete
setblock ~-97 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-97 minecraft:black_concrete
setblock ~112 ~-1 ~-97 minecraft:black_concrete
setblock ~-96 ~-1 ~-114 minecraft:black_concrete
setblock ~-96 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-96 minecraft:black_concrete
setblock ~113 ~-1 ~-96 minecraft:black_concrete
setblock ~-96 ~-1 ~-113 minecraft:black_concrete
setblock ~-96 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-96 minecraft:black_concrete
setblock ~112 ~-1 ~-96 minecraft:black_concrete
setblock ~-95 ~-1 ~-114 minecraft:black_concrete
setblock ~-95 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-95 minecraft:black_concrete
setblock ~113 ~-1 ~-95 minecraft:black_concrete
setblock ~-95 ~-1 ~-113 minecraft:black_concrete
setblock ~-95 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-95 minecraft:black_concrete
setblock ~112 ~-1 ~-95 minecraft:black_concrete
setblock ~-94 ~-1 ~-114 minecraft:black_concrete
setblock ~-94 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-94 minecraft:black_concrete
setblock ~113 ~-1 ~-94 minecraft:black_concrete
setblock ~-94 ~-1 ~-113 minecraft:black_concrete
setblock ~-94 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-94 minecraft:black_concrete
setblock ~112 ~-1 ~-94 minecraft:black_concrete
setblock ~-93 ~-1 ~-114 minecraft:black_concrete
setblock ~-93 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-93 minecraft:black_concrete
setblock ~113 ~-1 ~-93 minecraft:black_concrete
setblock ~-93 ~-1 ~-113 minecraft:black_concrete
setblock ~-93 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-93 minecraft:black_concrete
setblock ~112 ~-1 ~-93 minecraft:black_concrete
setblock ~-92 ~-1 ~-114 minecraft:black_concrete
setblock ~-92 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-92 minecraft:black_concrete
setblock ~113 ~-1 ~-92 minecraft:black_concrete
setblock ~-92 ~-1 ~-113 minecraft:black_concrete
setblock ~-92 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-92 minecraft:black_concrete
setblock ~112 ~-1 ~-92 minecraft:black_concrete
setblock ~-91 ~-1 ~-114 minecraft:black_concrete
setblock ~-91 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-91 minecraft:black_concrete
setblock ~113 ~-1 ~-91 minecraft:black_concrete
setblock ~-91 ~-1 ~-113 minecraft:black_concrete
setblock ~-91 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-91 minecraft:black_concrete
setblock ~112 ~-1 ~-91 minecraft:black_concrete
setblock ~-90 ~-1 ~-114 minecraft:black_concrete
setblock ~-90 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-90 minecraft:black_concrete
setblock ~113 ~-1 ~-90 minecraft:black_concrete
setblock ~-90 ~-1 ~-113 minecraft:black_concrete
setblock ~-90 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-90 minecraft:black_concrete
setblock ~112 ~-1 ~-90 minecraft:black_concrete
setblock ~-89 ~-1 ~-114 minecraft:black_concrete
setblock ~-89 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-89 minecraft:black_concrete
setblock ~113 ~-1 ~-89 minecraft:black_concrete
setblock ~-89 ~-1 ~-113 minecraft:black_concrete
setblock ~-89 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-89 minecraft:black_concrete
setblock ~112 ~-1 ~-89 minecraft:black_concrete
setblock ~-88 ~-1 ~-114 minecraft:black_concrete
setblock ~-88 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-88 minecraft:black_concrete
setblock ~113 ~-1 ~-88 minecraft:black_concrete
setblock ~-88 ~-1 ~-113 minecraft:black_concrete
setblock ~-88 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-88 minecraft:black_concrete
setblock ~112 ~-1 ~-88 minecraft:black_concrete
setblock ~-87 ~-1 ~-114 minecraft:black_concrete
setblock ~-87 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-87 minecraft:black_concrete
setblock ~113 ~-1 ~-87 minecraft:black_concrete
setblock ~-87 ~-1 ~-113 minecraft:black_concrete
setblock ~-87 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-87 minecraft:black_concrete
setblock ~112 ~-1 ~-87 minecraft:black_concrete
setblock ~-86 ~-1 ~-114 minecraft:black_concrete
setblock ~-86 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-86 minecraft:black_concrete
setblock ~113 ~-1 ~-86 minecraft:black_concrete
setblock ~-86 ~-1 ~-113 minecraft:black_concrete
setblock ~-86 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-86 minecraft:black_concrete
setblock ~112 ~-1 ~-86 minecraft:black_concrete
setblock ~-85 ~-1 ~-114 minecraft:black_concrete
setblock ~-85 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-85 minecraft:black_concrete
setblock ~113 ~-1 ~-85 minecraft:black_concrete
setblock ~-85 ~-1 ~-113 minecraft:black_concrete
setblock ~-85 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-85 minecraft:black_concrete
setblock ~112 ~-1 ~-85 minecraft:black_concrete
setblock ~-84 ~-1 ~-114 minecraft:black_concrete
setblock ~-84 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-84 minecraft:black_concrete
setblock ~113 ~-1 ~-84 minecraft:black_concrete
setblock ~-84 ~-1 ~-113 minecraft:black_concrete
setblock ~-84 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-84 minecraft:black_concrete
setblock ~112 ~-1 ~-84 minecraft:black_concrete
setblock ~-83 ~-1 ~-114 minecraft:black_concrete
setblock ~-83 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-83 minecraft:black_concrete
setblock ~113 ~-1 ~-83 minecraft:black_concrete
setblock ~-83 ~-1 ~-113 minecraft:black_concrete
setblock ~-83 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-83 minecraft:black_concrete
setblock ~112 ~-1 ~-83 minecraft:black_concrete
setblock ~-82 ~-1 ~-114 minecraft:black_concrete
setblock ~-82 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-82 minecraft:black_concrete
setblock ~113 ~-1 ~-82 minecraft:black_concrete
setblock ~-82 ~-1 ~-113 minecraft:black_concrete
setblock ~-82 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-82 minecraft:black_concrete
setblock ~112 ~-1 ~-82 minecraft:black_concrete
setblock ~-81 ~-1 ~-114 minecraft:black_concrete
setblock ~-81 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-81 minecraft:black_concrete
setblock ~113 ~-1 ~-81 minecraft:black_concrete
setblock ~-81 ~-1 ~-113 minecraft:black_concrete
setblock ~-81 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-81 minecraft:black_concrete
setblock ~112 ~-1 ~-81 minecraft:black_concrete
setblock ~-80 ~-1 ~-114 minecraft:black_concrete
setblock ~-80 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-80 minecraft:black_concrete
setblock ~113 ~-1 ~-80 minecraft:black_concrete
setblock ~-80 ~-1 ~-113 minecraft:black_concrete
setblock ~-80 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-80 minecraft:black_concrete
setblock ~112 ~-1 ~-80 minecraft:black_concrete
setblock ~-79 ~-1 ~-114 minecraft:black_concrete
setblock ~-79 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-79 minecraft:black_concrete
setblock ~113 ~-1 ~-79 minecraft:black_concrete
setblock ~-79 ~-1 ~-113 minecraft:black_concrete
setblock ~-79 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-79 minecraft:black_concrete
setblock ~112 ~-1 ~-79 minecraft:black_concrete
setblock ~-78 ~-1 ~-114 minecraft:black_concrete
setblock ~-78 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-78 minecraft:black_concrete
setblock ~113 ~-1 ~-78 minecraft:black_concrete
setblock ~-78 ~-1 ~-113 minecraft:black_concrete
setblock ~-78 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-78 minecraft:black_concrete
setblock ~112 ~-1 ~-78 minecraft:black_concrete
setblock ~-77 ~-1 ~-114 minecraft:black_concrete
setblock ~-77 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-77 minecraft:black_concrete
setblock ~113 ~-1 ~-77 minecraft:black_concrete
setblock ~-77 ~-1 ~-113 minecraft:black_concrete
setblock ~-77 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-77 minecraft:black_concrete
setblock ~112 ~-1 ~-77 minecraft:black_concrete
setblock ~-76 ~-1 ~-114 minecraft:black_concrete
setblock ~-76 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-76 minecraft:black_concrete
setblock ~113 ~-1 ~-76 minecraft:black_concrete
setblock ~-76 ~-1 ~-113 minecraft:black_concrete
setblock ~-76 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-76 minecraft:black_concrete
setblock ~112 ~-1 ~-76 minecraft:black_concrete
setblock ~-75 ~-1 ~-114 minecraft:black_concrete
setblock ~-75 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-75 minecraft:black_concrete
setblock ~113 ~-1 ~-75 minecraft:black_concrete
setblock ~-75 ~-1 ~-113 minecraft:black_concrete
setblock ~-75 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-75 minecraft:black_concrete
setblock ~112 ~-1 ~-75 minecraft:black_concrete
setblock ~-74 ~-1 ~-114 minecraft:black_concrete
setblock ~-74 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-74 minecraft:black_concrete
setblock ~113 ~-1 ~-74 minecraft:black_concrete
setblock ~-74 ~-1 ~-113 minecraft:black_concrete
setblock ~-74 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-74 minecraft:black_concrete
setblock ~112 ~-1 ~-74 minecraft:black_concrete
setblock ~-73 ~-1 ~-114 minecraft:black_concrete
setblock ~-73 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-73 minecraft:black_concrete
setblock ~113 ~-1 ~-73 minecraft:black_concrete
setblock ~-73 ~-1 ~-113 minecraft:black_concrete
setblock ~-73 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-73 minecraft:black_concrete
setblock ~112 ~-1 ~-73 minecraft:black_concrete
setblock ~-72 ~-1 ~-114 minecraft:black_concrete
setblock ~-72 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-72 minecraft:black_concrete
setblock ~113 ~-1 ~-72 minecraft:black_concrete
setblock ~-72 ~-1 ~-113 minecraft:black_concrete
setblock ~-72 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-72 minecraft:black_concrete
setblock ~112 ~-1 ~-72 minecraft:black_concrete
setblock ~-71 ~-1 ~-114 minecraft:black_concrete
setblock ~-71 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-71 minecraft:black_concrete
setblock ~113 ~-1 ~-71 minecraft:black_concrete
setblock ~-71 ~-1 ~-113 minecraft:black_concrete
setblock ~-71 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-71 minecraft:black_concrete
setblock ~112 ~-1 ~-71 minecraft:black_concrete
setblock ~-70 ~-1 ~-114 minecraft:black_concrete
setblock ~-70 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-70 minecraft:black_concrete
setblock ~113 ~-1 ~-70 minecraft:black_concrete
setblock ~-70 ~-1 ~-113 minecraft:black_concrete
setblock ~-70 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-70 minecraft:black_concrete
setblock ~112 ~-1 ~-70 minecraft:black_concrete
setblock ~-69 ~-1 ~-114 minecraft:black_concrete
setblock ~-69 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-69 minecraft:black_concrete
setblock ~113 ~-1 ~-69 minecraft:black_concrete
setblock ~-69 ~-1 ~-113 minecraft:black_concrete
setblock ~-69 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-69 minecraft:black_concrete
setblock ~112 ~-1 ~-69 minecraft:black_concrete
setblock ~-68 ~-1 ~-114 minecraft:black_concrete
setblock ~-68 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-68 minecraft:black_concrete
setblock ~113 ~-1 ~-68 minecraft:black_concrete
setblock ~-68 ~-1 ~-113 minecraft:black_concrete
setblock ~-68 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-68 minecraft:black_concrete
setblock ~112 ~-1 ~-68 minecraft:black_concrete
setblock ~-67 ~-1 ~-114 minecraft:black_concrete
setblock ~-67 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-67 minecraft:black_concrete
setblock ~113 ~-1 ~-67 minecraft:black_concrete
setblock ~-67 ~-1 ~-113 minecraft:black_concrete
setblock ~-67 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-67 minecraft:black_concrete
setblock ~112 ~-1 ~-67 minecraft:black_concrete
setblock ~-66 ~-1 ~-114 minecraft:black_concrete
setblock ~-66 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-66 minecraft:black_concrete
setblock ~113 ~-1 ~-66 minecraft:black_concrete
setblock ~-66 ~-1 ~-113 minecraft:black_concrete
setblock ~-66 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-66 minecraft:black_concrete
setblock ~112 ~-1 ~-66 minecraft:black_concrete
setblock ~-65 ~-1 ~-114 minecraft:black_concrete
setblock ~-65 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-65 minecraft:black_concrete
setblock ~113 ~-1 ~-65 minecraft:black_concrete
setblock ~-65 ~-1 ~-113 minecraft:black_concrete
setblock ~-65 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-65 minecraft:black_concrete
setblock ~112 ~-1 ~-65 minecraft:black_concrete
setblock ~-64 ~-1 ~-114 minecraft:black_concrete
setblock ~-64 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-64 minecraft:black_concrete
setblock ~113 ~-1 ~-64 minecraft:black_concrete
setblock ~-64 ~-1 ~-113 minecraft:black_concrete
setblock ~-64 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-64 minecraft:black_concrete
setblock ~112 ~-1 ~-64 minecraft:black_concrete
setblock ~-63 ~-1 ~-114 minecraft:black_concrete
setblock ~-63 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-63 minecraft:black_concrete
setblock ~113 ~-1 ~-63 minecraft:black_concrete
setblock ~-63 ~-1 ~-113 minecraft:black_concrete
setblock ~-63 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-63 minecraft:black_concrete
setblock ~112 ~-1 ~-63 minecraft:black_concrete
setblock ~-62 ~-1 ~-114 minecraft:black_concrete
setblock ~-62 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-62 minecraft:black_concrete
setblock ~113 ~-1 ~-62 minecraft:black_concrete
setblock ~-62 ~-1 ~-113 minecraft:black_concrete
setblock ~-62 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-62 minecraft:black_concrete
setblock ~112 ~-1 ~-62 minecraft:black_concrete
setblock ~-61 ~-1 ~-114 minecraft:black_concrete
setblock ~-61 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-61 minecraft:black_concrete
setblock ~113 ~-1 ~-61 minecraft:black_concrete
setblock ~-61 ~-1 ~-113 minecraft:black_concrete
setblock ~-61 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-61 minecraft:black_concrete
setblock ~112 ~-1 ~-61 minecraft:black_concrete
setblock ~-60 ~-1 ~-114 minecraft:black_concrete
setblock ~-60 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-60 minecraft:black_concrete
setblock ~113 ~-1 ~-60 minecraft:black_concrete
setblock ~-60 ~-1 ~-113 minecraft:black_concrete
setblock ~-60 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-60 minecraft:black_concrete
setblock ~112 ~-1 ~-60 minecraft:black_concrete
setblock ~-59 ~-1 ~-114 minecraft:black_concrete
setblock ~-59 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-59 minecraft:black_concrete
setblock ~113 ~-1 ~-59 minecraft:black_concrete
setblock ~-59 ~-1 ~-113 minecraft:black_concrete
setblock ~-59 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-59 minecraft:black_concrete
setblock ~112 ~-1 ~-59 minecraft:black_concrete
setblock ~-58 ~-1 ~-114 minecraft:black_concrete
setblock ~-58 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-58 minecraft:black_concrete
setblock ~113 ~-1 ~-58 minecraft:black_concrete
setblock ~-58 ~-1 ~-113 minecraft:black_concrete
setblock ~-58 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-58 minecraft:black_concrete
setblock ~112 ~-1 ~-58 minecraft:black_concrete
setblock ~-57 ~-1 ~-114 minecraft:black_concrete
setblock ~-57 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-57 minecraft:black_concrete
setblock ~113 ~-1 ~-57 minecraft:black_concrete
setblock ~-57 ~-1 ~-113 minecraft:black_concrete
setblock ~-57 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-57 minecraft:black_concrete
setblock ~112 ~-1 ~-57 minecraft:black_concrete
setblock ~-56 ~-1 ~-114 minecraft:black_concrete
setblock ~-56 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-56 minecraft:black_concrete
setblock ~113 ~-1 ~-56 minecraft:black_concrete
setblock ~-56 ~-1 ~-113 minecraft:black_concrete
setblock ~-56 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-56 minecraft:black_concrete
setblock ~112 ~-1 ~-56 minecraft:black_concrete
setblock ~-55 ~-1 ~-114 minecraft:black_concrete
setblock ~-55 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-55 minecraft:black_concrete
setblock ~113 ~-1 ~-55 minecraft:black_concrete
setblock ~-55 ~-1 ~-113 minecraft:black_concrete
setblock ~-55 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-55 minecraft:black_concrete
setblock ~112 ~-1 ~-55 minecraft:black_concrete
setblock ~-54 ~-1 ~-114 minecraft:black_concrete
setblock ~-54 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-54 minecraft:black_concrete
setblock ~113 ~-1 ~-54 minecraft:black_concrete
setblock ~-54 ~-1 ~-113 minecraft:black_concrete
setblock ~-54 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-54 minecraft:black_concrete
setblock ~112 ~-1 ~-54 minecraft:black_concrete
setblock ~-53 ~-1 ~-114 minecraft:black_concrete
setblock ~-53 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-53 minecraft:black_concrete
setblock ~113 ~-1 ~-53 minecraft:black_concrete
setblock ~-53 ~-1 ~-113 minecraft:black_concrete
setblock ~-53 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-53 minecraft:black_concrete
setblock ~112 ~-1 ~-53 minecraft:black_concrete
setblock ~-52 ~-1 ~-114 minecraft:black_concrete
setblock ~-52 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-52 minecraft:black_concrete
setblock ~113 ~-1 ~-52 minecraft:black_concrete
setblock ~-52 ~-1 ~-113 minecraft:black_concrete
setblock ~-52 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-52 minecraft:black_concrete
setblock ~112 ~-1 ~-52 minecraft:black_concrete
setblock ~-51 ~-1 ~-114 minecraft:black_concrete
setblock ~-51 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-51 minecraft:black_concrete
setblock ~113 ~-1 ~-51 minecraft:black_concrete
setblock ~-51 ~-1 ~-113 minecraft:black_concrete
setblock ~-51 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-51 minecraft:black_concrete
setblock ~112 ~-1 ~-51 minecraft:black_concrete
setblock ~-50 ~-1 ~-114 minecraft:black_concrete
setblock ~-50 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-50 minecraft:black_concrete
setblock ~113 ~-1 ~-50 minecraft:black_concrete
setblock ~-50 ~-1 ~-113 minecraft:black_concrete
setblock ~-50 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-50 minecraft:black_concrete
setblock ~112 ~-1 ~-50 minecraft:black_concrete
setblock ~-49 ~-1 ~-114 minecraft:black_concrete
setblock ~-49 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-49 minecraft:black_concrete
setblock ~113 ~-1 ~-49 minecraft:black_concrete
setblock ~-49 ~-1 ~-113 minecraft:black_concrete
setblock ~-49 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-49 minecraft:black_concrete
setblock ~112 ~-1 ~-49 minecraft:black_concrete
setblock ~-48 ~-1 ~-114 minecraft:black_concrete
setblock ~-48 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-48 minecraft:black_concrete
setblock ~113 ~-1 ~-48 minecraft:black_concrete
setblock ~-48 ~-1 ~-113 minecraft:black_concrete
setblock ~-48 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-48 minecraft:black_concrete
setblock ~112 ~-1 ~-48 minecraft:black_concrete
setblock ~-47 ~-1 ~-114 minecraft:black_concrete
setblock ~-47 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-47 minecraft:black_concrete
setblock ~113 ~-1 ~-47 minecraft:black_concrete
setblock ~-47 ~-1 ~-113 minecraft:black_concrete
setblock ~-47 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-47 minecraft:black_concrete
setblock ~112 ~-1 ~-47 minecraft:black_concrete
setblock ~-46 ~-1 ~-114 minecraft:black_concrete
setblock ~-46 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-46 minecraft:black_concrete
setblock ~113 ~-1 ~-46 minecraft:black_concrete
setblock ~-46 ~-1 ~-113 minecraft:black_concrete
setblock ~-46 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-46 minecraft:black_concrete
setblock ~112 ~-1 ~-46 minecraft:black_concrete
setblock ~-45 ~-1 ~-114 minecraft:black_concrete
setblock ~-45 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-45 minecraft:black_concrete
setblock ~113 ~-1 ~-45 minecraft:black_concrete
setblock ~-45 ~-1 ~-113 minecraft:black_concrete
setblock ~-45 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-45 minecraft:black_concrete
setblock ~112 ~-1 ~-45 minecraft:black_concrete
setblock ~-44 ~-1 ~-114 minecraft:black_concrete
setblock ~-44 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-44 minecraft:black_concrete
setblock ~113 ~-1 ~-44 minecraft:black_concrete
setblock ~-44 ~-1 ~-113 minecraft:black_concrete
setblock ~-44 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-44 minecraft:black_concrete
setblock ~112 ~-1 ~-44 minecraft:black_concrete
setblock ~-43 ~-1 ~-114 minecraft:black_concrete
setblock ~-43 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-43 minecraft:black_concrete
setblock ~113 ~-1 ~-43 minecraft:black_concrete
setblock ~-43 ~-1 ~-113 minecraft:black_concrete
setblock ~-43 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-43 minecraft:black_concrete
setblock ~112 ~-1 ~-43 minecraft:black_concrete
setblock ~-42 ~-1 ~-114 minecraft:black_concrete
setblock ~-42 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-42 minecraft:black_concrete
setblock ~113 ~-1 ~-42 minecraft:black_concrete
setblock ~-42 ~-1 ~-113 minecraft:black_concrete
setblock ~-42 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-42 minecraft:black_concrete
setblock ~112 ~-1 ~-42 minecraft:black_concrete
setblock ~-41 ~-1 ~-114 minecraft:black_concrete
setblock ~-41 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-41 minecraft:black_concrete
setblock ~113 ~-1 ~-41 minecraft:black_concrete
setblock ~-41 ~-1 ~-113 minecraft:black_concrete
setblock ~-41 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-41 minecraft:black_concrete
setblock ~112 ~-1 ~-41 minecraft:black_concrete
setblock ~-40 ~-1 ~-114 minecraft:black_concrete
setblock ~-40 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-40 minecraft:black_concrete
setblock ~113 ~-1 ~-40 minecraft:black_concrete
setblock ~-40 ~-1 ~-113 minecraft:black_concrete
setblock ~-40 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-40 minecraft:black_concrete
setblock ~112 ~-1 ~-40 minecraft:black_concrete
setblock ~-39 ~-1 ~-114 minecraft:black_concrete
setblock ~-39 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-39 minecraft:black_concrete
setblock ~113 ~-1 ~-39 minecraft:black_concrete
setblock ~-39 ~-1 ~-113 minecraft:black_concrete
setblock ~-39 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-39 minecraft:black_concrete
setblock ~112 ~-1 ~-39 minecraft:black_concrete
setblock ~-38 ~-1 ~-114 minecraft:black_concrete
setblock ~-38 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-38 minecraft:black_concrete
setblock ~113 ~-1 ~-38 minecraft:black_concrete
setblock ~-38 ~-1 ~-113 minecraft:black_concrete
setblock ~-38 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-38 minecraft:black_concrete
setblock ~112 ~-1 ~-38 minecraft:black_concrete
setblock ~-37 ~-1 ~-114 minecraft:black_concrete
setblock ~-37 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-37 minecraft:black_concrete
setblock ~113 ~-1 ~-37 minecraft:black_concrete
setblock ~-37 ~-1 ~-113 minecraft:black_concrete
setblock ~-37 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-37 minecraft:black_concrete
setblock ~112 ~-1 ~-37 minecraft:black_concrete
setblock ~-36 ~-1 ~-114 minecraft:black_concrete
setblock ~-36 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-36 minecraft:black_concrete
setblock ~113 ~-1 ~-36 minecraft:black_concrete
setblock ~-36 ~-1 ~-113 minecraft:black_concrete
setblock ~-36 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-36 minecraft:black_concrete
setblock ~112 ~-1 ~-36 minecraft:black_concrete
setblock ~-35 ~-1 ~-114 minecraft:black_concrete
setblock ~-35 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-35 minecraft:black_concrete
setblock ~113 ~-1 ~-35 minecraft:black_concrete
setblock ~-35 ~-1 ~-113 minecraft:black_concrete
setblock ~-35 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-35 minecraft:black_concrete
setblock ~112 ~-1 ~-35 minecraft:black_concrete
setblock ~-34 ~-1 ~-114 minecraft:black_concrete
setblock ~-34 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-34 minecraft:black_concrete
setblock ~113 ~-1 ~-34 minecraft:black_concrete
setblock ~-34 ~-1 ~-113 minecraft:black_concrete
setblock ~-34 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-34 minecraft:black_concrete
setblock ~112 ~-1 ~-34 minecraft:black_concrete
setblock ~-33 ~-1 ~-114 minecraft:black_concrete
setblock ~-33 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-33 minecraft:black_concrete
setblock ~113 ~-1 ~-33 minecraft:black_concrete
setblock ~-33 ~-1 ~-113 minecraft:black_concrete
setblock ~-33 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-33 minecraft:black_concrete
setblock ~112 ~-1 ~-33 minecraft:black_concrete
setblock ~-32 ~-1 ~-114 minecraft:black_concrete
setblock ~-32 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-32 minecraft:black_concrete
setblock ~113 ~-1 ~-32 minecraft:black_concrete
setblock ~-32 ~-1 ~-113 minecraft:black_concrete
setblock ~-32 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-32 minecraft:black_concrete
setblock ~112 ~-1 ~-32 minecraft:black_concrete
setblock ~-31 ~-1 ~-114 minecraft:black_concrete
setblock ~-31 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-31 minecraft:black_concrete
setblock ~113 ~-1 ~-31 minecraft:black_concrete
setblock ~-31 ~-1 ~-113 minecraft:black_concrete
setblock ~-31 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-31 minecraft:black_concrete
setblock ~112 ~-1 ~-31 minecraft:black_concrete
setblock ~-30 ~-1 ~-114 minecraft:black_concrete
setblock ~-30 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-30 minecraft:black_concrete
setblock ~113 ~-1 ~-30 minecraft:black_concrete
setblock ~-30 ~-1 ~-113 minecraft:black_concrete
setblock ~-30 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-30 minecraft:black_concrete
setblock ~112 ~-1 ~-30 minecraft:black_concrete
setblock ~-29 ~-1 ~-114 minecraft:black_concrete
setblock ~-29 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-29 minecraft:black_concrete
setblock ~113 ~-1 ~-29 minecraft:black_concrete
setblock ~-29 ~-1 ~-113 minecraft:black_concrete
setblock ~-29 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-29 minecraft:black_concrete
setblock ~112 ~-1 ~-29 minecraft:black_concrete
setblock ~-28 ~-1 ~-114 minecraft:black_concrete
setblock ~-28 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-28 minecraft:black_concrete
setblock ~113 ~-1 ~-28 minecraft:black_concrete
setblock ~-28 ~-1 ~-113 minecraft:black_concrete
setblock ~-28 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-28 minecraft:black_concrete
setblock ~112 ~-1 ~-28 minecraft:black_concrete
setblock ~-27 ~-1 ~-114 minecraft:black_concrete
setblock ~-27 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-27 minecraft:black_concrete
setblock ~113 ~-1 ~-27 minecraft:black_concrete
setblock ~-27 ~-1 ~-113 minecraft:black_concrete
setblock ~-27 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-27 minecraft:black_concrete
setblock ~112 ~-1 ~-27 minecraft:black_concrete
setblock ~-26 ~-1 ~-114 minecraft:black_concrete
setblock ~-26 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-26 minecraft:black_concrete
setblock ~113 ~-1 ~-26 minecraft:black_concrete
setblock ~-26 ~-1 ~-113 minecraft:black_concrete
setblock ~-26 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-26 minecraft:black_concrete
setblock ~112 ~-1 ~-26 minecraft:black_concrete
setblock ~-25 ~-1 ~-114 minecraft:black_concrete
setblock ~-25 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-25 minecraft:black_concrete
setblock ~113 ~-1 ~-25 minecraft:black_concrete
setblock ~-25 ~-1 ~-113 minecraft:black_concrete
setblock ~-25 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-25 minecraft:black_concrete
setblock ~112 ~-1 ~-25 minecraft:black_concrete
setblock ~-24 ~-1 ~-114 minecraft:black_concrete
setblock ~-24 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-24 minecraft:black_concrete
setblock ~113 ~-1 ~-24 minecraft:black_concrete
setblock ~-24 ~-1 ~-113 minecraft:black_concrete
setblock ~-24 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-24 minecraft:black_concrete
setblock ~112 ~-1 ~-24 minecraft:black_concrete
setblock ~-23 ~-1 ~-114 minecraft:black_concrete
setblock ~-23 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-23 minecraft:black_concrete
setblock ~113 ~-1 ~-23 minecraft:black_concrete
setblock ~-23 ~-1 ~-113 minecraft:black_concrete
setblock ~-23 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-23 minecraft:black_concrete
setblock ~112 ~-1 ~-23 minecraft:black_concrete
setblock ~-22 ~-1 ~-114 minecraft:black_concrete
setblock ~-22 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-22 minecraft:black_concrete
setblock ~113 ~-1 ~-22 minecraft:black_concrete
setblock ~-22 ~-1 ~-113 minecraft:black_concrete
setblock ~-22 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-22 minecraft:black_concrete
setblock ~112 ~-1 ~-22 minecraft:black_concrete
setblock ~-21 ~-1 ~-114 minecraft:black_concrete
setblock ~-21 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-21 minecraft:black_concrete
setblock ~113 ~-1 ~-21 minecraft:black_concrete
setblock ~-21 ~-1 ~-113 minecraft:black_concrete
setblock ~-21 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-21 minecraft:black_concrete
setblock ~112 ~-1 ~-21 minecraft:black_concrete
setblock ~-20 ~-1 ~-114 minecraft:black_concrete
setblock ~-20 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-20 minecraft:black_concrete
setblock ~113 ~-1 ~-20 minecraft:black_concrete
setblock ~-20 ~-1 ~-113 minecraft:black_concrete
setblock ~-20 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-20 minecraft:black_concrete
setblock ~112 ~-1 ~-20 minecraft:black_concrete
setblock ~-19 ~-1 ~-114 minecraft:black_concrete
setblock ~-19 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-19 minecraft:black_concrete
setblock ~113 ~-1 ~-19 minecraft:black_concrete
setblock ~-19 ~-1 ~-113 minecraft:black_concrete
setblock ~-19 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-19 minecraft:black_concrete
setblock ~112 ~-1 ~-19 minecraft:black_concrete
setblock ~-18 ~-1 ~-114 minecraft:black_concrete
setblock ~-18 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-18 minecraft:black_concrete
setblock ~113 ~-1 ~-18 minecraft:black_concrete
setblock ~-18 ~-1 ~-113 minecraft:black_concrete
setblock ~-18 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-18 minecraft:black_concrete
setblock ~112 ~-1 ~-18 minecraft:black_concrete
setblock ~-17 ~-1 ~-114 minecraft:black_concrete
setblock ~-17 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-17 minecraft:black_concrete
setblock ~113 ~-1 ~-17 minecraft:black_concrete
setblock ~-17 ~-1 ~-113 minecraft:black_concrete
setblock ~-17 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-17 minecraft:black_concrete
setblock ~112 ~-1 ~-17 minecraft:black_concrete
setblock ~-16 ~-1 ~-114 minecraft:black_concrete
setblock ~-16 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-16 minecraft:black_concrete
setblock ~113 ~-1 ~-16 minecraft:black_concrete
setblock ~-16 ~-1 ~-113 minecraft:black_concrete
setblock ~-16 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-16 minecraft:black_concrete
setblock ~112 ~-1 ~-16 minecraft:black_concrete
setblock ~-15 ~-1 ~-114 minecraft:black_concrete
setblock ~-15 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-15 minecraft:black_concrete
setblock ~113 ~-1 ~-15 minecraft:black_concrete
setblock ~-15 ~-1 ~-113 minecraft:black_concrete
setblock ~-15 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-15 minecraft:black_concrete
setblock ~112 ~-1 ~-15 minecraft:black_concrete
setblock ~-14 ~-1 ~-114 minecraft:black_concrete
setblock ~-14 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-14 minecraft:black_concrete
setblock ~113 ~-1 ~-14 minecraft:black_concrete
setblock ~-14 ~-1 ~-113 minecraft:black_concrete
setblock ~-14 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-14 minecraft:black_concrete
setblock ~112 ~-1 ~-14 minecraft:black_concrete
setblock ~-13 ~-1 ~-114 minecraft:black_concrete
setblock ~-13 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-13 minecraft:black_concrete
setblock ~113 ~-1 ~-13 minecraft:black_concrete
setblock ~-13 ~-1 ~-113 minecraft:black_concrete
setblock ~-13 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-13 minecraft:black_concrete
setblock ~112 ~-1 ~-13 minecraft:black_concrete
setblock ~-12 ~-1 ~-114 minecraft:black_concrete
setblock ~-12 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-12 minecraft:black_concrete
setblock ~113 ~-1 ~-12 minecraft:black_concrete
setblock ~-12 ~-1 ~-113 minecraft:black_concrete
setblock ~-12 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-12 minecraft:black_concrete
setblock ~112 ~-1 ~-12 minecraft:black_concrete
setblock ~-11 ~-1 ~-114 minecraft:black_concrete
setblock ~-11 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-11 minecraft:black_concrete
setblock ~113 ~-1 ~-11 minecraft:black_concrete
setblock ~-11 ~-1 ~-113 minecraft:black_concrete
setblock ~-11 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-11 minecraft:black_concrete
setblock ~112 ~-1 ~-11 minecraft:black_concrete
setblock ~-10 ~-1 ~-114 minecraft:black_concrete
setblock ~-10 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-10 minecraft:black_concrete
setblock ~113 ~-1 ~-10 minecraft:black_concrete
setblock ~-10 ~-1 ~-113 minecraft:black_concrete
setblock ~-10 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-10 minecraft:black_concrete
setblock ~112 ~-1 ~-10 minecraft:black_concrete
setblock ~-9 ~-1 ~-114 minecraft:black_concrete
setblock ~-9 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-9 minecraft:black_concrete
setblock ~113 ~-1 ~-9 minecraft:black_concrete
setblock ~-9 ~-1 ~-113 minecraft:black_concrete
setblock ~-9 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-9 minecraft:black_concrete
setblock ~112 ~-1 ~-9 minecraft:black_concrete
setblock ~-8 ~-1 ~-114 minecraft:black_concrete
setblock ~-8 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-8 minecraft:black_concrete
setblock ~113 ~-1 ~-8 minecraft:black_concrete
setblock ~-8 ~-1 ~-113 minecraft:black_concrete
setblock ~-8 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-8 minecraft:black_concrete
setblock ~112 ~-1 ~-8 minecraft:black_concrete
setblock ~-7 ~-1 ~-114 minecraft:black_concrete
setblock ~-7 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-7 minecraft:black_concrete
setblock ~113 ~-1 ~-7 minecraft:black_concrete
setblock ~-7 ~-1 ~-113 minecraft:black_concrete
setblock ~-7 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-7 minecraft:black_concrete
setblock ~112 ~-1 ~-7 minecraft:black_concrete
setblock ~-6 ~-1 ~-114 minecraft:black_concrete
setblock ~-6 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-6 minecraft:black_concrete
setblock ~113 ~-1 ~-6 minecraft:black_concrete
setblock ~-6 ~-1 ~-113 minecraft:black_concrete
setblock ~-6 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-6 minecraft:black_concrete
setblock ~112 ~-1 ~-6 minecraft:black_concrete
setblock ~-5 ~-1 ~-114 minecraft:black_concrete
setblock ~-5 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-5 minecraft:black_concrete
setblock ~113 ~-1 ~-5 minecraft:black_concrete
setblock ~-5 ~-1 ~-113 minecraft:black_concrete
setblock ~-5 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-5 minecraft:black_concrete
setblock ~112 ~-1 ~-5 minecraft:black_concrete
setblock ~-4 ~-1 ~-114 minecraft:black_concrete
setblock ~-4 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-4 minecraft:black_concrete
setblock ~113 ~-1 ~-4 minecraft:black_concrete
setblock ~-4 ~-1 ~-113 minecraft:black_concrete
setblock ~-4 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-4 minecraft:black_concrete
setblock ~112 ~-1 ~-4 minecraft:black_concrete
setblock ~-3 ~-1 ~-114 minecraft:black_concrete
setblock ~-3 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-3 minecraft:black_concrete
setblock ~113 ~-1 ~-3 minecraft:black_concrete
setblock ~-3 ~-1 ~-113 minecraft:black_concrete
setblock ~-3 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-3 minecraft:black_concrete
setblock ~112 ~-1 ~-3 minecraft:black_concrete
setblock ~-2 ~-1 ~-114 minecraft:black_concrete
setblock ~-2 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-2 minecraft:black_concrete
setblock ~113 ~-1 ~-2 minecraft:black_concrete
setblock ~-2 ~-1 ~-113 minecraft:black_concrete
setblock ~-2 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-2 minecraft:black_concrete
setblock ~112 ~-1 ~-2 minecraft:black_concrete
setblock ~-1 ~-1 ~-114 minecraft:black_concrete
setblock ~-1 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~-1 minecraft:black_concrete
setblock ~113 ~-1 ~-1 minecraft:black_concrete
setblock ~-1 ~-1 ~-113 minecraft:black_concrete
setblock ~-1 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~-1 minecraft:black_concrete
setblock ~112 ~-1 ~-1 minecraft:black_concrete
setblock ~0 ~-1 ~-114 minecraft:black_concrete
setblock ~0 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~0 minecraft:black_concrete
setblock ~113 ~-1 ~0 minecraft:black_concrete
setblock ~0 ~-1 ~-113 minecraft:black_concrete
setblock ~0 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~0 minecraft:black_concrete
setblock ~112 ~-1 ~0 minecraft:black_concrete
setblock ~1 ~-1 ~-114 minecraft:black_concrete
setblock ~1 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~1 minecraft:black_concrete
setblock ~113 ~-1 ~1 minecraft:black_concrete
setblock ~1 ~-1 ~-113 minecraft:black_concrete
setblock ~1 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~1 minecraft:black_concrete
setblock ~112 ~-1 ~1 minecraft:black_concrete
setblock ~2 ~-1 ~-114 minecraft:black_concrete
setblock ~2 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~2 minecraft:black_concrete
setblock ~113 ~-1 ~2 minecraft:black_concrete
setblock ~2 ~-1 ~-113 minecraft:black_concrete
setblock ~2 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~2 minecraft:black_concrete
setblock ~112 ~-1 ~2 minecraft:black_concrete
setblock ~3 ~-1 ~-114 minecraft:black_concrete
setblock ~3 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~3 minecraft:black_concrete
setblock ~113 ~-1 ~3 minecraft:black_concrete
setblock ~3 ~-1 ~-113 minecraft:black_concrete
setblock ~3 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~3 minecraft:black_concrete
setblock ~112 ~-1 ~3 minecraft:black_concrete
setblock ~4 ~-1 ~-114 minecraft:black_concrete
setblock ~4 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~4 minecraft:black_concrete
setblock ~113 ~-1 ~4 minecraft:black_concrete
setblock ~4 ~-1 ~-113 minecraft:black_concrete
setblock ~4 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~4 minecraft:black_concrete
setblock ~112 ~-1 ~4 minecraft:black_concrete
setblock ~5 ~-1 ~-114 minecraft:black_concrete
setblock ~5 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~5 minecraft:black_concrete
setblock ~113 ~-1 ~5 minecraft:black_concrete
setblock ~5 ~-1 ~-113 minecraft:black_concrete
setblock ~5 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~5 minecraft:black_concrete
setblock ~112 ~-1 ~5 minecraft:black_concrete
setblock ~6 ~-1 ~-114 minecraft:black_concrete
setblock ~6 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~6 minecraft:black_concrete
setblock ~113 ~-1 ~6 minecraft:black_concrete
setblock ~6 ~-1 ~-113 minecraft:black_concrete
setblock ~6 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~6 minecraft:black_concrete
setblock ~112 ~-1 ~6 minecraft:black_concrete
setblock ~7 ~-1 ~-114 minecraft:black_concrete
setblock ~7 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~7 minecraft:black_concrete
setblock ~113 ~-1 ~7 minecraft:black_concrete
setblock ~7 ~-1 ~-113 minecraft:black_concrete
setblock ~7 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~7 minecraft:black_concrete
setblock ~112 ~-1 ~7 minecraft:black_concrete
setblock ~8 ~-1 ~-114 minecraft:black_concrete
setblock ~8 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~8 minecraft:black_concrete
setblock ~113 ~-1 ~8 minecraft:black_concrete
setblock ~8 ~-1 ~-113 minecraft:black_concrete
setblock ~8 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~8 minecraft:black_concrete
setblock ~112 ~-1 ~8 minecraft:black_concrete
setblock ~9 ~-1 ~-114 minecraft:black_concrete
setblock ~9 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~9 minecraft:black_concrete
setblock ~113 ~-1 ~9 minecraft:black_concrete
setblock ~9 ~-1 ~-113 minecraft:black_concrete
setblock ~9 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~9 minecraft:black_concrete
setblock ~112 ~-1 ~9 minecraft:black_concrete
setblock ~10 ~-1 ~-114 minecraft:black_concrete
setblock ~10 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~10 minecraft:black_concrete
setblock ~113 ~-1 ~10 minecraft:black_concrete
setblock ~10 ~-1 ~-113 minecraft:black_concrete
setblock ~10 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~10 minecraft:black_concrete
setblock ~112 ~-1 ~10 minecraft:black_concrete
setblock ~11 ~-1 ~-114 minecraft:black_concrete
setblock ~11 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~11 minecraft:black_concrete
setblock ~113 ~-1 ~11 minecraft:black_concrete
setblock ~11 ~-1 ~-113 minecraft:black_concrete
setblock ~11 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~11 minecraft:black_concrete
setblock ~112 ~-1 ~11 minecraft:black_concrete
setblock ~12 ~-1 ~-114 minecraft:black_concrete
setblock ~12 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~12 minecraft:black_concrete
setblock ~113 ~-1 ~12 minecraft:black_concrete
setblock ~12 ~-1 ~-113 minecraft:black_concrete
setblock ~12 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~12 minecraft:black_concrete
setblock ~112 ~-1 ~12 minecraft:black_concrete
setblock ~13 ~-1 ~-114 minecraft:black_concrete
setblock ~13 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~13 minecraft:black_concrete
setblock ~113 ~-1 ~13 minecraft:black_concrete
setblock ~13 ~-1 ~-113 minecraft:black_concrete
setblock ~13 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~13 minecraft:black_concrete
setblock ~112 ~-1 ~13 minecraft:black_concrete
setblock ~14 ~-1 ~-114 minecraft:black_concrete
setblock ~14 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~14 minecraft:black_concrete
setblock ~113 ~-1 ~14 minecraft:black_concrete
setblock ~14 ~-1 ~-113 minecraft:black_concrete
setblock ~14 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~14 minecraft:black_concrete
setblock ~112 ~-1 ~14 minecraft:black_concrete
setblock ~15 ~-1 ~-114 minecraft:black_concrete
setblock ~15 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~15 minecraft:black_concrete
setblock ~113 ~-1 ~15 minecraft:black_concrete
setblock ~15 ~-1 ~-113 minecraft:black_concrete
setblock ~15 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~15 minecraft:black_concrete
setblock ~112 ~-1 ~15 minecraft:black_concrete
setblock ~16 ~-1 ~-114 minecraft:black_concrete
setblock ~16 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~16 minecraft:black_concrete
setblock ~113 ~-1 ~16 minecraft:black_concrete
setblock ~16 ~-1 ~-113 minecraft:black_concrete
setblock ~16 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~16 minecraft:black_concrete
setblock ~112 ~-1 ~16 minecraft:black_concrete
setblock ~17 ~-1 ~-114 minecraft:black_concrete
setblock ~17 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~17 minecraft:black_concrete
setblock ~113 ~-1 ~17 minecraft:black_concrete
setblock ~17 ~-1 ~-113 minecraft:black_concrete
setblock ~17 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~17 minecraft:black_concrete
setblock ~112 ~-1 ~17 minecraft:black_concrete
setblock ~18 ~-1 ~-114 minecraft:black_concrete
setblock ~18 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~18 minecraft:black_concrete
setblock ~113 ~-1 ~18 minecraft:black_concrete
setblock ~18 ~-1 ~-113 minecraft:black_concrete
setblock ~18 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~18 minecraft:black_concrete
setblock ~112 ~-1 ~18 minecraft:black_concrete
setblock ~19 ~-1 ~-114 minecraft:black_concrete
setblock ~19 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~19 minecraft:black_concrete
setblock ~113 ~-1 ~19 minecraft:black_concrete
setblock ~19 ~-1 ~-113 minecraft:black_concrete
setblock ~19 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~19 minecraft:black_concrete
setblock ~112 ~-1 ~19 minecraft:black_concrete
setblock ~20 ~-1 ~-114 minecraft:black_concrete
setblock ~20 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~20 minecraft:black_concrete
setblock ~113 ~-1 ~20 minecraft:black_concrete
setblock ~20 ~-1 ~-113 minecraft:black_concrete
setblock ~20 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~20 minecraft:black_concrete
setblock ~112 ~-1 ~20 minecraft:black_concrete
setblock ~21 ~-1 ~-114 minecraft:black_concrete
setblock ~21 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~21 minecraft:black_concrete
setblock ~113 ~-1 ~21 minecraft:black_concrete
setblock ~21 ~-1 ~-113 minecraft:black_concrete
setblock ~21 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~21 minecraft:black_concrete
setblock ~112 ~-1 ~21 minecraft:black_concrete
setblock ~22 ~-1 ~-114 minecraft:black_concrete
setblock ~22 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~22 minecraft:black_concrete
setblock ~113 ~-1 ~22 minecraft:black_concrete
setblock ~22 ~-1 ~-113 minecraft:black_concrete
setblock ~22 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~22 minecraft:black_concrete
setblock ~112 ~-1 ~22 minecraft:black_concrete
setblock ~23 ~-1 ~-114 minecraft:black_concrete
setblock ~23 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~23 minecraft:black_concrete
setblock ~113 ~-1 ~23 minecraft:black_concrete
setblock ~23 ~-1 ~-113 minecraft:black_concrete
setblock ~23 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~23 minecraft:black_concrete
setblock ~112 ~-1 ~23 minecraft:black_concrete
setblock ~24 ~-1 ~-114 minecraft:black_concrete
setblock ~24 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~24 minecraft:black_concrete
setblock ~113 ~-1 ~24 minecraft:black_concrete
setblock ~24 ~-1 ~-113 minecraft:black_concrete
setblock ~24 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~24 minecraft:black_concrete
setblock ~112 ~-1 ~24 minecraft:black_concrete
setblock ~25 ~-1 ~-114 minecraft:black_concrete
setblock ~25 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~25 minecraft:black_concrete
setblock ~113 ~-1 ~25 minecraft:black_concrete
setblock ~25 ~-1 ~-113 minecraft:black_concrete
setblock ~25 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~25 minecraft:black_concrete
setblock ~112 ~-1 ~25 minecraft:black_concrete
setblock ~26 ~-1 ~-114 minecraft:black_concrete
setblock ~26 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~26 minecraft:black_concrete
setblock ~113 ~-1 ~26 minecraft:black_concrete
setblock ~26 ~-1 ~-113 minecraft:black_concrete
setblock ~26 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~26 minecraft:black_concrete
setblock ~112 ~-1 ~26 minecraft:black_concrete
setblock ~27 ~-1 ~-114 minecraft:black_concrete
setblock ~27 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~27 minecraft:black_concrete
setblock ~113 ~-1 ~27 minecraft:black_concrete
setblock ~27 ~-1 ~-113 minecraft:black_concrete
setblock ~27 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~27 minecraft:black_concrete
setblock ~112 ~-1 ~27 minecraft:black_concrete
setblock ~28 ~-1 ~-114 minecraft:black_concrete
setblock ~28 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~28 minecraft:black_concrete
setblock ~113 ~-1 ~28 minecraft:black_concrete
setblock ~28 ~-1 ~-113 minecraft:black_concrete
setblock ~28 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~28 minecraft:black_concrete
setblock ~112 ~-1 ~28 minecraft:black_concrete
setblock ~29 ~-1 ~-114 minecraft:black_concrete
setblock ~29 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~29 minecraft:black_concrete
setblock ~113 ~-1 ~29 minecraft:black_concrete
setblock ~29 ~-1 ~-113 minecraft:black_concrete
setblock ~29 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~29 minecraft:black_concrete
setblock ~112 ~-1 ~29 minecraft:black_concrete
setblock ~30 ~-1 ~-114 minecraft:black_concrete
setblock ~30 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~30 minecraft:black_concrete
setblock ~113 ~-1 ~30 minecraft:black_concrete
setblock ~30 ~-1 ~-113 minecraft:black_concrete
setblock ~30 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~30 minecraft:black_concrete
setblock ~112 ~-1 ~30 minecraft:black_concrete
setblock ~31 ~-1 ~-114 minecraft:black_concrete
setblock ~31 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~31 minecraft:black_concrete
setblock ~113 ~-1 ~31 minecraft:black_concrete
setblock ~31 ~-1 ~-113 minecraft:black_concrete
setblock ~31 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~31 minecraft:black_concrete
setblock ~112 ~-1 ~31 minecraft:black_concrete
setblock ~32 ~-1 ~-114 minecraft:black_concrete
setblock ~32 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~32 minecraft:black_concrete
setblock ~113 ~-1 ~32 minecraft:black_concrete
setblock ~32 ~-1 ~-113 minecraft:black_concrete
setblock ~32 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~32 minecraft:black_concrete
setblock ~112 ~-1 ~32 minecraft:black_concrete
setblock ~33 ~-1 ~-114 minecraft:black_concrete
setblock ~33 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~33 minecraft:black_concrete
setblock ~113 ~-1 ~33 minecraft:black_concrete
setblock ~33 ~-1 ~-113 minecraft:black_concrete
setblock ~33 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~33 minecraft:black_concrete
setblock ~112 ~-1 ~33 minecraft:black_concrete
setblock ~34 ~-1 ~-114 minecraft:black_concrete
setblock ~34 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~34 minecraft:black_concrete
setblock ~113 ~-1 ~34 minecraft:black_concrete
setblock ~34 ~-1 ~-113 minecraft:black_concrete
setblock ~34 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~34 minecraft:black_concrete
setblock ~112 ~-1 ~34 minecraft:black_concrete
setblock ~35 ~-1 ~-114 minecraft:black_concrete
setblock ~35 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~35 minecraft:black_concrete
setblock ~113 ~-1 ~35 minecraft:black_concrete
setblock ~35 ~-1 ~-113 minecraft:black_concrete
setblock ~35 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~35 minecraft:black_concrete
setblock ~112 ~-1 ~35 minecraft:black_concrete
setblock ~36 ~-1 ~-114 minecraft:black_concrete
setblock ~36 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~36 minecraft:black_concrete
setblock ~113 ~-1 ~36 minecraft:black_concrete
setblock ~36 ~-1 ~-113 minecraft:black_concrete
setblock ~36 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~36 minecraft:black_concrete
setblock ~112 ~-1 ~36 minecraft:black_concrete
setblock ~37 ~-1 ~-114 minecraft:black_concrete
setblock ~37 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~37 minecraft:black_concrete
setblock ~113 ~-1 ~37 minecraft:black_concrete
setblock ~37 ~-1 ~-113 minecraft:black_concrete
setblock ~37 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~37 minecraft:black_concrete
setblock ~112 ~-1 ~37 minecraft:black_concrete
setblock ~38 ~-1 ~-114 minecraft:black_concrete
setblock ~38 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~38 minecraft:black_concrete
setblock ~113 ~-1 ~38 minecraft:black_concrete
setblock ~38 ~-1 ~-113 minecraft:black_concrete
setblock ~38 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~38 minecraft:black_concrete
setblock ~112 ~-1 ~38 minecraft:black_concrete
setblock ~39 ~-1 ~-114 minecraft:black_concrete
setblock ~39 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~39 minecraft:black_concrete
setblock ~113 ~-1 ~39 minecraft:black_concrete
setblock ~39 ~-1 ~-113 minecraft:black_concrete
setblock ~39 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~39 minecraft:black_concrete
setblock ~112 ~-1 ~39 minecraft:black_concrete
setblock ~40 ~-1 ~-114 minecraft:black_concrete
setblock ~40 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~40 minecraft:black_concrete
setblock ~113 ~-1 ~40 minecraft:black_concrete
setblock ~40 ~-1 ~-113 minecraft:black_concrete
setblock ~40 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~40 minecraft:black_concrete
setblock ~112 ~-1 ~40 minecraft:black_concrete
setblock ~41 ~-1 ~-114 minecraft:black_concrete
setblock ~41 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~41 minecraft:black_concrete
setblock ~113 ~-1 ~41 minecraft:black_concrete
setblock ~41 ~-1 ~-113 minecraft:black_concrete
setblock ~41 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~41 minecraft:black_concrete
setblock ~112 ~-1 ~41 minecraft:black_concrete
setblock ~42 ~-1 ~-114 minecraft:black_concrete
setblock ~42 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~42 minecraft:black_concrete
setblock ~113 ~-1 ~42 minecraft:black_concrete
setblock ~42 ~-1 ~-113 minecraft:black_concrete
setblock ~42 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~42 minecraft:black_concrete
setblock ~112 ~-1 ~42 minecraft:black_concrete
setblock ~43 ~-1 ~-114 minecraft:black_concrete
setblock ~43 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~43 minecraft:black_concrete
setblock ~113 ~-1 ~43 minecraft:black_concrete
setblock ~43 ~-1 ~-113 minecraft:black_concrete
setblock ~43 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~43 minecraft:black_concrete
setblock ~112 ~-1 ~43 minecraft:black_concrete
setblock ~44 ~-1 ~-114 minecraft:black_concrete
setblock ~44 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~44 minecraft:black_concrete
setblock ~113 ~-1 ~44 minecraft:black_concrete
setblock ~44 ~-1 ~-113 minecraft:black_concrete
setblock ~44 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~44 minecraft:black_concrete
setblock ~112 ~-1 ~44 minecraft:black_concrete
setblock ~45 ~-1 ~-114 minecraft:black_concrete
setblock ~45 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~45 minecraft:black_concrete
setblock ~113 ~-1 ~45 minecraft:black_concrete
setblock ~45 ~-1 ~-113 minecraft:black_concrete
setblock ~45 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~45 minecraft:black_concrete
setblock ~112 ~-1 ~45 minecraft:black_concrete
setblock ~46 ~-1 ~-114 minecraft:black_concrete
setblock ~46 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~46 minecraft:black_concrete
setblock ~113 ~-1 ~46 minecraft:black_concrete
setblock ~46 ~-1 ~-113 minecraft:black_concrete
setblock ~46 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~46 minecraft:black_concrete
setblock ~112 ~-1 ~46 minecraft:black_concrete
setblock ~47 ~-1 ~-114 minecraft:black_concrete
setblock ~47 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~47 minecraft:black_concrete
setblock ~113 ~-1 ~47 minecraft:black_concrete
setblock ~47 ~-1 ~-113 minecraft:black_concrete
setblock ~47 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~47 minecraft:black_concrete
setblock ~112 ~-1 ~47 minecraft:black_concrete
setblock ~48 ~-1 ~-114 minecraft:black_concrete
setblock ~48 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~48 minecraft:black_concrete
setblock ~113 ~-1 ~48 minecraft:black_concrete
setblock ~48 ~-1 ~-113 minecraft:black_concrete
setblock ~48 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~48 minecraft:black_concrete
setblock ~112 ~-1 ~48 minecraft:black_concrete
setblock ~49 ~-1 ~-114 minecraft:black_concrete
setblock ~49 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~49 minecraft:black_concrete
setblock ~113 ~-1 ~49 minecraft:black_concrete
setblock ~49 ~-1 ~-113 minecraft:black_concrete
setblock ~49 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~49 minecraft:black_concrete
setblock ~112 ~-1 ~49 minecraft:black_concrete
setblock ~50 ~-1 ~-114 minecraft:black_concrete
setblock ~50 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~50 minecraft:black_concrete
setblock ~113 ~-1 ~50 minecraft:black_concrete
setblock ~50 ~-1 ~-113 minecraft:black_concrete
setblock ~50 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~50 minecraft:black_concrete
setblock ~112 ~-1 ~50 minecraft:black_concrete
setblock ~51 ~-1 ~-114 minecraft:black_concrete
setblock ~51 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~51 minecraft:black_concrete
setblock ~113 ~-1 ~51 minecraft:black_concrete
setblock ~51 ~-1 ~-113 minecraft:black_concrete
setblock ~51 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~51 minecraft:black_concrete
setblock ~112 ~-1 ~51 minecraft:black_concrete
setblock ~52 ~-1 ~-114 minecraft:black_concrete
setblock ~52 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~52 minecraft:black_concrete
setblock ~113 ~-1 ~52 minecraft:black_concrete
setblock ~52 ~-1 ~-113 minecraft:black_concrete
setblock ~52 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~52 minecraft:black_concrete
setblock ~112 ~-1 ~52 minecraft:black_concrete
setblock ~53 ~-1 ~-114 minecraft:black_concrete
setblock ~53 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~53 minecraft:black_concrete
setblock ~113 ~-1 ~53 minecraft:black_concrete
setblock ~53 ~-1 ~-113 minecraft:black_concrete
setblock ~53 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~53 minecraft:black_concrete
setblock ~112 ~-1 ~53 minecraft:black_concrete
setblock ~54 ~-1 ~-114 minecraft:black_concrete
setblock ~54 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~54 minecraft:black_concrete
setblock ~113 ~-1 ~54 minecraft:black_concrete
setblock ~54 ~-1 ~-113 minecraft:black_concrete
setblock ~54 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~54 minecraft:black_concrete
setblock ~112 ~-1 ~54 minecraft:black_concrete
setblock ~55 ~-1 ~-114 minecraft:black_concrete
setblock ~55 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~55 minecraft:black_concrete
setblock ~113 ~-1 ~55 minecraft:black_concrete
setblock ~55 ~-1 ~-113 minecraft:black_concrete
setblock ~55 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~55 minecraft:black_concrete
setblock ~112 ~-1 ~55 minecraft:black_concrete
setblock ~56 ~-1 ~-114 minecraft:black_concrete
setblock ~56 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~56 minecraft:black_concrete
setblock ~113 ~-1 ~56 minecraft:black_concrete
setblock ~56 ~-1 ~-113 minecraft:black_concrete
setblock ~56 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~56 minecraft:black_concrete
setblock ~112 ~-1 ~56 minecraft:black_concrete
setblock ~57 ~-1 ~-114 minecraft:black_concrete
setblock ~57 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~57 minecraft:black_concrete
setblock ~113 ~-1 ~57 minecraft:black_concrete
setblock ~57 ~-1 ~-113 minecraft:black_concrete
setblock ~57 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~57 minecraft:black_concrete
setblock ~112 ~-1 ~57 minecraft:black_concrete
setblock ~58 ~-1 ~-114 minecraft:black_concrete
setblock ~58 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~58 minecraft:black_concrete
setblock ~113 ~-1 ~58 minecraft:black_concrete
setblock ~58 ~-1 ~-113 minecraft:black_concrete
setblock ~58 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~58 minecraft:black_concrete
setblock ~112 ~-1 ~58 minecraft:black_concrete
setblock ~59 ~-1 ~-114 minecraft:black_concrete
setblock ~59 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~59 minecraft:black_concrete
setblock ~113 ~-1 ~59 minecraft:black_concrete
setblock ~59 ~-1 ~-113 minecraft:black_concrete
setblock ~59 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~59 minecraft:black_concrete
setblock ~112 ~-1 ~59 minecraft:black_concrete
setblock ~60 ~-1 ~-114 minecraft:black_concrete
setblock ~60 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~60 minecraft:black_concrete
setblock ~113 ~-1 ~60 minecraft:black_concrete
setblock ~60 ~-1 ~-113 minecraft:black_concrete
setblock ~60 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~60 minecraft:black_concrete
setblock ~112 ~-1 ~60 minecraft:black_concrete
setblock ~61 ~-1 ~-114 minecraft:black_concrete
setblock ~61 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~61 minecraft:black_concrete
setblock ~113 ~-1 ~61 minecraft:black_concrete
setblock ~61 ~-1 ~-113 minecraft:black_concrete
setblock ~61 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~61 minecraft:black_concrete
setblock ~112 ~-1 ~61 minecraft:black_concrete
setblock ~62 ~-1 ~-114 minecraft:black_concrete
setblock ~62 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~62 minecraft:black_concrete
setblock ~113 ~-1 ~62 minecraft:black_concrete
setblock ~62 ~-1 ~-113 minecraft:black_concrete
setblock ~62 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~62 minecraft:black_concrete
setblock ~112 ~-1 ~62 minecraft:black_concrete
setblock ~63 ~-1 ~-114 minecraft:black_concrete
setblock ~63 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~63 minecraft:black_concrete
setblock ~113 ~-1 ~63 minecraft:black_concrete
setblock ~63 ~-1 ~-113 minecraft:black_concrete
setblock ~63 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~63 minecraft:black_concrete
setblock ~112 ~-1 ~63 minecraft:black_concrete
setblock ~64 ~-1 ~-114 minecraft:black_concrete
setblock ~64 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~64 minecraft:black_concrete
setblock ~113 ~-1 ~64 minecraft:black_concrete
setblock ~64 ~-1 ~-113 minecraft:black_concrete
setblock ~64 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~64 minecraft:black_concrete
setblock ~112 ~-1 ~64 minecraft:black_concrete
setblock ~65 ~-1 ~-114 minecraft:black_concrete
setblock ~65 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~65 minecraft:black_concrete
setblock ~113 ~-1 ~65 minecraft:black_concrete
setblock ~65 ~-1 ~-113 minecraft:black_concrete
setblock ~65 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~65 minecraft:black_concrete
setblock ~112 ~-1 ~65 minecraft:black_concrete
setblock ~66 ~-1 ~-114 minecraft:black_concrete
setblock ~66 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~66 minecraft:black_concrete
setblock ~113 ~-1 ~66 minecraft:black_concrete
setblock ~66 ~-1 ~-113 minecraft:black_concrete
setblock ~66 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~66 minecraft:black_concrete
setblock ~112 ~-1 ~66 minecraft:black_concrete
setblock ~67 ~-1 ~-114 minecraft:black_concrete
setblock ~67 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~67 minecraft:black_concrete
setblock ~113 ~-1 ~67 minecraft:black_concrete
setblock ~67 ~-1 ~-113 minecraft:black_concrete
setblock ~67 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~67 minecraft:black_concrete
setblock ~112 ~-1 ~67 minecraft:black_concrete
setblock ~68 ~-1 ~-114 minecraft:black_concrete
setblock ~68 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~68 minecraft:black_concrete
setblock ~113 ~-1 ~68 minecraft:black_concrete
setblock ~68 ~-1 ~-113 minecraft:black_concrete
setblock ~68 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~68 minecraft:black_concrete
setblock ~112 ~-1 ~68 minecraft:black_concrete
setblock ~69 ~-1 ~-114 minecraft:black_concrete
setblock ~69 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~69 minecraft:black_concrete
setblock ~113 ~-1 ~69 minecraft:black_concrete
setblock ~69 ~-1 ~-113 minecraft:black_concrete
setblock ~69 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~69 minecraft:black_concrete
setblock ~112 ~-1 ~69 minecraft:black_concrete
setblock ~70 ~-1 ~-114 minecraft:black_concrete
setblock ~70 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~70 minecraft:black_concrete
setblock ~113 ~-1 ~70 minecraft:black_concrete
setblock ~70 ~-1 ~-113 minecraft:black_concrete
setblock ~70 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~70 minecraft:black_concrete
setblock ~112 ~-1 ~70 minecraft:black_concrete
setblock ~71 ~-1 ~-114 minecraft:black_concrete
setblock ~71 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~71 minecraft:black_concrete
setblock ~113 ~-1 ~71 minecraft:black_concrete
setblock ~71 ~-1 ~-113 minecraft:black_concrete
setblock ~71 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~71 minecraft:black_concrete
setblock ~112 ~-1 ~71 minecraft:black_concrete
setblock ~72 ~-1 ~-114 minecraft:black_concrete
setblock ~72 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~72 minecraft:black_concrete
setblock ~113 ~-1 ~72 minecraft:black_concrete
setblock ~72 ~-1 ~-113 minecraft:black_concrete
setblock ~72 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~72 minecraft:black_concrete
setblock ~112 ~-1 ~72 minecraft:black_concrete
setblock ~73 ~-1 ~-114 minecraft:black_concrete
setblock ~73 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~73 minecraft:black_concrete
setblock ~113 ~-1 ~73 minecraft:black_concrete
setblock ~73 ~-1 ~-113 minecraft:black_concrete
setblock ~73 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~73 minecraft:black_concrete
setblock ~112 ~-1 ~73 minecraft:black_concrete
setblock ~74 ~-1 ~-114 minecraft:black_concrete
setblock ~74 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~74 minecraft:black_concrete
setblock ~113 ~-1 ~74 minecraft:black_concrete
setblock ~74 ~-1 ~-113 minecraft:black_concrete
setblock ~74 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~74 minecraft:black_concrete
setblock ~112 ~-1 ~74 minecraft:black_concrete
setblock ~75 ~-1 ~-114 minecraft:black_concrete
setblock ~75 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~75 minecraft:black_concrete
setblock ~113 ~-1 ~75 minecraft:black_concrete
setblock ~75 ~-1 ~-113 minecraft:black_concrete
setblock ~75 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~75 minecraft:black_concrete
setblock ~112 ~-1 ~75 minecraft:black_concrete
setblock ~76 ~-1 ~-114 minecraft:black_concrete
setblock ~76 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~76 minecraft:black_concrete
setblock ~113 ~-1 ~76 minecraft:black_concrete
setblock ~76 ~-1 ~-113 minecraft:black_concrete
setblock ~76 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~76 minecraft:black_concrete
setblock ~112 ~-1 ~76 minecraft:black_concrete
setblock ~77 ~-1 ~-114 minecraft:black_concrete
setblock ~77 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~77 minecraft:black_concrete
setblock ~113 ~-1 ~77 minecraft:black_concrete
setblock ~77 ~-1 ~-113 minecraft:black_concrete
setblock ~77 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~77 minecraft:black_concrete
setblock ~112 ~-1 ~77 minecraft:black_concrete
setblock ~78 ~-1 ~-114 minecraft:black_concrete
setblock ~78 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~78 minecraft:black_concrete
setblock ~113 ~-1 ~78 minecraft:black_concrete
setblock ~78 ~-1 ~-113 minecraft:black_concrete
setblock ~78 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~78 minecraft:black_concrete
setblock ~112 ~-1 ~78 minecraft:black_concrete
setblock ~79 ~-1 ~-114 minecraft:black_concrete
setblock ~79 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~79 minecraft:black_concrete
setblock ~113 ~-1 ~79 minecraft:black_concrete
setblock ~79 ~-1 ~-113 minecraft:black_concrete
setblock ~79 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~79 minecraft:black_concrete
setblock ~112 ~-1 ~79 minecraft:black_concrete
setblock ~80 ~-1 ~-114 minecraft:black_concrete
setblock ~80 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~80 minecraft:black_concrete
setblock ~113 ~-1 ~80 minecraft:black_concrete
setblock ~80 ~-1 ~-113 minecraft:black_concrete
setblock ~80 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~80 minecraft:black_concrete
setblock ~112 ~-1 ~80 minecraft:black_concrete
setblock ~81 ~-1 ~-114 minecraft:black_concrete
setblock ~81 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~81 minecraft:black_concrete
setblock ~113 ~-1 ~81 minecraft:black_concrete
setblock ~81 ~-1 ~-113 minecraft:black_concrete
setblock ~81 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~81 minecraft:black_concrete
setblock ~112 ~-1 ~81 minecraft:black_concrete
setblock ~82 ~-1 ~-114 minecraft:black_concrete
setblock ~82 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~82 minecraft:black_concrete
setblock ~113 ~-1 ~82 minecraft:black_concrete
setblock ~82 ~-1 ~-113 minecraft:black_concrete
setblock ~82 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~82 minecraft:black_concrete
setblock ~112 ~-1 ~82 minecraft:black_concrete
setblock ~83 ~-1 ~-114 minecraft:black_concrete
setblock ~83 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~83 minecraft:black_concrete
setblock ~113 ~-1 ~83 minecraft:black_concrete
setblock ~83 ~-1 ~-113 minecraft:black_concrete
setblock ~83 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~83 minecraft:black_concrete
setblock ~112 ~-1 ~83 minecraft:black_concrete
setblock ~84 ~-1 ~-114 minecraft:black_concrete
setblock ~84 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~84 minecraft:black_concrete
setblock ~113 ~-1 ~84 minecraft:black_concrete
setblock ~84 ~-1 ~-113 minecraft:black_concrete
setblock ~84 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~84 minecraft:black_concrete
setblock ~112 ~-1 ~84 minecraft:black_concrete
setblock ~85 ~-1 ~-114 minecraft:black_concrete
setblock ~85 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~85 minecraft:black_concrete
setblock ~113 ~-1 ~85 minecraft:black_concrete
setblock ~85 ~-1 ~-113 minecraft:black_concrete
setblock ~85 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~85 minecraft:black_concrete
setblock ~112 ~-1 ~85 minecraft:black_concrete
setblock ~86 ~-1 ~-114 minecraft:black_concrete
setblock ~86 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~86 minecraft:black_concrete
setblock ~113 ~-1 ~86 minecraft:black_concrete
setblock ~86 ~-1 ~-113 minecraft:black_concrete
setblock ~86 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~86 minecraft:black_concrete
setblock ~112 ~-1 ~86 minecraft:black_concrete
setblock ~87 ~-1 ~-114 minecraft:black_concrete
setblock ~87 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~87 minecraft:black_concrete
setblock ~113 ~-1 ~87 minecraft:black_concrete
setblock ~87 ~-1 ~-113 minecraft:black_concrete
setblock ~87 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~87 minecraft:black_concrete
setblock ~112 ~-1 ~87 minecraft:black_concrete
setblock ~88 ~-1 ~-114 minecraft:black_concrete
setblock ~88 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~88 minecraft:black_concrete
setblock ~113 ~-1 ~88 minecraft:black_concrete
setblock ~88 ~-1 ~-113 minecraft:black_concrete
setblock ~88 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~88 minecraft:black_concrete
setblock ~112 ~-1 ~88 minecraft:black_concrete
setblock ~89 ~-1 ~-114 minecraft:black_concrete
setblock ~89 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~89 minecraft:black_concrete
setblock ~113 ~-1 ~89 minecraft:black_concrete
setblock ~89 ~-1 ~-113 minecraft:black_concrete
setblock ~89 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~89 minecraft:black_concrete
setblock ~112 ~-1 ~89 minecraft:black_concrete
setblock ~90 ~-1 ~-114 minecraft:black_concrete
setblock ~90 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~90 minecraft:black_concrete
setblock ~113 ~-1 ~90 minecraft:black_concrete
setblock ~90 ~-1 ~-113 minecraft:black_concrete
setblock ~90 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~90 minecraft:black_concrete
setblock ~112 ~-1 ~90 minecraft:black_concrete
setblock ~91 ~-1 ~-114 minecraft:black_concrete
setblock ~91 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~91 minecraft:black_concrete
setblock ~113 ~-1 ~91 minecraft:black_concrete
setblock ~91 ~-1 ~-113 minecraft:black_concrete
setblock ~91 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~91 minecraft:black_concrete
setblock ~112 ~-1 ~91 minecraft:black_concrete
setblock ~92 ~-1 ~-114 minecraft:black_concrete
setblock ~92 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~92 minecraft:black_concrete
setblock ~113 ~-1 ~92 minecraft:black_concrete
setblock ~92 ~-1 ~-113 minecraft:black_concrete
setblock ~92 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~92 minecraft:black_concrete
setblock ~112 ~-1 ~92 minecraft:black_concrete
setblock ~93 ~-1 ~-114 minecraft:black_concrete
setblock ~93 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~93 minecraft:black_concrete
setblock ~113 ~-1 ~93 minecraft:black_concrete
setblock ~93 ~-1 ~-113 minecraft:black_concrete
setblock ~93 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~93 minecraft:black_concrete
setblock ~112 ~-1 ~93 minecraft:black_concrete
setblock ~94 ~-1 ~-114 minecraft:black_concrete
setblock ~94 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~94 minecraft:black_concrete
setblock ~113 ~-1 ~94 minecraft:black_concrete
setblock ~94 ~-1 ~-113 minecraft:black_concrete
setblock ~94 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~94 minecraft:black_concrete
setblock ~112 ~-1 ~94 minecraft:black_concrete
setblock ~95 ~-1 ~-114 minecraft:black_concrete
setblock ~95 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~95 minecraft:black_concrete
setblock ~113 ~-1 ~95 minecraft:black_concrete
setblock ~95 ~-1 ~-113 minecraft:black_concrete
setblock ~95 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~95 minecraft:black_concrete
setblock ~112 ~-1 ~95 minecraft:black_concrete
setblock ~96 ~-1 ~-114 minecraft:black_concrete
setblock ~96 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~96 minecraft:black_concrete
setblock ~113 ~-1 ~96 minecraft:black_concrete
setblock ~96 ~-1 ~-113 minecraft:black_concrete
setblock ~96 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~96 minecraft:black_concrete
setblock ~112 ~-1 ~96 minecraft:black_concrete
setblock ~97 ~-1 ~-114 minecraft:black_concrete
setblock ~97 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~97 minecraft:black_concrete
setblock ~113 ~-1 ~97 minecraft:black_concrete
setblock ~97 ~-1 ~-113 minecraft:black_concrete
setblock ~97 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~97 minecraft:black_concrete
setblock ~112 ~-1 ~97 minecraft:black_concrete
setblock ~98 ~-1 ~-114 minecraft:black_concrete
setblock ~98 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~98 minecraft:black_concrete
setblock ~113 ~-1 ~98 minecraft:black_concrete
setblock ~98 ~-1 ~-113 minecraft:black_concrete
setblock ~98 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~98 minecraft:black_concrete
setblock ~112 ~-1 ~98 minecraft:black_concrete
setblock ~99 ~-1 ~-114 minecraft:black_concrete
setblock ~99 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~99 minecraft:black_concrete
setblock ~113 ~-1 ~99 minecraft:black_concrete
setblock ~99 ~-1 ~-113 minecraft:black_concrete
setblock ~99 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~99 minecraft:black_concrete
setblock ~112 ~-1 ~99 minecraft:black_concrete
setblock ~100 ~-1 ~-114 minecraft:black_concrete
setblock ~100 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~100 minecraft:black_concrete
setblock ~113 ~-1 ~100 minecraft:black_concrete
setblock ~100 ~-1 ~-113 minecraft:black_concrete
setblock ~100 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~100 minecraft:black_concrete
setblock ~112 ~-1 ~100 minecraft:black_concrete
setblock ~101 ~-1 ~-114 minecraft:black_concrete
setblock ~101 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~101 minecraft:black_concrete
setblock ~113 ~-1 ~101 minecraft:black_concrete
setblock ~101 ~-1 ~-113 minecraft:black_concrete
setblock ~101 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~101 minecraft:black_concrete
setblock ~112 ~-1 ~101 minecraft:black_concrete
setblock ~102 ~-1 ~-114 minecraft:black_concrete
setblock ~102 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~102 minecraft:black_concrete
setblock ~113 ~-1 ~102 minecraft:black_concrete
setblock ~102 ~-1 ~-113 minecraft:black_concrete
setblock ~102 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~102 minecraft:black_concrete
setblock ~112 ~-1 ~102 minecraft:black_concrete
setblock ~103 ~-1 ~-114 minecraft:black_concrete
setblock ~103 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~103 minecraft:black_concrete
setblock ~113 ~-1 ~103 minecraft:black_concrete
setblock ~103 ~-1 ~-113 minecraft:black_concrete
setblock ~103 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~103 minecraft:black_concrete
setblock ~112 ~-1 ~103 minecraft:black_concrete
setblock ~104 ~-1 ~-114 minecraft:black_concrete
setblock ~104 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~104 minecraft:black_concrete
setblock ~113 ~-1 ~104 minecraft:black_concrete
setblock ~104 ~-1 ~-113 minecraft:black_concrete
setblock ~104 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~104 minecraft:black_concrete
setblock ~112 ~-1 ~104 minecraft:black_concrete
setblock ~105 ~-1 ~-114 minecraft:black_concrete
setblock ~105 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~105 minecraft:black_concrete
setblock ~113 ~-1 ~105 minecraft:black_concrete
setblock ~105 ~-1 ~-113 minecraft:black_concrete
setblock ~105 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~105 minecraft:black_concrete
setblock ~112 ~-1 ~105 minecraft:black_concrete
setblock ~106 ~-1 ~-114 minecraft:black_concrete
setblock ~106 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~106 minecraft:black_concrete
setblock ~113 ~-1 ~106 minecraft:black_concrete
setblock ~106 ~-1 ~-113 minecraft:black_concrete
setblock ~106 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~106 minecraft:black_concrete
setblock ~112 ~-1 ~106 minecraft:black_concrete
setblock ~107 ~-1 ~-114 minecraft:black_concrete
setblock ~107 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~107 minecraft:black_concrete
setblock ~113 ~-1 ~107 minecraft:black_concrete
setblock ~107 ~-1 ~-113 minecraft:black_concrete
setblock ~107 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~107 minecraft:black_concrete
setblock ~112 ~-1 ~107 minecraft:black_concrete
setblock ~108 ~-1 ~-114 minecraft:black_concrete
setblock ~108 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~108 minecraft:black_concrete
setblock ~113 ~-1 ~108 minecraft:black_concrete
setblock ~108 ~-1 ~-113 minecraft:black_concrete
setblock ~108 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~108 minecraft:black_concrete
setblock ~112 ~-1 ~108 minecraft:black_concrete
setblock ~109 ~-1 ~-114 minecraft:black_concrete
setblock ~109 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~109 minecraft:black_concrete
setblock ~113 ~-1 ~109 minecraft:black_concrete
setblock ~109 ~-1 ~-113 minecraft:black_concrete
setblock ~109 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~109 minecraft:black_concrete
setblock ~112 ~-1 ~109 minecraft:black_concrete
setblock ~110 ~-1 ~-114 minecraft:black_concrete
setblock ~110 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~110 minecraft:black_concrete
setblock ~113 ~-1 ~110 minecraft:black_concrete
setblock ~110 ~-1 ~-113 minecraft:black_concrete
setblock ~110 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~110 minecraft:black_concrete
setblock ~112 ~-1 ~110 minecraft:black_concrete
setblock ~111 ~-1 ~-114 minecraft:black_concrete
setblock ~111 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~111 minecraft:black_concrete
setblock ~113 ~-1 ~111 minecraft:black_concrete
setblock ~111 ~-1 ~-113 minecraft:black_concrete
setblock ~111 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~111 minecraft:black_concrete
setblock ~112 ~-1 ~111 minecraft:black_concrete
setblock ~112 ~-1 ~-114 minecraft:black_concrete
setblock ~112 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~112 minecraft:black_concrete
setblock ~113 ~-1 ~112 minecraft:black_concrete
setblock ~112 ~-1 ~-113 minecraft:black_concrete
setblock ~112 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~112 minecraft:black_concrete
setblock ~112 ~-1 ~112 minecraft:black_concrete
setblock ~113 ~-1 ~-114 minecraft:black_concrete
setblock ~113 ~-1 ~113 minecraft:black_concrete
setblock ~-114 ~-1 ~113 minecraft:black_concrete
setblock ~113 ~-1 ~113 minecraft:black_concrete
setblock ~113 ~-1 ~-113 minecraft:black_concrete
setblock ~113 ~-1 ~112 minecraft:black_concrete
setblock ~-113 ~-1 ~113 minecraft:black_concrete
setblock ~112 ~-1 ~113 minecraft:black_concrete
setblock ~-113 ~0 ~-114 minecraft:lantern
setblock ~-113 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-113 minecraft:lantern
setblock ~113 ~0 ~-113 minecraft:lantern
setblock ~-111 ~0 ~-114 minecraft:lantern
setblock ~-111 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-111 minecraft:lantern
setblock ~113 ~0 ~-111 minecraft:lantern
setblock ~-109 ~0 ~-114 minecraft:lantern
setblock ~-109 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-109 minecraft:lantern
setblock ~113 ~0 ~-109 minecraft:lantern
setblock ~-107 ~0 ~-114 minecraft:lantern
setblock ~-107 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-107 minecraft:lantern
setblock ~113 ~0 ~-107 minecraft:lantern
setblock ~-105 ~0 ~-114 minecraft:lantern
setblock ~-105 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-105 minecraft:lantern
setblock ~113 ~0 ~-105 minecraft:lantern
setblock ~-103 ~0 ~-114 minecraft:lantern
setblock ~-103 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-103 minecraft:lantern
setblock ~113 ~0 ~-103 minecraft:lantern
setblock ~-101 ~0 ~-114 minecraft:lantern
setblock ~-101 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-101 minecraft:lantern
setblock ~113 ~0 ~-101 minecraft:lantern
setblock ~-99 ~0 ~-114 minecraft:lantern
setblock ~-99 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-99 minecraft:lantern
setblock ~113 ~0 ~-99 minecraft:lantern
setblock ~-97 ~0 ~-114 minecraft:lantern
setblock ~-97 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-97 minecraft:lantern
setblock ~113 ~0 ~-97 minecraft:lantern
setblock ~-95 ~0 ~-114 minecraft:lantern
setblock ~-95 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-95 minecraft:lantern
setblock ~113 ~0 ~-95 minecraft:lantern
setblock ~-93 ~0 ~-114 minecraft:lantern
setblock ~-93 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-93 minecraft:lantern
setblock ~113 ~0 ~-93 minecraft:lantern
setblock ~-91 ~0 ~-114 minecraft:lantern
setblock ~-91 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-91 minecraft:lantern
setblock ~113 ~0 ~-91 minecraft:lantern
setblock ~-89 ~0 ~-114 minecraft:lantern
setblock ~-89 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-89 minecraft:lantern
setblock ~113 ~0 ~-89 minecraft:lantern
setblock ~-87 ~0 ~-114 minecraft:lantern
setblock ~-87 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-87 minecraft:lantern
setblock ~113 ~0 ~-87 minecraft:lantern
setblock ~-85 ~0 ~-114 minecraft:lantern
setblock ~-85 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-85 minecraft:lantern
setblock ~113 ~0 ~-85 minecraft:lantern
setblock ~-83 ~0 ~-114 minecraft:lantern
setblock ~-83 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-83 minecraft:lantern
setblock ~113 ~0 ~-83 minecraft:lantern
setblock ~-81 ~0 ~-114 minecraft:lantern
setblock ~-81 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-81 minecraft:lantern
setblock ~113 ~0 ~-81 minecraft:lantern
setblock ~-79 ~0 ~-114 minecraft:lantern
setblock ~-79 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-79 minecraft:lantern
setblock ~113 ~0 ~-79 minecraft:lantern
setblock ~-77 ~0 ~-114 minecraft:lantern
setblock ~-77 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-77 minecraft:lantern
setblock ~113 ~0 ~-77 minecraft:lantern
setblock ~-75 ~0 ~-114 minecraft:lantern
setblock ~-75 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-75 minecraft:lantern
setblock ~113 ~0 ~-75 minecraft:lantern
setblock ~-73 ~0 ~-114 minecraft:lantern
setblock ~-73 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-73 minecraft:lantern
setblock ~113 ~0 ~-73 minecraft:lantern
setblock ~-71 ~0 ~-114 minecraft:lantern
setblock ~-71 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-71 minecraft:lantern
setblock ~113 ~0 ~-71 minecraft:lantern
setblock ~-69 ~0 ~-114 minecraft:lantern
setblock ~-69 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-69 minecraft:lantern
setblock ~113 ~0 ~-69 minecraft:lantern
setblock ~-67 ~0 ~-114 minecraft:lantern
setblock ~-67 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-67 minecraft:lantern
setblock ~113 ~0 ~-67 minecraft:lantern
setblock ~-65 ~0 ~-114 minecraft:lantern
setblock ~-65 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-65 minecraft:lantern
setblock ~113 ~0 ~-65 minecraft:lantern
setblock ~-63 ~0 ~-114 minecraft:lantern
setblock ~-63 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-63 minecraft:lantern
setblock ~113 ~0 ~-63 minecraft:lantern
setblock ~-61 ~0 ~-114 minecraft:lantern
setblock ~-61 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-61 minecraft:lantern
setblock ~113 ~0 ~-61 minecraft:lantern
setblock ~-59 ~0 ~-114 minecraft:lantern
setblock ~-59 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-59 minecraft:lantern
setblock ~113 ~0 ~-59 minecraft:lantern
setblock ~-57 ~0 ~-114 minecraft:lantern
setblock ~-57 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-57 minecraft:lantern
setblock ~113 ~0 ~-57 minecraft:lantern
setblock ~-55 ~0 ~-114 minecraft:lantern
setblock ~-55 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-55 minecraft:lantern
setblock ~113 ~0 ~-55 minecraft:lantern
setblock ~-53 ~0 ~-114 minecraft:lantern
setblock ~-53 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-53 minecraft:lantern
setblock ~113 ~0 ~-53 minecraft:lantern
setblock ~-51 ~0 ~-114 minecraft:lantern
setblock ~-51 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-51 minecraft:lantern
setblock ~113 ~0 ~-51 minecraft:lantern
setblock ~-49 ~0 ~-114 minecraft:lantern
setblock ~-49 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-49 minecraft:lantern
setblock ~113 ~0 ~-49 minecraft:lantern
setblock ~-47 ~0 ~-114 minecraft:lantern
setblock ~-47 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-47 minecraft:lantern
setblock ~113 ~0 ~-47 minecraft:lantern
setblock ~-45 ~0 ~-114 minecraft:lantern
setblock ~-45 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-45 minecraft:lantern
setblock ~113 ~0 ~-45 minecraft:lantern
setblock ~-43 ~0 ~-114 minecraft:lantern
setblock ~-43 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-43 minecraft:lantern
setblock ~113 ~0 ~-43 minecraft:lantern
setblock ~-41 ~0 ~-114 minecraft:lantern
setblock ~-41 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-41 minecraft:lantern
setblock ~113 ~0 ~-41 minecraft:lantern
setblock ~-39 ~0 ~-114 minecraft:lantern
setblock ~-39 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-39 minecraft:lantern
setblock ~113 ~0 ~-39 minecraft:lantern
setblock ~-37 ~0 ~-114 minecraft:lantern
setblock ~-37 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-37 minecraft:lantern
setblock ~113 ~0 ~-37 minecraft:lantern
setblock ~-35 ~0 ~-114 minecraft:lantern
setblock ~-35 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-35 minecraft:lantern
setblock ~113 ~0 ~-35 minecraft:lantern
setblock ~-33 ~0 ~-114 minecraft:lantern
setblock ~-33 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-33 minecraft:lantern
setblock ~113 ~0 ~-33 minecraft:lantern
setblock ~-31 ~0 ~-114 minecraft:lantern
setblock ~-31 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-31 minecraft:lantern
setblock ~113 ~0 ~-31 minecraft:lantern
setblock ~-29 ~0 ~-114 minecraft:lantern
setblock ~-29 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-29 minecraft:lantern
setblock ~113 ~0 ~-29 minecraft:lantern
setblock ~-27 ~0 ~-114 minecraft:lantern
setblock ~-27 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-27 minecraft:lantern
setblock ~113 ~0 ~-27 minecraft:lantern
setblock ~-25 ~0 ~-114 minecraft:lantern
setblock ~-25 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-25 minecraft:lantern
setblock ~113 ~0 ~-25 minecraft:lantern
setblock ~-23 ~0 ~-114 minecraft:lantern
setblock ~-23 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-23 minecraft:lantern
setblock ~113 ~0 ~-23 minecraft:lantern
setblock ~-21 ~0 ~-114 minecraft:lantern
setblock ~-21 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-21 minecraft:lantern
setblock ~113 ~0 ~-21 minecraft:lantern
setblock ~-19 ~0 ~-114 minecraft:lantern
setblock ~-19 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-19 minecraft:lantern
setblock ~113 ~0 ~-19 minecraft:lantern
setblock ~-17 ~0 ~-114 minecraft:lantern
setblock ~-17 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-17 minecraft:lantern
setblock ~113 ~0 ~-17 minecraft:lantern
setblock ~-15 ~0 ~-114 minecraft:lantern
setblock ~-15 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-15 minecraft:lantern
setblock ~113 ~0 ~-15 minecraft:lantern
setblock ~-13 ~0 ~-114 minecraft:lantern
setblock ~-13 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-13 minecraft:lantern
setblock ~113 ~0 ~-13 minecraft:lantern
setblock ~-11 ~0 ~-114 minecraft:lantern
setblock ~-11 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-11 minecraft:lantern
setblock ~113 ~0 ~-11 minecraft:lantern
setblock ~-9 ~0 ~-114 minecraft:lantern
setblock ~-9 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-9 minecraft:lantern
setblock ~113 ~0 ~-9 minecraft:lantern
setblock ~-7 ~0 ~-114 minecraft:lantern
setblock ~-7 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-7 minecraft:lantern
setblock ~113 ~0 ~-7 minecraft:lantern
setblock ~-5 ~0 ~-114 minecraft:lantern
setblock ~-5 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-5 minecraft:lantern
setblock ~113 ~0 ~-5 minecraft:lantern
setblock ~-3 ~0 ~-114 minecraft:lantern
setblock ~-3 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-3 minecraft:lantern
setblock ~113 ~0 ~-3 minecraft:lantern
setblock ~-1 ~0 ~-114 minecraft:lantern
setblock ~-1 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~-1 minecraft:lantern
setblock ~113 ~0 ~-1 minecraft:lantern
setblock ~1 ~0 ~-114 minecraft:lantern
setblock ~1 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~1 minecraft:lantern
setblock ~113 ~0 ~1 minecraft:lantern
setblock ~3 ~0 ~-114 minecraft:lantern
setblock ~3 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~3 minecraft:lantern
setblock ~113 ~0 ~3 minecraft:lantern
setblock ~5 ~0 ~-114 minecraft:lantern
setblock ~5 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~5 minecraft:lantern
setblock ~113 ~0 ~5 minecraft:lantern
setblock ~7 ~0 ~-114 minecraft:lantern
setblock ~7 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~7 minecraft:lantern
setblock ~113 ~0 ~7 minecraft:lantern
setblock ~9 ~0 ~-114 minecraft:lantern
setblock ~9 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~9 minecraft:lantern
setblock ~113 ~0 ~9 minecraft:lantern
setblock ~11 ~0 ~-114 minecraft:lantern
setblock ~11 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~11 minecraft:lantern
setblock ~113 ~0 ~11 minecraft:lantern
setblock ~13 ~0 ~-114 minecraft:lantern
setblock ~13 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~13 minecraft:lantern
setblock ~113 ~0 ~13 minecraft:lantern
setblock ~15 ~0 ~-114 minecraft:lantern
setblock ~15 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~15 minecraft:lantern
setblock ~113 ~0 ~15 minecraft:lantern
setblock ~17 ~0 ~-114 minecraft:lantern
setblock ~17 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~17 minecraft:lantern
setblock ~113 ~0 ~17 minecraft:lantern
setblock ~19 ~0 ~-114 minecraft:lantern
setblock ~19 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~19 minecraft:lantern
setblock ~113 ~0 ~19 minecraft:lantern
setblock ~21 ~0 ~-114 minecraft:lantern
setblock ~21 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~21 minecraft:lantern
setblock ~113 ~0 ~21 minecraft:lantern
setblock ~23 ~0 ~-114 minecraft:lantern
setblock ~23 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~23 minecraft:lantern
setblock ~113 ~0 ~23 minecraft:lantern
setblock ~25 ~0 ~-114 minecraft:lantern
setblock ~25 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~25 minecraft:lantern
setblock ~113 ~0 ~25 minecraft:lantern
setblock ~27 ~0 ~-114 minecraft:lantern
setblock ~27 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~27 minecraft:lantern
setblock ~113 ~0 ~27 minecraft:lantern
setblock ~29 ~0 ~-114 minecraft:lantern
setblock ~29 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~29 minecraft:lantern
setblock ~113 ~0 ~29 minecraft:lantern
setblock ~31 ~0 ~-114 minecraft:lantern
setblock ~31 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~31 minecraft:lantern
setblock ~113 ~0 ~31 minecraft:lantern
setblock ~33 ~0 ~-114 minecraft:lantern
setblock ~33 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~33 minecraft:lantern
setblock ~113 ~0 ~33 minecraft:lantern
setblock ~35 ~0 ~-114 minecraft:lantern
setblock ~35 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~35 minecraft:lantern
setblock ~113 ~0 ~35 minecraft:lantern
setblock ~37 ~0 ~-114 minecraft:lantern
setblock ~37 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~37 minecraft:lantern
setblock ~113 ~0 ~37 minecraft:lantern
setblock ~39 ~0 ~-114 minecraft:lantern
setblock ~39 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~39 minecraft:lantern
setblock ~113 ~0 ~39 minecraft:lantern
setblock ~41 ~0 ~-114 minecraft:lantern
setblock ~41 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~41 minecraft:lantern
setblock ~113 ~0 ~41 minecraft:lantern
setblock ~43 ~0 ~-114 minecraft:lantern
setblock ~43 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~43 minecraft:lantern
setblock ~113 ~0 ~43 minecraft:lantern
setblock ~45 ~0 ~-114 minecraft:lantern
setblock ~45 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~45 minecraft:lantern
setblock ~113 ~0 ~45 minecraft:lantern
setblock ~47 ~0 ~-114 minecraft:lantern
setblock ~47 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~47 minecraft:lantern
setblock ~113 ~0 ~47 minecraft:lantern
setblock ~49 ~0 ~-114 minecraft:lantern
setblock ~49 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~49 minecraft:lantern
setblock ~113 ~0 ~49 minecraft:lantern
setblock ~51 ~0 ~-114 minecraft:lantern
setblock ~51 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~51 minecraft:lantern
setblock ~113 ~0 ~51 minecraft:lantern
setblock ~53 ~0 ~-114 minecraft:lantern
setblock ~53 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~53 minecraft:lantern
setblock ~113 ~0 ~53 minecraft:lantern
setblock ~55 ~0 ~-114 minecraft:lantern
setblock ~55 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~55 minecraft:lantern
setblock ~113 ~0 ~55 minecraft:lantern
setblock ~57 ~0 ~-114 minecraft:lantern
setblock ~57 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~57 minecraft:lantern
setblock ~113 ~0 ~57 minecraft:lantern
setblock ~59 ~0 ~-114 minecraft:lantern
setblock ~59 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~59 minecraft:lantern
setblock ~113 ~0 ~59 minecraft:lantern
setblock ~61 ~0 ~-114 minecraft:lantern
setblock ~61 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~61 minecraft:lantern
setblock ~113 ~0 ~61 minecraft:lantern
setblock ~63 ~0 ~-114 minecraft:lantern
setblock ~63 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~63 minecraft:lantern
setblock ~113 ~0 ~63 minecraft:lantern
setblock ~65 ~0 ~-114 minecraft:lantern
setblock ~65 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~65 minecraft:lantern
setblock ~113 ~0 ~65 minecraft:lantern
setblock ~67 ~0 ~-114 minecraft:lantern
setblock ~67 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~67 minecraft:lantern
setblock ~113 ~0 ~67 minecraft:lantern
setblock ~69 ~0 ~-114 minecraft:lantern
setblock ~69 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~69 minecraft:lantern
setblock ~113 ~0 ~69 minecraft:lantern
setblock ~71 ~0 ~-114 minecraft:lantern
setblock ~71 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~71 minecraft:lantern
setblock ~113 ~0 ~71 minecraft:lantern
setblock ~73 ~0 ~-114 minecraft:lantern
setblock ~73 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~73 minecraft:lantern
setblock ~113 ~0 ~73 minecraft:lantern
setblock ~75 ~0 ~-114 minecraft:lantern
setblock ~75 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~75 minecraft:lantern
setblock ~113 ~0 ~75 minecraft:lantern
setblock ~77 ~0 ~-114 minecraft:lantern
setblock ~77 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~77 minecraft:lantern
setblock ~113 ~0 ~77 minecraft:lantern
setblock ~79 ~0 ~-114 minecraft:lantern
setblock ~79 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~79 minecraft:lantern
setblock ~113 ~0 ~79 minecraft:lantern
setblock ~81 ~0 ~-114 minecraft:lantern
setblock ~81 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~81 minecraft:lantern
setblock ~113 ~0 ~81 minecraft:lantern
setblock ~83 ~0 ~-114 minecraft:lantern
setblock ~83 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~83 minecraft:lantern
setblock ~113 ~0 ~83 minecraft:lantern
setblock ~85 ~0 ~-114 minecraft:lantern
setblock ~85 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~85 minecraft:lantern
setblock ~113 ~0 ~85 minecraft:lantern
setblock ~87 ~0 ~-114 minecraft:lantern
setblock ~87 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~87 minecraft:lantern
setblock ~113 ~0 ~87 minecraft:lantern
setblock ~89 ~0 ~-114 minecraft:lantern
setblock ~89 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~89 minecraft:lantern
setblock ~113 ~0 ~89 minecraft:lantern
setblock ~91 ~0 ~-114 minecraft:lantern
setblock ~91 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~91 minecraft:lantern
setblock ~113 ~0 ~91 minecraft:lantern
setblock ~93 ~0 ~-114 minecraft:lantern
setblock ~93 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~93 minecraft:lantern
setblock ~113 ~0 ~93 minecraft:lantern
setblock ~95 ~0 ~-114 minecraft:lantern
setblock ~95 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~95 minecraft:lantern
setblock ~113 ~0 ~95 minecraft:lantern
setblock ~97 ~0 ~-114 minecraft:lantern
setblock ~97 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~97 minecraft:lantern
setblock ~113 ~0 ~97 minecraft:lantern
setblock ~99 ~0 ~-114 minecraft:lantern
setblock ~99 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~99 minecraft:lantern
setblock ~113 ~0 ~99 minecraft:lantern
setblock ~101 ~0 ~-114 minecraft:lantern
setblock ~101 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~101 minecraft:lantern
setblock ~113 ~0 ~101 minecraft:lantern
setblock ~103 ~0 ~-114 minecraft:lantern
setblock ~103 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~103 minecraft:lantern
setblock ~113 ~0 ~103 minecraft:lantern
setblock ~105 ~0 ~-114 minecraft:lantern
setblock ~105 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~105 minecraft:lantern
setblock ~113 ~0 ~105 minecraft:lantern
setblock ~107 ~0 ~-114 minecraft:lantern
setblock ~107 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~107 minecraft:lantern
setblock ~113 ~0 ~107 minecraft:lantern
setblock ~109 ~0 ~-114 minecraft:lantern
setblock ~109 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~109 minecraft:lantern
setblock ~113 ~0 ~109 minecraft:lantern
setblock ~111 ~0 ~-114 minecraft:lantern
setblock ~111 ~0 ~113 minecraft:lantern
setblock ~-114 ~0 ~111 minecraft:lantern
setblock ~113 ~0 ~111 minecraft:lantern
setblock ~-112 ~0 ~-112 minecraft:glass
setblock ~-112 ~0 ~-110 minecraft:glass
setblock ~-112 ~0 ~-108 minecraft:glass
setblock ~-112 ~0 ~-106 minecraft:glass
setblock ~-112 ~0 ~-104 minecraft:glass
setblock ~-112 ~0 ~-102 minecraft:glass
setblock ~-112 ~0 ~-100 minecraft:glass
setblock ~-112 ~0 ~-98 minecraft:glass
setblock ~-112 ~0 ~-96 minecraft:glass
setblock ~-112 ~0 ~-94 minecraft:glass
setblock ~-112 ~0 ~-92 minecraft:glass
setblock ~-112 ~0 ~-90 minecraft:glass
setblock ~-112 ~0 ~-88 minecraft:glass
setblock ~-112 ~0 ~-86 minecraft:glass
setblock ~-112 ~0 ~-84 minecraft:glass
setblock ~-112 ~0 ~-82 minecraft:glass
setblock ~-112 ~2 ~-112 minecraft:glass
setblock ~-112 ~2 ~-110 minecraft:glass
setblock ~-112 ~2 ~-108 minecraft:glass
setblock ~-112 ~2 ~-106 minecraft:glass
setblock ~-112 ~2 ~-104 minecraft:glass
setblock ~-112 ~2 ~-102 minecraft:glass
setblock ~-112 ~2 ~-100 minecraft:glass
setblock ~-112 ~2 ~-98 minecraft:glass
setblock ~-112 ~2 ~-96 minecraft:glass
setblock ~-112 ~2 ~-94 minecraft:glass
setblock ~-112 ~2 ~-92 minecraft:glass
setblock ~-112 ~2 ~-90 minecraft:glass
setblock ~-112 ~2 ~-88 minecraft:glass
setblock ~-112 ~2 ~-86 minecraft:glass
setblock ~-112 ~2 ~-84 minecraft:glass
setblock ~-112 ~2 ~-82 minecraft:glass
setblock ~-112 ~4 ~-112 minecraft:glass
setblock ~-112 ~4 ~-110 minecraft:glass
setblock ~-112 ~4 ~-108 minecraft:glass
setblock ~-112 ~4 ~-106 minecraft:glass
setblock ~-112 ~4 ~-104 minecraft:glass
setblock ~-112 ~4 ~-102 minecraft:glass
setblock ~-112 ~4 ~-100 minecraft:glass
setblock ~-112 ~4 ~-98 minecraft:glass
setblock ~-112 ~4 ~-96 minecraft:glass
setblock ~-112 ~4 ~-94 minecraft:glass
setblock ~-112 ~4 ~-92 minecraft:glass
setblock ~-112 ~4 ~-90 minecraft:glass
setblock ~-112 ~4 ~-88 minecraft:glass
setblock ~-112 ~4 ~-86 minecraft:glass
setblock ~-112 ~4 ~-84 minecraft:glass
setblock ~-112 ~4 ~-82 minecraft:glass
setblock ~-112 ~6 ~-112 minecraft:glass
setblock ~-112 ~6 ~-110 minecraft:glass
setblock ~-112 ~6 ~-108 minecraft:glass
setblock ~-112 ~6 ~-106 minecraft:glass
setblock ~-112 ~6 ~-104 minecraft:glass
setblock ~-112 ~6 ~-102 minecraft:glass
setblock ~-112 ~6 ~-100 minecraft:glass
setblock ~-112 ~6 ~-98 minecraft:glass
setblock ~-112 ~6 ~-96 minecraft:glass
setblock ~-112 ~6 ~-94 minecraft:glass
setblock ~-112 ~6 ~-92 minecraft:glass
setblock ~-112 ~6 ~-90 minecraft:glass
setblock ~-112 ~6 ~-88 minecraft:glass
setblock ~-112 ~6 ~-86 minecraft:glass
setblock ~-112 ~6 ~-84 minecraft:glass
setblock ~-112 ~6 ~-82 minecraft:glass
setblock ~-112 ~8 ~-112 minecraft:glass
setblock ~-112 ~8 ~-110 minecraft:glass
setblock ~-112 ~8 ~-108 minecraft:glass
setblock ~-112 ~8 ~-106 minecraft:glass
setblock ~-112 ~8 ~-104 minecraft:glass
setblock ~-112 ~8 ~-102 minecraft:glass
setblock ~-112 ~8 ~-100 minecraft:glass
setblock ~-112 ~8 ~-98 minecraft:glass
setblock ~-112 ~8 ~-96 minecraft:glass
setblock ~-112 ~8 ~-94 minecraft:glass
setblock ~-112 ~8 ~-92 minecraft:glass
setblock ~-112 ~8 ~-90 minecraft:glass
setblock ~-112 ~8 ~-88 minecraft:glass
setblock ~-112 ~8 ~-86 minecraft:glass
setblock ~-112 ~8 ~-84 minecraft:glass
setblock ~-112 ~8 ~-82 minecraft:glass
setblock ~-112 ~10 ~-112 minecraft:glass
setblock ~-112 ~10 ~-110 minecraft:glass
setblock ~-112 ~10 ~-108 minecraft:glass
setblock ~-112 ~10 ~-106 minecraft:glass
setblock ~-112 ~10 ~-104 minecraft:glass
setblock ~-112 ~10 ~-102 minecraft:glass
setblock ~-112 ~10 ~-100 minecraft:glass
setblock ~-112 ~10 ~-98 minecraft:glass
setblock ~-112 ~10 ~-96 minecraft:glass
setblock ~-112 ~10 ~-94 minecraft:glass
setblock ~-112 ~10 ~-92 minecraft:glass
setblock ~-112 ~10 ~-90 minecraft:glass
setblock ~-112 ~10 ~-88 minecraft:glass
setblock ~-112 ~10 ~-86 minecraft:glass
setblock ~-112 ~10 ~-84 minecraft:glass
setblock ~-112 ~10 ~-82 minecraft:glass
setblock ~-112 ~12 ~-112 minecraft:glass
setblock ~-112 ~12 ~-110 minecraft:glass
setblock ~-112 ~12 ~-108 minecraft:glass
setblock ~-112 ~12 ~-106 minecraft:glass
setblock ~-112 ~12 ~-104 minecraft:glass
setblock ~-112 ~12 ~-102 minecraft:glass
setblock ~-112 ~12 ~-100 minecraft:glass
setblock ~-112 ~12 ~-98 minecraft:glass
setblock ~-112 ~12 ~-96 minecraft:glass
setblock ~-112 ~12 ~-94 minecraft:glass
setblock ~-112 ~12 ~-92 minecraft:glass
setblock ~-112 ~12 ~-90 minecraft:glass
setblock ~-112 ~12 ~-88 minecraft:glass
setblock ~-112 ~12 ~-86 minecraft:glass
setblock ~-112 ~12 ~-84 minecraft:glass
setblock ~-112 ~12 ~-82 minecraft:glass
setblock ~-112 ~14 ~-112 minecraft:glass
setblock ~-112 ~14 ~-110 minecraft:glass
setblock ~-112 ~14 ~-108 minecraft:glass
setblock ~-112 ~14 ~-106 minecraft:glass
setblock ~-112 ~14 ~-104 minecraft:glass
setblock ~-112 ~14 ~-102 minecraft:glass
setblock ~-112 ~14 ~-100 minecraft:glass
setblock ~-112 ~14 ~-98 minecraft:glass
setblock ~-112 ~14 ~-96 minecraft:glass
setblock ~-112 ~14 ~-94 minecraft:glass
setblock ~-112 ~14 ~-92 minecraft:glass
setblock ~-112 ~14 ~-90 minecraft:glass
setblock ~-112 ~14 ~-88 minecraft:glass
setblock ~-112 ~14 ~-86 minecraft:glass
setblock ~-112 ~14 ~-84 minecraft:glass
setblock ~-112 ~14 ~-82 minecraft:glass
setblock ~-112 ~16 ~-112 minecraft:glass
setblock ~-112 ~16 ~-110 minecraft:glass
setblock ~-112 ~16 ~-108 minecraft:glass
setblock ~-112 ~16 ~-106 minecraft:glass
setblock ~-112 ~16 ~-104 minecraft:glass
setblock ~-112 ~16 ~-102 minecraft:glass
setblock ~-112 ~16 ~-100 minecraft:glass
setblock ~-112 ~16 ~-98 minecraft:glass
setblock ~-112 ~16 ~-96 minecraft:glass
setblock ~-112 ~16 ~-94 minecraft:glass
setblock ~-112 ~16 ~-92 minecraft:glass
setblock ~-112 ~16 ~-90 minecraft:glass
setblock ~-112 ~16 ~-88 minecraft:glass
setblock ~-112 ~16 ~-86 minecraft:glass
setblock ~-112 ~16 ~-84 minecraft:glass
setblock ~-112 ~16 ~-82 minecraft:glass
setblock ~-112 ~18 ~-112 minecraft:glass
setblock ~-112 ~18 ~-110 minecraft:glass
setblock ~-112 ~18 ~-108 minecraft:glass
setblock ~-112 ~18 ~-106 minecraft:glass
setblock ~-112 ~18 ~-104 minecraft:glass
setblock ~-112 ~18 ~-102 minecraft:glass
setblock ~-112 ~18 ~-100 minecraft:glass
setblock ~-112 ~18 ~-98 minecraft:glass
setblock ~-112 ~18 ~-96 minecraft:glass
setblock ~-112 ~18 ~-94 minecraft:glass
setblock ~-112 ~18 ~-92 minecraft:glass
setblock ~-112 ~18 ~-90 minecraft:glass
setblock ~-112 ~18 ~-88 minecraft:glass
setblock ~-112 ~18 ~-86 minecraft:glass
setblock ~-112 ~18 ~-84 minecraft:glass
setblock ~-112 ~18 ~-82 minecraft:glass
setblock ~-112 ~20 ~-112 minecraft:glass
setblock ~-112 ~20 ~-110 minecraft:glass
setblock ~-112 ~20 ~-108 minecraft:glass
setblock ~-112 ~20 ~-106 minecraft:glass
setblock ~-112 ~20 ~-104 minecraft:glass
setblock ~-112 ~20 ~-102 minecraft:glass
setblock ~-112 ~20 ~-100 minecraft:glass
setblock ~-112 ~20 ~-98 minecraft:glass
setblock ~-112 ~20 ~-96 minecraft:glass
setblock ~-112 ~20 ~-94 minecraft:glass
setblock ~-112 ~20 ~-92 minecraft:glass
setblock ~-112 ~20 ~-90 minecraft:glass
setblock ~-112 ~20 ~-88 minecraft:glass
setblock ~-112 ~20 ~-86 minecraft:glass
setblock ~-112 ~20 ~-84 minecraft:glass
setblock ~-112 ~20 ~-82 minecraft:glass
setblock ~-112 ~22 ~-112 minecraft:glass
setblock ~-112 ~22 ~-110 minecraft:glass
setblock ~-112 ~22 ~-108 minecraft:glass
setblock ~-112 ~22 ~-106 minecraft:glass
setblock ~-112 ~22 ~-104 minecraft:glass
setblock ~-112 ~22 ~-102 minecraft:glass
setblock ~-112 ~22 ~-100 minecraft:glass
setblock ~-112 ~22 ~-98 minecraft:glass
setblock ~-112 ~22 ~-96 minecraft:glass
setblock ~-112 ~22 ~-94 minecraft:glass
setblock ~-112 ~22 ~-92 minecraft:glass
setblock ~-112 ~22 ~-90 minecraft:glass
setblock ~-112 ~22 ~-88 minecraft:glass
setblock ~-112 ~22 ~-86 minecraft:glass
setblock ~-112 ~22 ~-84 minecraft:glass
setblock ~-112 ~22 ~-82 minecraft:glass
setblock ~-112 ~24 ~-112 minecraft:glass
setblock ~-112 ~24 ~-110 minecraft:glass
setblock ~-112 ~24 ~-108 minecraft:glass
setblock ~-112 ~24 ~-106 minecraft:glass
setblock ~-112 ~24 ~-104 minecraft:glass
setblock ~-112 ~24 ~-102 minecraft:glass
setblock ~-112 ~24 ~-100 minecraft:glass
setblock ~-112 ~24 ~-98 minecraft:glass
setblock ~-112 ~24 ~-96 minecraft:glass
setblock ~-112 ~24 ~-94 minecraft:glass
setblock ~-112 ~24 ~-92 minecraft:glass
setblock ~-112 ~24 ~-90 minecraft:glass
setblock ~-112 ~24 ~-88 minecraft:glass
setblock ~-112 ~24 ~-86 minecraft:glass
setblock ~-112 ~24 ~-84 minecraft:glass
setblock ~-112 ~24 ~-82 minecraft:glass
setblock ~-112 ~26 ~-112 minecraft:glass
setblock ~-112 ~26 ~-110 minecraft:glass
setblock ~-112 ~26 ~-108 minecraft:glass
setblock ~-112 ~26 ~-106 minecraft:glass
setblock ~-112 ~26 ~-104 minecraft:glass
setblock ~-112 ~26 ~-102 minecraft:glass
setblock ~-112 ~26 ~-100 minecraft:glass
setblock ~-112 ~26 ~-98 minecraft:glass
setblock ~-112 ~26 ~-96 minecraft:glass
setblock ~-112 ~26 ~-94 minecraft:glass
setblock ~-112 ~26 ~-92 minecraft:glass
setblock ~-112 ~26 ~-90 minecraft:glass
setblock ~-112 ~26 ~-88 minecraft:glass
setblock ~-112 ~26 ~-86 minecraft:glass
setblock ~-112 ~26 ~-84 minecraft:glass
setblock ~-112 ~26 ~-82 minecraft:glass
setblock ~-112 ~28 ~-112 minecraft:glass
setblock ~-112 ~28 ~-110 minecraft:glass
setblock ~-112 ~28 ~-108 minecraft:glass
setblock ~-112 ~28 ~-106 minecraft:glass
setblock ~-112 ~28 ~-104 minecraft:glass
setblock ~-112 ~28 ~-102 minecraft:glass
setblock ~-112 ~28 ~-100 minecraft:glass
setblock ~-112 ~28 ~-98 minecraft:glass
setblock ~-112 ~28 ~-96 minecraft:glass
setblock ~-112 ~28 ~-94 minecraft:glass
setblock ~-112 ~28 ~-92 minecraft:glass
setblock ~-112 ~28 ~-90 minecraft:glass
setblock ~-112 ~28 ~-88 minecraft:glass
setblock ~-112 ~28 ~-86 minecraft:glass
setblock ~-112 ~28 ~-84 minecraft:glass
setblock ~-112 ~28 ~-82 minecraft:glass
setblock ~-112 ~30 ~-112 minecraft:glass
setblock ~-112 ~30 ~-110 minecraft:glass
setblock ~-112 ~30 ~-108 minecraft:glass
setblock ~-112 ~30 ~-106 minecraft:glass
setblock ~-112 ~30 ~-104 minecraft:glass
setblock ~-112 ~30 ~-102 minecraft:glass
setblock ~-112 ~30 ~-100 minecraft:glass
setblock ~-112 ~30 ~-98 minecraft:glass
setblock ~-112 ~30 ~-96 minecraft:glass
setblock ~-112 ~30 ~-94 minecraft:glass
setblock ~-112 ~30 ~-92 minecraft:glass
setblock ~-112 ~30 ~-90 minecraft:glass
setblock ~-112 ~30 ~-88 minecraft:glass
setblock ~-112 ~30 ~-86 minecraft:glass
setblock ~-112 ~30 ~-84 minecraft:glass
setblock ~-112 ~30 ~-82 minecraft:glass
setblock ~-110 ~0 ~-112 minecraft:glass
setblock ~-110 ~0 ~-110 minecraft:glass
setblock ~-110 ~0 ~-108 minecraft:glass
setblock ~-110 ~0 ~-106 minecraft:glass
setblock ~-110 ~0 ~-104 minecraft:glass
setblock ~-110 ~0 ~-102 minecraft:glass
setblock ~-110 ~0 ~-100 minecraft:glass
setblock ~-110 ~0 ~-98 minecraft:glass
setblock ~-110 ~0 ~-96 minecraft:glass
setblock ~-110 ~0 ~-94 minecraft:glass
setblock ~-110 ~0 ~-92 minecraft:glass
setblock ~-110 ~0 ~-90 minecraft:glass
setblock ~-110 ~0 ~-88 minecraft:glass
setblock ~-110 ~0 ~-86 minecraft:glass
setblock ~-110 ~0 ~-84 minecraft:glass
setblock ~-110 ~0 ~-82 minecraft:glass
setblock ~-110 ~2 ~-112 minecraft:glass
setblock ~-110 ~2 ~-110 minecraft:glass
setblock ~-110 ~2 ~-108 minecraft:glass
setblock ~-110 ~2 ~-106 minecraft:glass
setblock ~-110 ~2 ~-104 minecraft:glass
setblock ~-110 ~2 ~-102 minecraft:glass
setblock ~-110 ~2 ~-100 minecraft:glass
setblock ~-110 ~2 ~-98 minecraft:glass
setblock ~-110 ~2 ~-96 minecraft:glass
setblock ~-110 ~2 ~-94 minecraft:glass
setblock ~-110 ~2 ~-92 minecraft:glass
setblock ~-110 ~2 ~-90 minecraft:glass
setblock ~-110 ~2 ~-88 minecraft:glass
setblock ~-110 ~2 ~-86 minecraft:glass
setblock ~-110 ~2 ~-84 minecraft:glass
setblock ~-110 ~2 ~-82 minecraft:glass
setblock ~-110 ~4 ~-112 minecraft:glass
setblock ~-110 ~4 ~-110 minecraft:glass
setblock ~-110 ~4 ~-108 minecraft:glass
setblock ~-110 ~4 ~-106 minecraft:glass
setblock ~-110 ~4 ~-104 minecraft:glass
setblock ~-110 ~4 ~-102 minecraft:glass
setblock ~-110 ~4 ~-100 minecraft:glass
setblock ~-110 ~4 ~-98 minecraft:glass
setblock ~-110 ~4 ~-96 minecraft:glass
setblock ~-110 ~4 ~-94 minecraft:glass
setblock ~-110 ~4 ~-92 minecraft:glass
setblock ~-110 ~4 ~-90 minecraft:glass
setblock ~-110 ~4 ~-88 minecraft:glass
setblock ~-110 ~4 ~-86 minecraft:glass
setblock ~-110 ~4 ~-84 minecraft:glass
setblock ~-110 ~4 ~-82 minecraft:glass
setblock ~-110 ~6 ~-112 minecraft:glass
setblock ~-110 ~6 ~-110 minecraft:glass
setblock ~-110 ~6 ~-108 minecraft:glass
setblock ~-110 ~6 ~-106 minecraft:glass
setblock ~-110 ~6 ~-104 minecraft:glass
setblock ~-110 ~6 ~-102 minecraft:glass
setblock ~-110 ~6 ~-100 minecraft:glass
setblock ~-110 ~6 ~-98 minecraft:glass
setblock ~-110 ~6 ~-96 minecraft:glass
setblock ~-110 ~6 ~-94 minecraft:glass
setblock ~-110 ~6 ~-92 minecraft:glass
setblock ~-110 ~6 ~-90 minecraft:glass
setblock ~-110 ~6 ~-88 minecraft:glass
setblock ~-110 ~6 ~-86 minecraft:glass
setblock ~-110 ~6 ~-84 minecraft:glass
setblock ~-110 ~6 ~-82 minecraft:glass
setblock ~-110 ~8 ~-112 minecraft:glass
setblock ~-110 ~8 ~-110 minecraft:glass
setblock ~-110 ~8 ~-108 minecraft:glass
setblock ~-110 ~8 ~-106 minecraft:glass
setblock ~-110 ~8 ~-104 minecraft:glass
setblock ~-110 ~8 ~-102 minecraft:glass
setblock ~-110 ~8 ~-100 minecraft:glass
setblock ~-110 ~8 ~-98 minecraft:glass
setblock ~-110 ~8 ~-96 minecraft:glass
setblock ~-110 ~8 ~-94 minecraft:glass
setblock ~-110 ~8 ~-92 minecraft:glass
setblock ~-110 ~8 ~-90 minecraft:glass
setblock ~-110 ~8 ~-88 minecraft:glass
setblock ~-110 ~8 ~-86 minecraft:glass
setblock ~-110 ~8 ~-84 minecraft:glass
setblock ~-110 ~8 ~-82 minecraft:glass
setblock ~-110 ~10 ~-112 minecraft:glass
setblock ~-110 ~10 ~-110 minecraft:glass
setblock ~-110 ~10 ~-108 minecraft:glass
setblock ~-110 ~10 ~-106 minecraft:glass
setblock ~-110 ~10 ~-104 minecraft:glass
setblock ~-110 ~10 ~-102 minecraft:glass
setblock ~-110 ~10 ~-100 minecraft:glass
setblock ~-110 ~10 ~-98 minecraft:glass
setblock ~-110 ~10 ~-96 minecraft:glass
setblock ~-110 ~10 ~-94 minecraft:glass
setblock ~-110 ~10 ~-92 minecraft:glass
setblock ~-110 ~10 ~-90 minecraft:glass
setblock ~-110 ~10 ~-88 minecraft:glass
setblock ~-110 ~10 ~-86 minecraft:glass
setblock ~-110 ~10 ~-84 minecraft:glass
setblock ~-110 ~10 ~-82 minecraft:glass
setblock ~-110 ~12 ~-112 minecraft:glass
setblock ~-110 ~12 ~-110 minecraft:glass
setblock ~-110 ~12 ~-108 minecraft:glass
setblock ~-110 ~12 ~-106 minecraft:glass
setblock ~-110 ~12 ~-104 minecraft:glass
setblock ~-110 ~12 ~-102 minecraft:glass
setblock ~-110 ~12 ~-100 minecraft:glass
setblock ~-110 ~12 ~-98 minecraft:glass
setblock ~-110 ~12 ~-96 minecraft:glass
setblock ~-110 ~12 ~-94 minecraft:glass
setblock ~-110 ~12 ~-92 minecraft:glass
setblock ~-110 ~12 ~-90 minecraft:glass
setblock ~-110 ~12 ~-88 minecraft:glass
setblock ~-110 ~12 ~-86 minecraft:glass
setblock ~-110 ~12 ~-84 minecraft:glass
setblock ~-110 ~12 ~-82 minecraft:glass
setblock ~-110 ~14 ~-112 minecraft:glass
setblock ~-110 ~14 ~-110 minecraft:glass
setblock ~-110 ~14 ~-108 minecraft:glass
setblock ~-110 ~14 ~-106 minecraft:glass
setblock ~-110 ~14 ~-104 minecraft:glass
setblock ~-110 ~14 ~-102 minecraft:glass
setblock ~-110 ~14 ~-100 minecraft:glass
setblock ~-110 ~14 ~-98 minecraft:glass
setblock ~-110 ~14 ~-96 minecraft:glass
setblock ~-110 ~14 ~-94 minecraft:glass
setblock ~-110 ~14 ~-92 minecraft:glass
setblock ~-110 ~14 ~-90 minecraft:glass
setblock ~-110 ~14 ~-88 minecraft:glass
setblock ~-110 ~14 ~-86 minecraft:glass
setblock ~-110 ~14 ~-84 minecraft:glass
setblock ~-110 ~14 ~-82 minecraft:glass
setblock ~-110 ~16 ~-112 minecraft:glass
setblock ~-110 ~16 ~-110 minecraft:glass
setblock ~-110 ~16 ~-108 minecraft:glass
setblock ~-110 ~16 ~-106 minecraft:glass
setblock ~-110 ~16 ~-104 minecraft:glass
setblock ~-110 ~16 ~-102 minecraft:glass
setblock ~-110 ~16 ~-100 minecraft:glass
setblock ~-110 ~16 ~-98 minecraft:glass
setblock ~-110 ~16 ~-96 minecraft:glass
setblock ~-110 ~16 ~-94 minecraft:glass
setblock ~-110 ~16 ~-92 minecraft:glass
setblock ~-110 ~16 ~-90 minecraft:glass
setblock ~-110 ~16 ~-88 minecraft:glass
setblock ~-110 ~16 ~-86 minecraft:glass
setblock ~-110 ~16 ~-84 minecraft:glass
setblock ~-110 ~16 ~-82 minecraft:glass
setblock ~-110 ~18 ~-112 minecraft:glass
setblock ~-110 ~18 ~-110 minecraft:glass
setblock ~-110 ~18 ~-108 minecraft:glass
setblock ~-110 ~18 ~-106 minecraft:glass
setblock ~-110 ~18 ~-104 minecraft:glass
setblock ~-110 ~18 ~-102 minecraft:glass
setblock ~-110 ~18 ~-100 minecraft:glass
setblock ~-110 ~18 ~-98 minecraft:glass
setblock ~-110 ~18 ~-96 minecraft:glass
setblock ~-110 ~18 ~-94 minecraft:glass
setblock ~-110 ~18 ~-92 minecraft:glass
setblock ~-110 ~18 ~-90 minecraft:glass
setblock ~-110 ~18 ~-88 minecraft:glass
setblock ~-110 ~18 ~-86 minecraft:glass
setblock ~-110 ~18 ~-84 minecraft:glass
setblock ~-110 ~18 ~-82 minecraft:glass
setblock ~-110 ~20 ~-112 minecraft:glass
setblock ~-110 ~20 ~-110 minecraft:glass
setblock ~-110 ~20 ~-108 minecraft:glass
setblock ~-110 ~20 ~-106 minecraft:glass
setblock ~-110 ~20 ~-104 minecraft:glass
setblock ~-110 ~20 ~-102 minecraft:glass
setblock ~-110 ~20 ~-100 minecraft:glass
setblock ~-110 ~20 ~-98 minecraft:glass
setblock ~-110 ~20 ~-96 minecraft:glass
setblock ~-110 ~20 ~-94 minecraft:glass
setblock ~-110 ~20 ~-92 minecraft:glass
setblock ~-110 ~20 ~-90 minecraft:glass
setblock ~-110 ~20 ~-88 minecraft:glass
setblock ~-110 ~20 ~-86 minecraft:glass
setblock ~-110 ~20 ~-84 minecraft:glass
setblock ~-110 ~20 ~-82 minecraft:glass
setblock ~-110 ~22 ~-112 minecraft:glass
setblock ~-110 ~22 ~-110 minecraft:glass
setblock ~-110 ~22 ~-108 minecraft:glass
setblock ~-110 ~22 ~-106 minecraft:glass
setblock ~-110 ~22 ~-104 minecraft:glass
setblock ~-110 ~22 ~-102 minecraft:glass
setblock ~-110 ~22 ~-100 minecraft:glass
setblock ~-110 ~22 ~-98 minecraft:glass
setblock ~-110 ~22 ~-96 minecraft:glass
setblock ~-110 ~22 ~-94 minecraft:glass
setblock ~-110 ~22 ~-92 minecraft:glass
setblock ~-110 ~22 ~-90 minecraft:glass
setblock ~-110 ~22 ~-88 minecraft:glass
setblock ~-110 ~22 ~-86 minecraft:glass
setblock ~-110 ~22 ~-84 minecraft:glass
setblock ~-110 ~22 ~-82 minecraft:glass
setblock ~-110 ~24 ~-112 minecraft:glass
setblock ~-110 ~24 ~-110 minecraft:glass
setblock ~-110 ~24 ~-108 minecraft:glass
setblock ~-110 ~24 ~-106 minecraft:glass
setblock ~-110 ~24 ~-104 minecraft:glass
setblock ~-110 ~24 ~-102 minecraft:glass
setblock ~-110 ~24 ~-100 minecraft:glass
setblock ~-110 ~24 ~-98 minecraft:glass
setblock ~-110 ~24 ~-96 minecraft:glass
setblock ~-110 ~24 ~-94 minecraft:glass
setblock ~-110 ~24 ~-92 minecraft:glass
setblock ~-110 ~24 ~-90 minecraft:glass
setblock ~-110 ~24 ~-88 minecraft:glass
setblock ~-110 ~24 ~-86 minecraft:glass
setblock ~-110 ~24 ~-84 minecraft:glass
setblock ~-110 ~24 ~-82 minecraft:glass
setblock ~-110 ~26 ~-112 minecraft:glass
setblock ~-110 ~26 ~-110 minecraft:glass
setblock ~-110 ~26 ~-108 minecraft:glass
setblock ~-110 ~26 ~-106 minecraft:glass
setblock ~-110 ~26 ~-104 minecraft:glass
setblock ~-110 ~26 ~-102 minecraft:glass
setblock ~-110 ~26 ~-100 minecraft:glass
setblock ~-110 ~26 ~-98 minecraft:glass
setblock ~-110 ~26 ~-96 minecraft:glass
setblock ~-110 ~26 ~-94 minecraft:glass
setblock ~-110 ~26 ~-92 minecraft:glass
setblock ~-110 ~26 ~-90 minecraft:glass
setblock ~-110 ~26 ~-88 minecraft:glass
setblock ~-110 ~26 ~-86 minecraft:glass
setblock ~-110 ~26 ~-84 minecraft:glass
setblock ~-110 ~26 ~-82 minecraft:glass
setblock ~-110 ~28 ~-112 minecraft:glass
setblock ~-110 ~28 ~-110 minecraft:glass
setblock ~-110 ~28 ~-108 minecraft:glass
setblock ~-110 ~28 ~-106 minecraft:glass
setblock ~-110 ~28 ~-104 minecraft:glass
setblock ~-110 ~28 ~-102 minecraft:glass
setblock ~-110 ~28 ~-100 minecraft:glass
setblock ~-110 ~28 ~-98 minecraft:glass
setblock ~-110 ~28 ~-96 minecraft:glass
setblock ~-110 ~28 ~-94 minecraft:glass
setblock ~-110 ~28 ~-92 minecraft:glass
setblock ~-110 ~28 ~-90 minecraft:glass
setblock ~-110 ~28 ~-88 minecraft:glass
setblock ~-110 ~28 ~-86 minecraft:glass
setblock ~-110 ~28 ~-84 minecraft:glass
setblock ~-110 ~28 ~-82 minecraft:glass
setblock ~-110 ~30 ~-112 minecraft:glass
setblock ~-110 ~30 ~-110 minecraft:glass
setblock ~-110 ~30 ~-108 minecraft:glass
setblock ~-110 ~30 ~-106 minecraft:glass
setblock ~-110 ~30 ~-104 minecraft:glass
setblock ~-110 ~30 ~-102 minecraft:glass
setblock ~-110 ~30 ~-100 minecraft:glass
setblock ~-110 ~30 ~-98 minecraft:glass
setblock ~-110 ~30 ~-96 minecraft:glass
setblock ~-110 ~30 ~-94 minecraft:glass
setblock ~-110 ~30 ~-92 minecraft:glass
setblock ~-110 ~30 ~-90 minecraft:glass
setblock ~-110 ~30 ~-88 minecraft:glass
setblock ~-110 ~30 ~-86 minecraft:glass
setblock ~-110 ~30 ~-84 minecraft:glass
setblock ~-110 ~30 ~-82 minecraft:glass
setblock ~-108 ~0 ~-112 minecraft:glass
setblock ~-108 ~0 ~-110 minecraft:glass
setblock ~-108 ~0 ~-108 minecraft:glass
setblock ~-108 ~0 ~-106 minecraft:glass
setblock ~-108 ~0 ~-104 minecraft:glass
setblock ~-108 ~0 ~-102 minecraft:glass
setblock ~-108 ~0 ~-100 minecraft:glass
setblock ~-108 ~0 ~-98 minecraft:glass
setblock ~-108 ~0 ~-96 minecraft:glass
setblock ~-108 ~0 ~-94 minecraft:glass
setblock ~-108 ~0 ~-92 minecraft:glass
setblock ~-108 ~0 ~-90 minecraft:glass
setblock ~-108 ~0 ~-88 minecraft:glass
setblock ~-108 ~0 ~-86 minecraft:glass
setblock ~-108 ~0 ~-84 minecraft:glass
setblock ~-108 ~0 ~-82 minecraft:glass
setblock ~-108 ~2 ~-112 minecraft:glass
setblock ~-108 ~2 ~-110 minecraft:glass
setblock ~-108 ~2 ~-108 minecraft:glass
setblock ~-108 ~2 ~-106 minecraft:glass
setblock ~-108 ~2 ~-104 minecraft:glass
setblock ~-108 ~2 ~-102 minecraft:glass
setblock ~-108 ~2 ~-100 minecraft:glass
setblock ~-108 ~2 ~-98 minecraft:glass
setblock ~-108 ~2 ~-96 minecraft:glass
setblock ~-108 ~2 ~-94 minecraft:glass
setblock ~-108 ~2 ~-92 minecraft:glass
setblock ~-108 ~2 ~-90 minecraft:glass
setblock ~-108 ~2 ~-88 minecraft:glass
setblock ~-108 ~2 ~-86 minecraft:glass
setblock ~-108 ~2 ~-84 minecraft:glass
setblock ~-108 ~2 ~-82 minecraft:glass
setblock ~-108 ~4 ~-112 minecraft:glass
setblock ~-108 ~4 ~-110 minecraft:glass
setblock ~-108 ~4 ~-108 minecraft:glass
setblock ~-108 ~4 ~-106 minecraft:glass
setblock ~-108 ~4 ~-104 minecraft:glass
setblock ~-108 ~4 ~-102 minecraft:glass
setblock ~-108 ~4 ~-100 minecraft:glass
setblock ~-108 ~4 ~-98 minecraft:glass
setblock ~-108 ~4 ~-96 minecraft:glass
setblock ~-108 ~4 ~-94 minecraft:glass
setblock ~-108 ~4 ~-92 minecraft:glass
setblock ~-108 ~4 ~-90 minecraft:glass
setblock ~-108 ~4 ~-88 minecraft:glass
setblock ~-108 ~4 ~-86 minecraft:glass
setblock ~-108 ~4 ~-84 minecraft:glass
setblock ~-108 ~4 ~-82 minecraft:glass
setblock ~-108 ~6 ~-112 minecraft:glass
setblock ~-108 ~6 ~-110 minecraft:glass
setblock ~-108 ~6 ~-108 minecraft:glass
setblock ~-108 ~6 ~-106 minecraft:glass
setblock ~-108 ~6 ~-104 minecraft:glass
setblock ~-108 ~6 ~-102 minecraft:glass
setblock ~-108 ~6 ~-100 minecraft:glass
setblock ~-108 ~6 ~-98 minecraft:glass
setblock ~-108 ~6 ~-96 minecraft:glass
setblock ~-108 ~6 ~-94 minecraft:glass
setblock ~-108 ~6 ~-92 minecraft:glass
setblock ~-108 ~6 ~-90 minecraft:glass
setblock ~-108 ~6 ~-88 minecraft:glass
setblock ~-108 ~6 ~-86 minecraft:glass
setblock ~-108 ~6 ~-84 minecraft:glass
setblock ~-108 ~6 ~-82 minecraft:glass
setblock ~-108 ~8 ~-112 minecraft:glass
setblock ~-108 ~8 ~-110 minecraft:glass
setblock ~-108 ~8 ~-108 minecraft:glass
setblock ~-108 ~8 ~-106 minecraft:glass
setblock ~-108 ~8 ~-104 minecraft:glass
setblock ~-108 ~8 ~-102 minecraft:glass
setblock ~-108 ~8 ~-100 minecraft:glass
setblock ~-108 ~8 ~-98 minecraft:glass
setblock ~-108 ~8 ~-96 minecraft:glass
setblock ~-108 ~8 ~-94 minecraft:glass
setblock ~-108 ~8 ~-92 minecraft:glass
setblock ~-108 ~8 ~-90 minecraft:glass
setblock ~-108 ~8 ~-88 minecraft:glass
setblock ~-108 ~8 ~-86 minecraft:glass
setblock ~-108 ~8 ~-84 minecraft:glass
setblock ~-108 ~8 ~-82 minecraft:glass
setblock ~-108 ~10 ~-112 minecraft:glass
setblock ~-108 ~10 ~-110 minecraft:glass
setblock ~-108 ~10 ~-108 minecraft:glass
setblock ~-108 ~10 ~-106 minecraft:glass
setblock ~-108 ~10 ~-104 minecraft:glass
setblock ~-108 ~10 ~-102 minecraft:glass
setblock ~-108 ~10 ~-100 minecraft:glass
setblock ~-108 ~10 ~-98 minecraft:glass
setblock ~-108 ~10 ~-96 minecraft:glass
setblock ~-108 ~10 ~-94 minecraft:glass
setblock ~-108 ~10 ~-92 minecraft:glass
setblock ~-108 ~10 ~-90 minecraft:glass
setblock ~-108 ~10 ~-88 minecraft:glass
setblock ~-108 ~10 ~-86 minecraft:glass
setblock ~-108 ~10 ~-84 minecraft:glass
setblock ~-108 ~10 ~-82 minecraft:glass
setblock ~-108 ~12 ~-112 minecraft:glass
setblock ~-108 ~12 ~-110 minecraft:glass
setblock ~-108 ~12 ~-108 minecraft:glass
setblock ~-108 ~12 ~-106 minecraft:glass
setblock ~-108 ~12 ~-104 minecraft:glass
setblock ~-108 ~12 ~-102 minecraft:glass
setblock ~-108 ~12 ~-100 minecraft:glass
setblock ~-108 ~12 ~-98 minecraft:glass
setblock ~-108 ~12 ~-96 minecraft:glass
setblock ~-108 ~12 ~-94 minecraft:glass
setblock ~-108 ~12 ~-92 minecraft:glass
setblock ~-108 ~12 ~-90 minecraft:glass
setblock ~-108 ~12 ~-88 minecraft:glass
setblock ~-108 ~12 ~-86 minecraft:glass
setblock ~-108 ~12 ~-84 minecraft:glass
setblock ~-108 ~12 ~-82 minecraft:glass
setblock ~-108 ~14 ~-112 minecraft:glass
setblock ~-108 ~14 ~-110 minecraft:glass
setblock ~-108 ~14 ~-108 minecraft:glass
setblock ~-108 ~14 ~-106 minecraft:glass
setblock ~-108 ~14 ~-104 minecraft:glass
setblock ~-108 ~14 ~-102 minecraft:glass
setblock ~-108 ~14 ~-100 minecraft:glass
setblock ~-108 ~14 ~-98 minecraft:glass
setblock ~-108 ~14 ~-96 minecraft:glass
setblock ~-108 ~14 ~-94 minecraft:glass
setblock ~-108 ~14 ~-92 minecraft:glass
setblock ~-108 ~14 ~-90 minecraft:glass
setblock ~-108 ~14 ~-88 minecraft:glass
setblock ~-108 ~14 ~-86 minecraft:glass
setblock ~-108 ~14 ~-84 minecraft:glass
setblock ~-108 ~14 ~-82 minecraft:glass
setblock ~-108 ~16 ~-112 minecraft:glass
setblock ~-108 ~16 ~-110 minecraft:glass
setblock ~-108 ~16 ~-108 minecraft:glass
setblock ~-108 ~16 ~-106 minecraft:glass
setblock ~-108 ~16 ~-104 minecraft:glass
setblock ~-108 ~16 ~-102 minecraft:glass
setblock ~-108 ~16 ~-100 minecraft:glass
setblock ~-108 ~16 ~-98 minecraft:glass
setblock ~-108 ~16 ~-96 minecraft:glass
setblock ~-108 ~16 ~-94 minecraft:glass
setblock ~-108 ~16 ~-92 minecraft:glass
setblock ~-108 ~16 ~-90 minecraft:glass
setblock ~-108 ~16 ~-88 minecraft:glass
setblock ~-108 ~16 ~-86 minecraft:glass
setblock ~-108 ~16 ~-84 minecraft:glass
setblock ~-108 ~16 ~-82 minecraft:glass
setblock ~-108 ~18 ~-112 minecraft:glass
setblock ~-108 ~18 ~-110 minecraft:glass
setblock ~-108 ~18 ~-108 minecraft:glass
setblock ~-108 ~18 ~-106 minecraft:glass
setblock ~-108 ~18 ~-104 minecraft:glass
setblock ~-108 ~18 ~-102 minecraft:glass
setblock ~-108 ~18 ~-100 minecraft:glass
setblock ~-108 ~18 ~-98 minecraft:glass
setblock ~-108 ~18 ~-96 minecraft:glass
setblock ~-108 ~18 ~-94 minecraft:glass
setblock ~-108 ~18 ~-92 minecraft:glass
setblock ~-108 ~18 ~-90 minecraft:glass
setblock ~-108 ~18 ~-88 minecraft:glass
setblock ~-108 ~18 ~-86 minecraft:glass
setblock ~-108 ~18 ~-84 minecraft:glass
setblock ~-108 ~18 ~-82 minecraft:glass
setblock ~-108 ~20 ~-112 minecraft:glass
setblock ~-108 ~20 ~-110 minecraft:glass
setblock ~-108 ~20 ~-108 minecraft:glass
setblock ~-108 ~20 ~-106 minecraft:glass
setblock ~-108 ~20 ~-104 minecraft:glass
setblock ~-108 ~20 ~-102 minecraft:glass
setblock ~-108 ~20 ~-100 minecraft:glass
setblock ~-108 ~20 ~-98 minecraft:glass
setblock ~-108 ~20 ~-96 minecraft:glass
setblock ~-108 ~20 ~-94 minecraft:glass
setblock ~-108 ~20 ~-92 minecraft:glass
setblock ~-108 ~20 ~-90 minecraft:glass
setblock ~-108 ~20 ~-88 minecraft:glass
setblock ~-108 ~20 ~-86 minecraft:glass
setblock ~-108 ~20 ~-84 minecraft:glass
setblock ~-108 ~20 ~-82 minecraft:glass
setblock ~-108 ~22 ~-112 minecraft:glass
setblock ~-108 ~22 ~-110 minecraft:glass
setblock ~-108 ~22 ~-108 minecraft:glass
setblock ~-108 ~22 ~-106 minecraft:glass
setblock ~-108 ~22 ~-104 minecraft:glass
setblock ~-108 ~22 ~-102 minecraft:glass
setblock ~-108 ~22 ~-100 minecraft:glass
setblock ~-108 ~22 ~-98 minecraft:glass
setblock ~-108 ~22 ~-96 minecraft:glass
setblock ~-108 ~22 ~-94 minecraft:glass
setblock ~-108 ~22 ~-92 minecraft:glass
setblock ~-108 ~22 ~-90 minecraft:glass
setblock ~-108 ~22 ~-88 minecraft:glass
setblock ~-108 ~22 ~-86 minecraft:glass
setblock ~-108 ~22 ~-84 minecraft:glass
setblock ~-108 ~22 ~-82 minecraft:glass
setblock ~-108 ~24 ~-112 minecraft:glass
setblock ~-108 ~24 ~-110 minecraft:glass
setblock ~-108 ~24 ~-108 minecraft:glass
setblock ~-108 ~24 ~-106 minecraft:glass
setblock ~-108 ~24 ~-104 minecraft:glass
setblock ~-108 ~24 ~-102 minecraft:glass
setblock ~-108 ~24 ~-100 minecraft:glass
setblock ~-108 ~24 ~-98 minecraft:glass
setblock ~-108 ~24 ~-96 minecraft:glass
setblock ~-108 ~24 ~-94 minecraft:glass
setblock ~-108 ~24 ~-92 minecraft:glass
setblock ~-108 ~24 ~-90 minecraft:glass
setblock ~-108 ~24 ~-88 minecraft:glass
setblock ~-108 ~24 ~-86 minecraft:glass
setblock ~-108 ~24 ~-84 minecraft:glass
setblock ~-108 ~24 ~-82 minecraft:glass
setblock ~-108 ~26 ~-112 minecraft:glass
setblock ~-108 ~26 ~-110 minecraft:glass
setblock ~-108 ~26 ~-108 minecraft:glass
setblock ~-108 ~26 ~-106 minecraft:glass
setblock ~-108 ~26 ~-104 minecraft:glass
setblock ~-108 ~26 ~-102 minecraft:glass
setblock ~-108 ~26 ~-100 minecraft:glass
setblock ~-108 ~26 ~-98 minecraft:glass
setblock ~-108 ~26 ~-96 minecraft:glass
setblock ~-108 ~26 ~-94 minecraft:glass
setblock ~-108 ~26 ~-92 minecraft:glass
setblock ~-108 ~26 ~-90 minecraft:glass
setblock ~-108 ~26 ~-88 minecraft:glass
setblock ~-108 ~26 ~-86 minecraft:glass
setblock ~-108 ~26 ~-84 minecraft:glass
setblock ~-108 ~26 ~-82 minecraft:glass
setblock ~-108 ~28 ~-112 minecraft:glass
setblock ~-108 ~28 ~-110 minecraft:glass
setblock ~-108 ~28 ~-108 minecraft:glass
setblock ~-108 ~28 ~-106 minecraft:glass
setblock ~-108 ~28 ~-104 minecraft:glass
setblock ~-108 ~28 ~-102 minecraft:glass
setblock ~-108 ~28 ~-100 minecraft:glass
setblock ~-108 ~28 ~-98 minecraft:glass
setblock ~-108 ~28 ~-96 minecraft:glass
setblock ~-108 ~28 ~-94 minecraft:glass
setblock ~-108 ~28 ~-92 minecraft:glass
setblock ~-108 ~28 ~-90 minecraft:glass
setblock ~-108 ~28 ~-88 minecraft:glass
setblock ~-108 ~28 ~-86 minecraft:glass
setblock ~-108 ~28 ~-84 minecraft:glass
setblock ~-108 ~28 ~-82 minecraft:glass
setblock ~-108 ~30 ~-112 minecraft:glass
setblock ~-108 ~30 ~-110 minecraft:glass
setblock ~-108 ~30 ~-108 minecraft:glass
setblock ~-108 ~30 ~-106 minecraft:glass
setblock ~-108 ~30 ~-104 minecraft:glass
setblock ~-108 ~30 ~-102 minecraft:glass
setblock ~-108 ~30 ~-100 minecraft:glass
setblock ~-108 ~30 ~-98 minecraft:glass
setblock ~-108 ~30 ~-96 minecraft:glass
setblock ~-108 ~30 ~-94 minecraft:glass
setblock ~-108 ~30 ~-92 minecraft:glass
setblock ~-108 ~30 ~-90 minecraft:glass
setblock ~-108 ~30 ~-88 minecraft:glass
setblock ~-108 ~30 ~-86 minecraft:glass
setblock ~-108 ~30 ~-84 minecraft:glass
setblock ~-108 ~30 ~-82 minecraft:glass
setblock ~-106 ~0 ~-112 minecraft:glass
setblock ~-106 ~0 ~-110 minecraft:glass
setblock ~-106 ~0 ~-108 minecraft:glass
setblock ~-106 ~0 ~-106 minecraft:glass
setblock ~-106 ~0 ~-104 minecraft:glass
setblock ~-106 ~0 ~-102 minecraft:glass
setblock ~-106 ~0 ~-100 minecraft:glass
setblock ~-106 ~0 ~-98 minecraft:glass
setblock ~-106 ~0 ~-96 minecraft:glass
setblock ~-106 ~0 ~-94 minecraft:glass
setblock ~-106 ~0 ~-92 minecraft:glass
setblock ~-106 ~0 ~-90 minecraft:glass
setblock ~-106 ~0 ~-88 minecraft:glass
setblock ~-106 ~0 ~-86 minecraft:glass
setblock ~-106 ~0 ~-84 minecraft:glass
setblock ~-106 ~0 ~-82 minecraft:glass
setblock ~-106 ~2 ~-112 minecraft:glass
setblock ~-106 ~2 ~-110 minecraft:glass
setblock ~-106 ~2 ~-108 minecraft:glass
setblock ~-106 ~2 ~-106 minecraft:glass
setblock ~-106 ~2 ~-104 minecraft:glass
setblock ~-106 ~2 ~-102 minecraft:glass
setblock ~-106 ~2 ~-100 minecraft:glass
setblock ~-106 ~2 ~-98 minecraft:glass
setblock ~-106 ~2 ~-96 minecraft:glass
setblock ~-106 ~2 ~-94 minecraft:glass
setblock ~-106 ~2 ~-92 minecraft:glass
setblock ~-106 ~2 ~-90 minecraft:glass
setblock ~-106 ~2 ~-88 minecraft:glass
setblock ~-106 ~2 ~-86 minecraft:glass
setblock ~-106 ~2 ~-84 minecraft:glass
setblock ~-106 ~2 ~-82 minecraft:glass
setblock ~-106 ~4 ~-112 minecraft:glass
setblock ~-106 ~4 ~-110 minecraft:glass
setblock ~-106 ~4 ~-108 minecraft:glass
setblock ~-106 ~4 ~-106 minecraft:glass
setblock ~-106 ~4 ~-104 minecraft:glass
setblock ~-106 ~4 ~-102 minecraft:glass
setblock ~-106 ~4 ~-100 minecraft:glass
setblock ~-106 ~4 ~-98 minecraft:glass
setblock ~-106 ~4 ~-96 minecraft:glass
setblock ~-106 ~4 ~-94 minecraft:glass
setblock ~-106 ~4 ~-92 minecraft:glass
setblock ~-106 ~4 ~-90 minecraft:glass
setblock ~-106 ~4 ~-88 minecraft:glass
setblock ~-106 ~4 ~-86 minecraft:glass
setblock ~-106 ~4 ~-84 minecraft:glass
setblock ~-106 ~4 ~-82 minecraft:glass
setblock ~-106 ~6 ~-112 minecraft:glass
setblock ~-106 ~6 ~-110 minecraft:glass
setblock ~-106 ~6 ~-108 minecraft:glass
setblock ~-106 ~6 ~-106 minecraft:glass
setblock ~-106 ~6 ~-104 minecraft:glass
setblock ~-106 ~6 ~-102 minecraft:glass
setblock ~-106 ~6 ~-100 minecraft:glass
setblock ~-106 ~6 ~-98 minecraft:glass
setblock ~-106 ~6 ~-96 minecraft:glass
setblock ~-106 ~6 ~-94 minecraft:glass
setblock ~-106 ~6 ~-92 minecraft:glass
setblock ~-106 ~6 ~-90 minecraft:glass
setblock ~-106 ~6 ~-88 minecraft:glass
setblock ~-106 ~6 ~-86 minecraft:glass
setblock ~-106 ~6 ~-84 minecraft:glass
setblock ~-106 ~6 ~-82 minecraft:glass
setblock ~-106 ~8 ~-112 minecraft:glass
setblock ~-106 ~8 ~-110 minecraft:glass
setblock ~-106 ~8 ~-108 minecraft:glass
setblock ~-106 ~8 ~-106 minecraft:glass
setblock ~-106 ~8 ~-104 minecraft:glass
setblock ~-106 ~8 ~-102 minecraft:glass
setblock ~-106 ~8 ~-100 minecraft:glass
setblock ~-106 ~8 ~-98 minecraft:glass
setblock ~-106 ~8 ~-96 minecraft:glass
setblock ~-106 ~8 ~-94 minecraft:glass
setblock ~-106 ~8 ~-92 minecraft:glass
setblock ~-106 ~8 ~-90 minecraft:glass
setblock ~-106 ~8 ~-88 minecraft:glass
setblock ~-106 ~8 ~-86 minecraft:glass
setblock ~-106 ~8 ~-84 minecraft:glass
setblock ~-106 ~8 ~-82 minecraft:glass
setblock ~-106 ~10 ~-112 minecraft:glass
setblock ~-106 ~10 ~-110 minecraft:glass
setblock ~-106 ~10 ~-108 minecraft:glass
setblock ~-106 ~10 ~-106 minecraft:glass
setblock ~-106 ~10 ~-104 minecraft:glass
setblock ~-106 ~10 ~-102 minecraft:glass
setblock ~-106 ~10 ~-100 minecraft:glass
setblock ~-106 ~10 ~-98 minecraft:glass
setblock ~-106 ~10 ~-96 minecraft:glass
setblock ~-106 ~10 ~-94 minecraft:glass
setblock ~-106 ~10 ~-92 minecraft:glass
setblock ~-106 ~10 ~-90 minecraft:glass
setblock ~-106 ~10 ~-88 minecraft:glass
setblock ~-106 ~10 ~-86 minecraft:glass
setblock ~-106 ~10 ~-84 minecraft:glass
setblock ~-106 ~10 ~-82 minecraft:glass
setblock ~-106 ~12 ~-112 minecraft:glass
setblock ~-106 ~12 ~-110 minecraft:glass
setblock ~-106 ~12 ~-108 minecraft:glass
setblock ~-106 ~12 ~-106 minecraft:glass
setblock ~-106 ~12 ~-104 minecraft:glass
setblock ~-106 ~12 ~-102 minecraft:glass
setblock ~-106 ~12 ~-100 minecraft:glass
setblock ~-106 ~12 ~-98 minecraft:glass
setblock ~-106 ~12 ~-96 minecraft:glass
setblock ~-106 ~12 ~-94 minecraft:glass
setblock ~-106 ~12 ~-92 minecraft:glass
setblock ~-106 ~12 ~-90 minecraft:glass
setblock ~-106 ~12 ~-88 minecraft:glass
setblock ~-106 ~12 ~-86 minecraft:glass
setblock ~-106 ~12 ~-84 minecraft:glass
setblock ~-106 ~12 ~-82 minecraft:glass
setblock ~-106 ~14 ~-112 minecraft:glass
setblock ~-106 ~14 ~-110 minecraft:glass
setblock ~-106 ~14 ~-108 minecraft:glass
setblock ~-106 ~14 ~-106 minecraft:glass
setblock ~-106 ~14 ~-104 minecraft:glass
setblock ~-106 ~14 ~-102 minecraft:glass
setblock ~-106 ~14 ~-100 minecraft:glass
setblock ~-106 ~14 ~-98 minecraft:glass
setblock ~-106 ~14 ~-96 minecraft:glass
setblock ~-106 ~14 ~-94 minecraft:glass
setblock ~-106 ~14 ~-92 minecraft:glass
setblock ~-106 ~14 ~-90 minecraft:glass
setblock ~-106 ~14 ~-88 minecraft:glass
setblock ~-106 ~14 ~-86 minecraft:glass
setblock ~-106 ~14 ~-84 minecraft:glass
setblock ~-106 ~14 ~-82 minecraft:glass
setblock ~-106 ~16 ~-112 minecraft:glass
setblock ~-106 ~16 ~-110 minecraft:glass
setblock ~-106 ~16 ~-108 minecraft:glass
setblock ~-106 ~16 ~-106 minecraft:glass
setblock ~-106 ~16 ~-104 minecraft:glass
setblock ~-106 ~16 ~-102 minecraft:glass
setblock ~-106 ~16 ~-100 minecraft:glass
setblock ~-106 ~16 ~-98 minecraft:glass
setblock ~-106 ~16 ~-96 minecraft:glass
setblock ~-106 ~16 ~-94 minecraft:glass
setblock ~-106 ~16 ~-92 minecraft:glass
setblock ~-106 ~16 ~-90 minecraft:glass
setblock ~-106 ~16 ~-88 minecraft:glass
setblock ~-106 ~16 ~-86 minecraft:glass
setblock ~-106 ~16 ~-84 minecraft:glass
setblock ~-106 ~16 ~-82 minecraft:glass
setblock ~-106 ~18 ~-112 minecraft:glass
setblock ~-106 ~18 ~-110 minecraft:glass
setblock ~-106 ~18 ~-108 minecraft:glass
setblock ~-106 ~18 ~-106 minecraft:glass
setblock ~-106 ~18 ~-104 minecraft:glass
setblock ~-106 ~18 ~-102 minecraft:glass
setblock ~-106 ~18 ~-100 minecraft:glass
setblock ~-106 ~18 ~-98 minecraft:glass
setblock ~-106 ~18 ~-96 minecraft:glass
setblock ~-106 ~18 ~-94 minecraft:glass
setblock ~-106 ~18 ~-92 minecraft:glass
setblock ~-106 ~18 ~-90 minecraft:glass
setblock ~-106 ~18 ~-88 minecraft:glass
setblock ~-106 ~18 ~-86 minecraft:glass
setblock ~-106 ~18 ~-84 minecraft:glass
setblock ~-106 ~18 ~-82 minecraft:glass
setblock ~-106 ~20 ~-112 minecraft:glass
setblock ~-106 ~20 ~-110 minecraft:glass
setblock ~-106 ~20 ~-108 minecraft:glass
setblock ~-106 ~20 ~-106 minecraft:glass
setblock ~-106 ~20 ~-104 minecraft:glass
setblock ~-106 ~20 ~-102 minecraft:glass
setblock ~-106 ~20 ~-100 minecraft:glass
setblock ~-106 ~20 ~-98 minecraft:glass
setblock ~-106 ~20 ~-96 minecraft:glass
setblock ~-106 ~20 ~-94 minecraft:glass
setblock ~-106 ~20 ~-92 minecraft:glass
setblock ~-106 ~20 ~-90 minecraft:glass
setblock ~-106 ~20 ~-88 minecraft:glass
setblock ~-106 ~20 ~-86 minecraft:glass
setblock ~-106 ~20 ~-84 minecraft:glass
setblock ~-106 ~20 ~-82 minecraft:glass
setblock ~-106 ~22 ~-112 minecraft:glass
setblock ~-106 ~22 ~-110 minecraft:glass
setblock ~-106 ~22 ~-108 minecraft:glass
setblock ~-106 ~22 ~-106 minecraft:glass
setblock ~-106 ~22 ~-104 minecraft:glass
setblock ~-106 ~22 ~-102 minecraft:glass
setblock ~-106 ~22 ~-100 minecraft:glass
setblock ~-106 ~22 ~-98 minecraft:glass
setblock ~-106 ~22 ~-96 minecraft:glass
setblock ~-106 ~22 ~-94 minecraft:glass
setblock ~-106 ~22 ~-92 minecraft:glass
setblock ~-106 ~22 ~-90 minecraft:glass
setblock ~-106 ~22 ~-88 minecraft:glass
setblock ~-106 ~22 ~-86 minecraft:glass
setblock ~-106 ~22 ~-84 minecraft:glass
setblock ~-106 ~22 ~-82 minecraft:glass
setblock ~-106 ~24 ~-112 minecraft:glass
setblock ~-106 ~24 ~-110 minecraft:glass
setblock ~-106 ~24 ~-108 minecraft:glass
setblock ~-106 ~24 ~-106 minecraft:glass
setblock ~-106 ~24 ~-104 minecraft:glass
setblock ~-106 ~24 ~-102 minecraft:glass
setblock ~-106 ~24 ~-100 minecraft:glass
setblock ~-106 ~24 ~-98 minecraft:glass
setblock ~-106 ~24 ~-96 minecraft:glass
setblock ~-106 ~24 ~-94 minecraft:glass
setblock ~-106 ~24 ~-92 minecraft:glass
setblock ~-106 ~24 ~-90 minecraft:glass
setblock ~-106 ~24 ~-88 minecraft:glass
setblock ~-106 ~24 ~-86 minecraft:glass
setblock ~-106 ~24 ~-84 minecraft:glass
setblock ~-106 ~24 ~-82 minecraft:glass
setblock ~-106 ~26 ~-112 minecraft:glass
setblock ~-106 ~26 ~-110 minecraft:glass
setblock ~-106 ~26 ~-108 minecraft:glass
setblock ~-106 ~26 ~-106 minecraft:glass
setblock ~-106 ~26 ~-104 minecraft:glass
setblock ~-106 ~26 ~-102 minecraft:glass
setblock ~-106 ~26 ~-100 minecraft:glass
setblock ~-106 ~26 ~-98 minecraft:glass
setblock ~-106 ~26 ~-96 minecraft:glass
setblock ~-106 ~26 ~-94 minecraft:glass
setblock ~-106 ~26 ~-92 minecraft:glass
setblock ~-106 ~26 ~-90 minecraft:glass
setblock ~-106 ~26 ~-88 minecraft:glass
setblock ~-106 ~26 ~-86 minecraft:glass
setblock ~-106 ~26 ~-84 minecraft:glass
setblock ~-106 ~26 ~-82 minecraft:glass
setblock ~-106 ~28 ~-112 minecraft:glass
setblock ~-106 ~28 ~-110 minecraft:glass
setblock ~-106 ~28 ~-108 minecraft:glass
setblock ~-106 ~28 ~-106 minecraft:glass
setblock ~-106 ~28 ~-104 minecraft:glass
setblock ~-106 ~28 ~-102 minecraft:glass
setblock ~-106 ~28 ~-100 minecraft:glass
setblock ~-106 ~28 ~-98 minecraft:glass
setblock ~-106 ~28 ~-96 minecraft:glass
setblock ~-106 ~28 ~-94 minecraft:glass
setblock ~-106 ~28 ~-92 minecraft:glass
setblock ~-106 ~28 ~-90 minecraft:glass
setblock ~-106 ~28 ~-88 minecraft:glass
setblock ~-106 ~28 ~-86 minecraft:glass
setblock ~-106 ~28 ~-84 minecraft:glass
setblock ~-106 ~28 ~-82 minecraft:glass
setblock ~-106 ~30 ~-112 minecraft:glass
setblock ~-106 ~30 ~-110 minecraft:glass
setblock ~-106 ~30 ~-108 minecraft:glass
setblock ~-106 ~30 ~-106 minecraft:glass
setblock ~-106 ~30 ~-104 minecraft:glass
setblock ~-106 ~30 ~-102 minecraft:glass
setblock ~-106 ~30 ~-100 minecraft:glass
setblock ~-106 ~30 ~-98 minecraft:glass
setblock ~-106 ~30 ~-96 minecraft:glass
setblock ~-106 ~30 ~-94 minecraft:glass
setblock ~-106 ~30 ~-92 minecraft:glass
setblock ~-106 ~30 ~-90 minecraft:glass
setblock ~-106 ~30 ~-88 minecraft:glass
setblock ~-106 ~30 ~-86 minecraft:glass
setblock ~-106 ~30 ~-84 minecraft:glass
setblock ~-106 ~30 ~-82 minecraft:glass
setblock ~-104 ~0 ~-112 minecraft:glass
setblock ~-104 ~0 ~-110 minecraft:glass
setblock ~-104 ~0 ~-108 minecraft:glass
setblock ~-104 ~0 ~-106 minecraft:glass
setblock ~-104 ~0 ~-104 minecraft:glass
setblock ~-104 ~0 ~-102 minecraft:glass
setblock ~-104 ~0 ~-100 minecraft:glass
setblock ~-104 ~0 ~-98 minecraft:glass
setblock ~-104 ~0 ~-96 minecraft:glass
setblock ~-104 ~0 ~-94 minecraft:glass
setblock ~-104 ~0 ~-92 minecraft:glass
setblock ~-104 ~0 ~-90 minecraft:glass
setblock ~-104 ~0 ~-88 minecraft:glass
setblock ~-104 ~0 ~-86 minecraft:glass
setblock ~-104 ~0 ~-84 minecraft:glass
setblock ~-104 ~0 ~-82 minecraft:glass
setblock ~-104 ~2 ~-112 minecraft:glass
setblock ~-104 ~2 ~-110 minecraft:glass
setblock ~-104 ~2 ~-108 minecraft:glass
setblock ~-104 ~2 ~-106 minecraft:glass
setblock ~-104 ~2 ~-104 minecraft:glass
setblock ~-104 ~2 ~-102 minecraft:glass
setblock ~-104 ~2 ~-100 minecraft:glass
setblock ~-104 ~2 ~-98 minecraft:glass
setblock ~-104 ~2 ~-96 minecraft:glass
setblock ~-104 ~2 ~-94 minecraft:glass
setblock ~-104 ~2 ~-92 minecraft:glass
setblock ~-104 ~2 ~-90 minecraft:glass
setblock ~-104 ~2 ~-88 minecraft:glass
setblock ~-104 ~2 ~-86 minecraft:glass
setblock ~-104 ~2 ~-84 minecraft:glass
setblock ~-104 ~2 ~-82 minecraft:glass
setblock ~-104 ~4 ~-112 minecraft:glass
setblock ~-104 ~4 ~-110 minecraft:glass
setblock ~-104 ~4 ~-108 minecraft:glass
setblock ~-104 ~4 ~-106 minecraft:glass
setblock ~-104 ~4 ~-104 minecraft:glass
setblock ~-104 ~4 ~-102 minecraft:glass
setblock ~-104 ~4 ~-100 minecraft:glass
setblock ~-104 ~4 ~-98 minecraft:glass
setblock ~-104 ~4 ~-96 minecraft:glass
setblock ~-104 ~4 ~-94 minecraft:glass
setblock ~-104 ~4 ~-92 minecraft:glass
setblock ~-104 ~4 ~-90 minecraft:glass
setblock ~-104 ~4 ~-88 minecraft:glass
setblock ~-104 ~4 ~-86 minecraft:glass
setblock ~-104 ~4 ~-84 minecraft:glass
setblock ~-104 ~4 ~-82 minecraft:glass
setblock ~-104 ~6 ~-112 minecraft:glass
setblock ~-104 ~6 ~-110 minecraft:glass
setblock ~-104 ~6 ~-108 minecraft:glass
setblock ~-104 ~6 ~-106 minecraft:glass
setblock ~-104 ~6 ~-104 minecraft:glass
setblock ~-104 ~6 ~-102 minecraft:glass
setblock ~-104 ~6 ~-100 minecraft:glass
setblock ~-104 ~6 ~-98 minecraft:glass
setblock ~-104 ~6 ~-96 minecraft:glass
setblock ~-104 ~6 ~-94 minecraft:glass
setblock ~-104 ~6 ~-92 minecraft:glass
setblock ~-104 ~6 ~-90 minecraft:glass
setblock ~-104 ~6 ~-88 minecraft:glass
setblock ~-104 ~6 ~-86 minecraft:glass
setblock ~-104 ~6 ~-84 minecraft:glass
setblock ~-104 ~6 ~-82 minecraft:glass
setblock ~-104 ~8 ~-112 minecraft:glass
setblock ~-104 ~8 ~-110 minecraft:glass
setblock ~-104 ~8 ~-108 minecraft:glass
setblock ~-104 ~8 ~-106 minecraft:glass
setblock ~-104 ~8 ~-104 minecraft:glass
setblock ~-104 ~8 ~-102 minecraft:glass
setblock ~-104 ~8 ~-100 minecraft:glass
setblock ~-104 ~8 ~-98 minecraft:glass
setblock ~-104 ~8 ~-96 minecraft:glass
setblock ~-104 ~8 ~-94 minecraft:glass
setblock ~-104 ~8 ~-92 minecraft:glass
setblock ~-104 ~8 ~-90 minecraft:glass
setblock ~-104 ~8 ~-88 minecraft:glass
setblock ~-104 ~8 ~-86 minecraft:glass
setblock ~-104 ~8 ~-84 minecraft:glass
setblock ~-104 ~8 ~-82 minecraft:glass
setblock ~-104 ~10 ~-112 minecraft:glass
setblock ~-104 ~10 ~-110 minecraft:glass
setblock ~-104 ~10 ~-108 minecraft:glass
setblock ~-104 ~10 ~-106 minecraft:glass
setblock ~-104 ~10 ~-104 minecraft:glass
setblock ~-104 ~10 ~-102 minecraft:glass
setblock ~-104 ~10 ~-100 minecraft:glass
setblock ~-104 ~10 ~-98 minecraft:glass
setblock ~-104 ~10 ~-96 minecraft:glass
setblock ~-104 ~10 ~-94 minecraft:glass
setblock ~-104 ~10 ~-92 minecraft:glass
setblock ~-104 ~10 ~-90 minecraft:glass
setblock ~-104 ~10 ~-88 minecraft:glass
setblock ~-104 ~10 ~-86 minecraft:glass
setblock ~-104 ~10 ~-84 minecraft:glass
setblock ~-104 ~10 ~-82 minecraft:glass
setblock ~-104 ~12 ~-112 minecraft:glass
setblock ~-104 ~12 ~-110 minecraft:glass
setblock ~-104 ~12 ~-108 minecraft:glass
setblock ~-104 ~12 ~-106 minecraft:glass
setblock ~-104 ~12 ~-104 minecraft:glass
setblock ~-104 ~12 ~-102 minecraft:glass
setblock ~-104 ~12 ~-100 minecraft:glass
setblock ~-104 ~12 ~-98 minecraft:glass
setblock ~-104 ~12 ~-96 minecraft:glass
setblock ~-104 ~12 ~-94 minecraft:glass
setblock ~-104 ~12 ~-92 minecraft:glass
setblock ~-104 ~12 ~-90 minecraft:glass
setblock ~-104 ~12 ~-88 minecraft:glass
setblock ~-104 ~12 ~-86 minecraft:glass
setblock ~-104 ~12 ~-84 minecraft:glass
setblock ~-104 ~12 ~-82 minecraft:glass
setblock ~-104 ~14 ~-112 minecraft:glass
setblock ~-104 ~14 ~-110 minecraft:glass
setblock ~-104 ~14 ~-108 minecraft:glass
setblock ~-104 ~14 ~-106 minecraft:glass
setblock ~-104 ~14 ~-104 minecraft:glass
setblock ~-104 ~14 ~-102 minecraft:glass
setblock ~-104 ~14 ~-100 minecraft:glass
setblock ~-104 ~14 ~-98 minecraft:glass
setblock ~-104 ~14 ~-96 minecraft:glass
setblock ~-104 ~14 ~-94 minecraft:glass
setblock ~-104 ~14 ~-92 minecraft:glass
setblock ~-104 ~14 ~-90 minecraft:glass
setblock ~-104 ~14 ~-88 minecraft:glass
setblock ~-104 ~14 ~-86 minecraft:glass
setblock ~-104 ~14 ~-84 minecraft:glass
setblock ~-104 ~14 ~-82 minecraft:glass
setblock ~-104 ~16 ~-112 minecraft:glass
setblock ~-104 ~16 ~-110 minecraft:glass
setblock ~-104 ~16 ~-108 minecraft:glass
setblock ~-104 ~16 ~-106 minecraft:glass
setblock ~-104 ~16 ~-104 minecraft:glass
setblock ~-104 ~16 ~-102 minecraft:glass
setblock ~-104 ~16 ~-100 minecraft:glass
setblock ~-104 ~16 ~-98 minecraft:glass
setblock ~-104 ~16 ~-96 minecraft:glass
setblock ~-104 ~16 ~-94 minecraft:glass
setblock ~-104 ~16 ~-92 minecraft:glass
setblock ~-104 ~16 ~-90 minecraft:glass
setblock ~-104 ~16 ~-88 minecraft:glass
setblock ~-104 ~16 ~-86 minecraft:glass
setblock ~-104 ~16 ~-84 minecraft:glass
setblock ~-104 ~16 ~-82 minecraft:glass
setblock ~-104 ~18 ~-112 minecraft:glass
setblock ~-104 ~18 ~-110 minecraft:glass
setblock ~-104 ~18 ~-108 minecraft:glass
setblock ~-104 ~18 ~-106 minecraft:glass
setblock ~-104 ~18 ~-104 minecraft:glass
setblock ~-104 ~18 ~-102 minecraft:glass
setblock ~-104 ~18 ~-100 minecraft:glass
setblock ~-104 ~18 ~-98 minecraft:glass
setblock ~-104 ~18 ~-96 minecraft:glass
setblock ~-104 ~18 ~-94 minecraft:glass
setblock ~-104 ~18 ~-92 minecraft:glass
setblock ~-104 ~18 ~-90 minecraft:glass
setblock ~-104 ~18 ~-88 minecraft:glass
setblock ~-104 ~18 ~-86 minecraft:glass
setblock ~-104 ~18 ~-84 minecraft:glass
setblock ~-104 ~18 ~-82 minecraft:glass
setblock ~-104 ~20 ~-112 minecraft:glass
setblock ~-104 ~20 ~-110 minecraft:glass
setblock ~-104 ~20 ~-108 minecraft:glass
setblock ~-104 ~20 ~-106 minecraft:glass
setblock ~-104 ~20 ~-104 minecraft:glass
setblock ~-104 ~20 ~-102 minecraft:glass
setblock ~-104 ~20 ~-100 minecraft:glass
setblock ~-104 ~20 ~-98 minecraft:glass
setblock ~-104 ~20 ~-96 minecraft:glass
setblock ~-104 ~20 ~-94 minecraft:glass
setblock ~-104 ~20 ~-92 minecraft:glass
setblock ~-104 ~20 ~-90 minecraft:glass
setblock ~-104 ~20 ~-88 minecraft:glass
setblock ~-104 ~20 ~-86 minecraft:glass
setblock ~-104 ~20 ~-84 minecraft:glass
setblock ~-104 ~20 ~-82 minecraft:glass
setblock ~-104 ~22 ~-112 minecraft:glass
setblock ~-104 ~22 ~-110 minecraft:glass
setblock ~-104 ~22 ~-108 minecraft:glass
setblock ~-104 ~22 ~-106 minecraft:glass
setblock ~-104 ~22 ~-104 minecraft:glass
setblock ~-104 ~22 ~-102 minecraft:glass
setblock ~-104 ~22 ~-100 minecraft:glass
setblock ~-104 ~22 ~-98 minecraft:glass
setblock ~-104 ~22 ~-96 minecraft:glass
setblock ~-104 ~22 ~-94 minecraft:glass
setblock ~-104 ~22 ~-92 minecraft:glass
setblock ~-104 ~22 ~-90 minecraft:glass
setblock ~-104 ~22 ~-88 minecraft:glass
setblock ~-104 ~22 ~-86 minecraft:glass
setblock ~-104 ~22 ~-84 minecraft:glass
setblock ~-104 ~22 ~-82 minecraft:glass
setblock ~-104 ~24 ~-112 minecraft:glass
setblock ~-104 ~24 ~-110 minecraft:glass
setblock ~-104 ~24 ~-108 minecraft:glass
setblock ~-104 ~24 ~-106 minecraft:glass
setblock ~-104 ~24 ~-104 minecraft:glass
setblock ~-104 ~24 ~-102 minecraft:glass
setblock ~-104 ~24 ~-100 minecraft:glass
setblock ~-104 ~24 ~-98 minecraft:glass
setblock ~-104 ~24 ~-96 minecraft:glass
setblock ~-104 ~24 ~-94 minecraft:glass
setblock ~-104 ~24 ~-92 minecraft:glass
setblock ~-104 ~24 ~-90 minecraft:glass
setblock ~-104 ~24 ~-88 minecraft:glass
setblock ~-104 ~24 ~-86 minecraft:glass
setblock ~-104 ~24 ~-84 minecraft:glass
setblock ~-104 ~24 ~-82 minecraft:glass
setblock ~-104 ~26 ~-112 minecraft:glass
setblock ~-104 ~26 ~-110 minecraft:glass
setblock ~-104 ~26 ~-108 minecraft:glass
setblock ~-104 ~26 ~-106 minecraft:glass
setblock ~-104 ~26 ~-104 minecraft:glass
setblock ~-104 ~26 ~-102 minecraft:glass
setblock ~-104 ~26 ~-100 minecraft:glass
setblock ~-104 ~26 ~-98 minecraft:glass
setblock ~-104 ~26 ~-96 minecraft:glass
setblock ~-104 ~26 ~-94 minecraft:glass
setblock ~-104 ~26 ~-92 minecraft:glass
setblock ~-104 ~26 ~-90 minecraft:glass
setblock ~-104 ~26 ~-88 minecraft:glass
setblock ~-104 ~26 ~-86 minecraft:glass
setblock ~-104 ~26 ~-84 minecraft:glass
setblock ~-104 ~26 ~-82 minecraft:glass
setblock ~-104 ~28 ~-112 minecraft:glass
setblock ~-104 ~28 ~-110 minecraft:glass
setblock ~-104 ~28 ~-108 minecraft:glass
setblock ~-104 ~28 ~-106 minecraft:glass
setblock ~-104 ~28 ~-104 minecraft:glass
setblock ~-104 ~28 ~-102 minecraft:glass
setblock ~-104 ~28 ~-100 minecraft:glass
setblock ~-104 ~28 ~-98 minecraft:glass
setblock ~-104 ~28 ~-96 minecraft:glass
setblock ~-104 ~28 ~-94 minecraft:glass
setblock ~-104 ~28 ~-92 minecraft:glass
setblock ~-104 ~28 ~-90 minecraft:glass
setblock ~-104 ~28 ~-88 minecraft:glass
setblock ~-104 ~28 ~-86 minecraft:glass
setblock ~-104 ~28 ~-84 minecraft:glass
setblock ~-104 ~28 ~-82 minecraft:glass
setblock ~-104 ~30 ~-112 minecraft:glass
setblock ~-104 ~30 ~-110 minecraft:glass
setblock ~-104 ~30 ~-108 minecraft:glass
setblock ~-104 ~30 ~-106 minecraft:glass
setblock ~-104 ~30 ~-104 minecraft:glass
setblock ~-104 ~30 ~-102 minecraft:glass
setblock ~-104 ~30 ~-100 minecraft:glass
setblock ~-104 ~30 ~-98 minecraft:glass
setblock ~-104 ~30 ~-96 minecraft:glass
setblock ~-104 ~30 ~-94 minecraft:glass
setblock ~-104 ~30 ~-92 minecraft:glass
setblock ~-104 ~30 ~-90 minecraft:glass
setblock ~-104 ~30 ~-88 minecraft:glass
setblock ~-104 ~30 ~-86 minecraft:glass
setblock ~-104 ~30 ~-84 minecraft:glass
setblock ~-104 ~30 ~-82 minecraft:glass
setblock ~-102 ~0 ~-112 minecraft:glass
setblock ~-102 ~0 ~-110 minecraft:glass
setblock ~-102 ~0 ~-108 minecraft:glass
setblock ~-102 ~0 ~-106 minecraft:glass
setblock ~-102 ~0 ~-104 minecraft:glass
setblock ~-102 ~0 ~-102 minecraft:glass
setblock ~-102 ~0 ~-100 minecraft:glass
setblock ~-102 ~0 ~-98 minecraft:glass
setblock ~-102 ~0 ~-96 minecraft:glass
setblock ~-102 ~0 ~-94 minecraft:glass
setblock ~-102 ~0 ~-92 minecraft:glass
setblock ~-102 ~0 ~-90 minecraft:glass
setblock ~-102 ~0 ~-88 minecraft:glass
setblock ~-102 ~0 ~-86 minecraft:glass
setblock ~-102 ~0 ~-84 minecraft:glass
setblock ~-102 ~0 ~-82 minecraft:glass
setblock ~-102 ~2 ~-112 minecraft:glass
setblock ~-102 ~2 ~-110 minecraft:glass
setblock ~-102 ~2 ~-108 minecraft:glass
setblock ~-102 ~2 ~-106 minecraft:glass
setblock ~-102 ~2 ~-104 minecraft:glass
setblock ~-102 ~2 ~-102 minecraft:glass
setblock ~-102 ~2 ~-100 minecraft:glass
setblock ~-102 ~2 ~-98 minecraft:glass
setblock ~-102 ~2 ~-96 minecraft:glass
setblock ~-102 ~2 ~-94 minecraft:glass
setblock ~-102 ~2 ~-92 minecraft:glass
setblock ~-102 ~2 ~-90 minecraft:glass
setblock ~-102 ~2 ~-88 minecraft:glass
setblock ~-102 ~2 ~-86 minecraft:glass
setblock ~-102 ~2 ~-84 minecraft:glass
setblock ~-102 ~2 ~-82 minecraft:glass
setblock ~-102 ~4 ~-112 minecraft:glass
setblock ~-102 ~4 ~-110 minecraft:glass
setblock ~-102 ~4 ~-108 minecraft:glass
setblock ~-102 ~4 ~-106 minecraft:glass
setblock ~-102 ~4 ~-104 minecraft:glass
setblock ~-102 ~4 ~-102 minecraft:glass
setblock ~-102 ~4 ~-100 minecraft:glass
setblock ~-102 ~4 ~-98 minecraft:glass
setblock ~-102 ~4 ~-96 minecraft:glass
setblock ~-102 ~4 ~-94 minecraft:glass
setblock ~-102 ~4 ~-92 minecraft:glass
setblock ~-102 ~4 ~-90 minecraft:glass
setblock ~-102 ~4 ~-88 minecraft:glass
setblock ~-102 ~4 ~-86 minecraft:glass
setblock ~-102 ~4 ~-84 minecraft:glass
setblock ~-102 ~4 ~-82 minecraft:glass
setblock ~-102 ~6 ~-112 minecraft:glass
setblock ~-102 ~6 ~-110 minecraft:glass
setblock ~-102 ~6 ~-108 minecraft:glass
setblock ~-102 ~6 ~-106 minecraft:glass
setblock ~-102 ~6 ~-104 minecraft:glass
setblock ~-102 ~6 ~-102 minecraft:glass
setblock ~-102 ~6 ~-100 minecraft:glass
setblock ~-102 ~6 ~-98 minecraft:glass
setblock ~-102 ~6 ~-96 minecraft:glass
setblock ~-102 ~6 ~-94 minecraft:glass
setblock ~-102 ~6 ~-92 minecraft:glass
setblock ~-102 ~6 ~-90 minecraft:glass
setblock ~-102 ~6 ~-88 minecraft:glass
setblock ~-102 ~6 ~-86 minecraft:glass
setblock ~-102 ~6 ~-84 minecraft:glass
setblock ~-102 ~6 ~-82 minecraft:glass
setblock ~-102 ~8 ~-112 minecraft:glass
setblock ~-102 ~8 ~-110 minecraft:glass
setblock ~-102 ~8 ~-108 minecraft:glass
setblock ~-102 ~8 ~-106 minecraft:glass
setblock ~-102 ~8 ~-104 minecraft:glass
setblock ~-102 ~8 ~-102 minecraft:glass
setblock ~-102 ~8 ~-100 minecraft:glass
setblock ~-102 ~8 ~-98 minecraft:glass
setblock ~-102 ~8 ~-96 minecraft:glass
setblock ~-102 ~8 ~-94 minecraft:glass
setblock ~-102 ~8 ~-92 minecraft:glass
setblock ~-102 ~8 ~-90 minecraft:glass
setblock ~-102 ~8 ~-88 minecraft:glass
setblock ~-102 ~8 ~-86 minecraft:glass
setblock ~-102 ~8 ~-84 minecraft:glass
setblock ~-102 ~8 ~-82 minecraft:glass
setblock ~-102 ~10 ~-112 minecraft:glass
setblock ~-102 ~10 ~-110 minecraft:glass
setblock ~-102 ~10 ~-108 minecraft:glass
setblock ~-102 ~10 ~-106 minecraft:glass
setblock ~-102 ~10 ~-104 minecraft:glass
setblock ~-102 ~10 ~-102 minecraft:glass
setblock ~-102 ~10 ~-100 minecraft:glass
setblock ~-102 ~10 ~-98 minecraft:glass
setblock ~-102 ~10 ~-96 minecraft:glass
setblock ~-102 ~10 ~-94 minecraft:glass
setblock ~-102 ~10 ~-92 minecraft:glass
setblock ~-102 ~10 ~-90 minecraft:glass
setblock ~-102 ~10 ~-88 minecraft:glass
setblock ~-102 ~10 ~-86 minecraft:glass
setblock ~-102 ~10 ~-84 minecraft:glass
setblock ~-102 ~10 ~-82 minecraft:glass
setblock ~-102 ~12 ~-112 minecraft:glass
setblock ~-102 ~12 ~-110 minecraft:glass
setblock ~-102 ~12 ~-108 minecraft:glass
setblock ~-102 ~12 ~-106 minecraft:glass
setblock ~-102 ~12 ~-104 minecraft:glass
setblock ~-102 ~12 ~-102 minecraft:glass
setblock ~-102 ~12 ~-100 minecraft:glass
setblock ~-102 ~12 ~-98 minecraft:glass
setblock ~-102 ~12 ~-96 minecraft:glass
setblock ~-102 ~12 ~-94 minecraft:glass
setblock ~-102 ~12 ~-92 minecraft:glass
setblock ~-102 ~12 ~-90 minecraft:glass
setblock ~-102 ~12 ~-88 minecraft:glass
setblock ~-102 ~12 ~-86 minecraft:glass
setblock ~-102 ~12 ~-84 minecraft:glass
setblock ~-102 ~12 ~-82 minecraft:glass
setblock ~-102 ~14 ~-112 minecraft:glass
setblock ~-102 ~14 ~-110 minecraft:glass
setblock ~-102 ~14 ~-108 minecraft:glass
setblock ~-102 ~14 ~-106 minecraft:glass
setblock ~-102 ~14 ~-104 minecraft:glass
setblock ~-102 ~14 ~-102 minecraft:glass
setblock ~-102 ~14 ~-100 minecraft:glass
setblock ~-102 ~14 ~-98 minecraft:glass
setblock ~-102 ~14 ~-96 minecraft:glass
setblock ~-102 ~14 ~-94 minecraft:glass
setblock ~-102 ~14 ~-92 minecraft:glass
setblock ~-102 ~14 ~-90 minecraft:glass
setblock ~-102 ~14 ~-88 minecraft:glass
setblock ~-102 ~14 ~-86 minecraft:glass
setblock ~-102 ~14 ~-84 minecraft:glass
setblock ~-102 ~14 ~-82 minecraft:glass
setblock ~-102 ~16 ~-112 minecraft:glass
setblock ~-102 ~16 ~-110 minecraft:glass
setblock ~-102 ~16 ~-108 minecraft:glass
setblock ~-102 ~16 ~-106 minecraft:glass
setblock ~-102 ~16 ~-104 minecraft:glass
setblock ~-102 ~16 ~-102 minecraft:glass
setblock ~-102 ~16 ~-100 minecraft:glass
setblock ~-102 ~16 ~-98 minecraft:glass
setblock ~-102 ~16 ~-96 minecraft:glass
setblock ~-102 ~16 ~-94 minecraft:glass
setblock ~-102 ~16 ~-92 minecraft:glass
setblock ~-102 ~16 ~-90 minecraft:glass
setblock ~-102 ~16 ~-88 minecraft:glass
setblock ~-102 ~16 ~-86 minecraft:glass
setblock ~-102 ~16 ~-84 minecraft:glass
setblock ~-102 ~16 ~-82 minecraft:glass
setblock ~-102 ~18 ~-112 minecraft:glass
setblock ~-102 ~18 ~-110 minecraft:glass
setblock ~-102 ~18 ~-108 minecraft:glass
setblock ~-102 ~18 ~-106 minecraft:glass
setblock ~-102 ~18 ~-104 minecraft:glass
setblock ~-102 ~18 ~-102 minecraft:glass
setblock ~-102 ~18 ~-100 minecraft:glass
setblock ~-102 ~18 ~-98 minecraft:glass
setblock ~-102 ~18 ~-96 minecraft:glass
setblock ~-102 ~18 ~-94 minecraft:glass
setblock ~-102 ~18 ~-92 minecraft:glass
setblock ~-102 ~18 ~-90 minecraft:glass
setblock ~-102 ~18 ~-88 minecraft:glass
setblock ~-102 ~18 ~-86 minecraft:glass
setblock ~-102 ~18 ~-84 minecraft:glass
setblock ~-102 ~18 ~-82 minecraft:glass
setblock ~-102 ~20 ~-112 minecraft:glass
setblock ~-102 ~20 ~-110 minecraft:glass
setblock ~-102 ~20 ~-108 minecraft:glass
setblock ~-102 ~20 ~-106 minecraft:glass
setblock ~-102 ~20 ~-104 minecraft:glass
setblock ~-102 ~20 ~-102 minecraft:glass
setblock ~-102 ~20 ~-100 minecraft:glass
setblock ~-102 ~20 ~-98 minecraft:glass
setblock ~-102 ~20 ~-96 minecraft:glass
setblock ~-102 ~20 ~-94 minecraft:glass
setblock ~-102 ~20 ~-92 minecraft:glass
setblock ~-102 ~20 ~-90 minecraft:glass
setblock ~-102 ~20 ~-88 minecraft:glass
setblock ~-102 ~20 ~-86 minecraft:glass
setblock ~-102 ~20 ~-84 minecraft:glass
setblock ~-102 ~20 ~-82 minecraft:glass
setblock ~-102 ~22 ~-112 minecraft:glass
setblock ~-102 ~22 ~-110 minecraft:glass
setblock ~-102 ~22 ~-108 minecraft:glass
setblock ~-102 ~22 ~-106 minecraft:glass
setblock ~-102 ~22 ~-104 minecraft:glass
setblock ~-102 ~22 ~-102 minecraft:glass
setblock ~-102 ~22 ~-100 minecraft:glass
setblock ~-102 ~22 ~-98 minecraft:glass
setblock ~-102 ~22 ~-96 minecraft:glass
setblock ~-102 ~22 ~-94 minecraft:glass
setblock ~-102 ~22 ~-92 minecraft:glass
setblock ~-102 ~22 ~-90 minecraft:glass
setblock ~-102 ~22 ~-88 minecraft:glass
setblock ~-102 ~22 ~-86 minecraft:glass
setblock ~-102 ~22 ~-84 minecraft:glass
setblock ~-102 ~22 ~-82 minecraft:glass
setblock ~-102 ~24 ~-112 minecraft:glass
setblock ~-102 ~24 ~-110 minecraft:glass
setblock ~-102 ~24 ~-108 minecraft:glass
setblock ~-102 ~24 ~-106 minecraft:glass
setblock ~-102 ~24 ~-104 minecraft:glass
setblock ~-102 ~24 ~-102 minecraft:glass
setblock ~-102 ~24 ~-100 minecraft:glass
setblock ~-102 ~24 ~-98 minecraft:glass
setblock ~-102 ~24 ~-96 minecraft:glass
setblock ~-102 ~24 ~-94 minecraft:glass
setblock ~-102 ~24 ~-92 minecraft:glass
setblock ~-102 ~24 ~-90 minecraft:glass
setblock ~-102 ~24 ~-88 minecraft:glass
setblock ~-102 ~24 ~-86 minecraft:glass
setblock ~-102 ~24 ~-84 minecraft:glass
setblock ~-102 ~24 ~-82 minecraft:glass
setblock ~-102 ~26 ~-112 minecraft:glass
setblock ~-102 ~26 ~-110 minecraft:glass
setblock ~-102 ~26 ~-108 minecraft:glass
setblock ~-102 ~26 ~-106 minecraft:glass
setblock ~-102 ~26 ~-104 minecraft:glass
setblock ~-102 ~26 ~-102 minecraft:glass
setblock ~-102 ~26 ~-100 minecraft:glass
setblock ~-102 ~26 ~-98 minecraft:glass
setblock ~-102 ~26 ~-96 minecraft:glass
setblock ~-102 ~26 ~-94 minecraft:glass
setblock ~-102 ~26 ~-92 minecraft:glass
setblock ~-102 ~26 ~-90 minecraft:glass
setblock ~-102 ~26 ~-88 minecraft:glass
setblock ~-102 ~26 ~-86 minecraft:glass
setblock ~-102 ~26 ~-84 minecraft:glass
setblock ~-102 ~26 ~-82 minecraft:glass
setblock ~-102 ~28 ~-112 minecraft:glass
setblock ~-102 ~28 ~-110 minecraft:glass
setblock ~-102 ~28 ~-108 minecraft:glass
setblock ~-102 ~28 ~-106 minecraft:glass
setblock ~-102 ~28 ~-104 minecraft:glass
setblock ~-102 ~28 ~-102 minecraft:glass
setblock ~-102 ~28 ~-100 minecraft:glass
setblock ~-102 ~28 ~-98 minecraft:glass
setblock ~-102 ~28 ~-96 minecraft:glass
setblock ~-102 ~28 ~-94 minecraft:glass
setblock ~-102 ~28 ~-92 minecraft:glass
setblock ~-102 ~28 ~-90 minecraft:glass
setblock ~-102 ~28 ~-88 minecraft:glass
setblock ~-102 ~28 ~-86 minecraft:glass
setblock ~-102 ~28 ~-84 minecraft:glass
setblock ~-102 ~28 ~-82 minecraft:glass
setblock ~-102 ~30 ~-112 minecraft:glass
setblock ~-102 ~30 ~-110 minecraft:glass
setblock ~-102 ~30 ~-108 minecraft:glass
setblock ~-102 ~30 ~-106 minecraft:glass
setblock ~-102 ~30 ~-104 minecraft:glass
setblock ~-102 ~30 ~-102 minecraft:glass
setblock ~-102 ~30 ~-100 minecraft:glass
setblock ~-102 ~30 ~-98 minecraft:glass
setblock ~-102 ~30 ~-96 minecraft:glass
setblock ~-102 ~30 ~-94 minecraft:glass
setblock ~-102 ~30 ~-92 minecraft:glass
setblock ~-102 ~30 ~-90 minecraft:glass
setblock ~-102 ~30 ~-88 minecraft:glass
setblock ~-102 ~30 ~-86 minecraft:glass
setblock ~-102 ~30 ~-84 minecraft:glass
setblock ~-102 ~30 ~-82 minecraft:glass
setblock ~-100 ~0 ~-112 minecraft:glass
setblock ~-100 ~0 ~-110 minecraft:glass
setblock ~-100 ~0 ~-108 minecraft:glass
setblock ~-100 ~0 ~-106 minecraft:glass
setblock ~-100 ~0 ~-104 minecraft:glass
setblock ~-100 ~0 ~-102 minecraft:glass
setblock ~-100 ~0 ~-100 minecraft:glass
setblock ~-100 ~0 ~-98 minecraft:glass
setblock ~-100 ~0 ~-96 minecraft:glass
setblock ~-100 ~0 ~-94 minecraft:glass
setblock ~-100 ~0 ~-92 minecraft:glass
setblock ~-100 ~0 ~-90 minecraft:glass
setblock ~-100 ~0 ~-88 minecraft:glass
setblock ~-100 ~0 ~-86 minecraft:glass
setblock ~-100 ~0 ~-84 minecraft:glass
setblock ~-100 ~0 ~-82 minecraft:glass
setblock ~-100 ~2 ~-112 minecraft:glass
setblock ~-100 ~2 ~-110 minecraft:glass
setblock ~-100 ~2 ~-108 minecraft:glass
setblock ~-100 ~2 ~-106 minecraft:glass
setblock ~-100 ~2 ~-104 minecraft:glass
setblock ~-100 ~2 ~-102 minecraft:glass
setblock ~-100 ~2 ~-100 minecraft:glass
setblock ~-100 ~2 ~-98 minecraft:glass
setblock ~-100 ~2 ~-96 minecraft:glass
setblock ~-100 ~2 ~-94 minecraft:glass
setblock ~-100 ~2 ~-92 minecraft:glass
setblock ~-100 ~2 ~-90 minecraft:glass
setblock ~-100 ~2 ~-88 minecraft:glass
setblock ~-100 ~2 ~-86 minecraft:glass
setblock ~-100 ~2 ~-84 minecraft:glass
setblock ~-100 ~2 ~-82 minecraft:glass
setblock ~-100 ~4 ~-112 minecraft:glass
setblock ~-100 ~4 ~-110 minecraft:glass
setblock ~-100 ~4 ~-108 minecraft:glass
setblock ~-100 ~4 ~-106 minecraft:glass
setblock ~-100 ~4 ~-104 minecraft:glass
setblock ~-100 ~4 ~-102 minecraft:glass
setblock ~-100 ~4 ~-100 minecraft:glass
setblock ~-100 ~4 ~-98 minecraft:glass
setblock ~-100 ~4 ~-96 minecraft:glass
setblock ~-100 ~4 ~-94 minecraft:glass
setblock ~-100 ~4 ~-92 minecraft:glass
setblock ~-100 ~4 ~-90 minecraft:glass
setblock ~-100 ~4 ~-88 minecraft:glass
setblock ~-100 ~4 ~-86 minecraft:glass
setblock ~-100 ~4 ~-84 minecraft:glass
setblock ~-100 ~4 ~-82 minecraft:glass
setblock ~-100 ~6 ~-112 minecraft:glass
setblock ~-100 ~6 ~-110 minecraft:glass
setblock ~-100 ~6 ~-108 minecraft:glass
setblock ~-100 ~6 ~-106 minecraft:glass
setblock ~-100 ~6 ~-104 minecraft:glass
setblock ~-100 ~6 ~-102 minecraft:glass
setblock ~-100 ~6 ~-100 minecraft:glass
setblock ~-100 ~6 ~-98 minecraft:glass
setblock ~-100 ~6 ~-96 minecraft:glass
setblock ~-100 ~6 ~-94 minecraft:glass
setblock ~-100 ~6 ~-92 minecraft:glass
setblock ~-100 ~6 ~-90 minecraft:glass
setblock ~-100 ~6 ~-88 minecraft:glass
setblock ~-100 ~6 ~-86 minecraft:glass
setblock ~-100 ~6 ~-84 minecraft:glass
setblock ~-100 ~6 ~-82 minecraft:glass
setblock ~-100 ~8 ~-112 minecraft:glass
setblock ~-100 ~8 ~-110 minecraft:glass
setblock ~-100 ~8 ~-108 minecraft:glass
setblock ~-100 ~8 ~-106 minecraft:glass
setblock ~-100 ~8 ~-104 minecraft:glass
setblock ~-100 ~8 ~-102 minecraft:glass
setblock ~-100 ~8 ~-100 minecraft:glass
setblock ~-100 ~8 ~-98 minecraft:glass
setblock ~-100 ~8 ~-96 minecraft:glass
setblock ~-100 ~8 ~-94 minecraft:glass
setblock ~-100 ~8 ~-92 minecraft:glass
setblock ~-100 ~8 ~-90 minecraft:glass
setblock ~-100 ~8 ~-88 minecraft:glass
setblock ~-100 ~8 ~-86 minecraft:glass
setblock ~-100 ~8 ~-84 minecraft:glass
setblock ~-100 ~8 ~-82 minecraft:glass
setblock ~-100 ~10 ~-112 minecraft:glass
setblock ~-100 ~10 ~-110 minecraft:glass
setblock ~-100 ~10 ~-108 minecraft:glass
setblock ~-100 ~10 ~-106 minecraft:glass
setblock ~-100 ~10 ~-104 minecraft:glass
setblock ~-100 ~10 ~-102 minecraft:glass
setblock ~-100 ~10 ~-100 minecraft:glass
setblock ~-100 ~10 ~-98 minecraft:glass
setblock ~-100 ~10 ~-96 minecraft:glass
setblock ~-100 ~10 ~-94 minecraft:glass
setblock ~-100 ~10 ~-92 minecraft:glass
setblock ~-100 ~10 ~-90 minecraft:glass
setblock ~-100 ~10 ~-88 minecraft:glass
setblock ~-100 ~10 ~-86 minecraft:glass
setblock ~-100 ~10 ~-84 minecraft:glass
setblock ~-100 ~10 ~-82 minecraft:glass
setblock ~-100 ~12 ~-112 minecraft:glass
setblock ~-100 ~12 ~-110 minecraft:glass
setblock ~-100 ~12 ~-108 minecraft:glass
setblock ~-100 ~12 ~-106 minecraft:glass
setblock ~-100 ~12 ~-104 minecraft:glass
setblock ~-100 ~12 ~-102 minecraft:glass
setblock ~-100 ~12 ~-100 minecraft:glass
setblock ~-100 ~12 ~-98 minecraft:glass
setblock ~-100 ~12 ~-96 minecraft:glass
setblock ~-100 ~12 ~-94 minecraft:glass
setblock ~-100 ~12 ~-92 minecraft:glass
setblock ~-100 ~12 ~-90 minecraft:glass
setblock ~-100 ~12 ~-88 minecraft:glass
setblock ~-100 ~12 ~-86 minecraft:glass
setblock ~-100 ~12 ~-84 minecraft:glass
setblock ~-100 ~12 ~-82 minecraft:glass
setblock ~-100 ~14 ~-112 minecraft:glass
setblock ~-100 ~14 ~-110 minecraft:glass
setblock ~-100 ~14 ~-108 minecraft:glass
setblock ~-100 ~14 ~-106 minecraft:glass
setblock ~-100 ~14 ~-104 minecraft:glass
setblock ~-100 ~14 ~-102 minecraft:glass
setblock ~-100 ~14 ~-100 minecraft:glass
setblock ~-100 ~14 ~-98 minecraft:glass
setblock ~-100 ~14 ~-96 minecraft:glass
setblock ~-100 ~14 ~-94 minecraft:glass
setblock ~-100 ~14 ~-92 minecraft:glass
setblock ~-100 ~14 ~-90 minecraft:glass
setblock ~-100 ~14 ~-88 minecraft:glass
setblock ~-100 ~14 ~-86 minecraft:glass
setblock ~-100 ~14 ~-84 minecraft:glass
setblock ~-100 ~14 ~-82 minecraft:glass
setblock ~-100 ~16 ~-112 minecraft:glass
setblock ~-100 ~16 ~-110 minecraft:glass
setblock ~-100 ~16 ~-108 minecraft:glass
setblock ~-100 ~16 ~-106 minecraft:glass
setblock ~-100 ~16 ~-104 minecraft:glass
setblock ~-100 ~16 ~-102 minecraft:glass
setblock ~-100 ~16 ~-100 minecraft:glass
setblock ~-100 ~16 ~-98 minecraft:glass
setblock ~-100 ~16 ~-96 minecraft:glass
setblock ~-100 ~16 ~-94 minecraft:glass
setblock ~-100 ~16 ~-92 minecraft:glass
setblock ~-100 ~16 ~-90 minecraft:glass
setblock ~-100 ~16 ~-88 minecraft:glass
setblock ~-100 ~16 ~-86 minecraft:glass
setblock ~-100 ~16 ~-84 minecraft:glass
setblock ~-100 ~16 ~-82 minecraft:glass
setblock ~-100 ~18 ~-112 minecraft:glass
setblock ~-100 ~18 ~-110 minecraft:glass
setblock ~-100 ~18 ~-108 minecraft:glass
setblock ~-100 ~18 ~-106 minecraft:glass
setblock ~-100 ~18 ~-104 minecraft:glass
setblock ~-100 ~18 ~-102 minecraft:glass
setblock ~-100 ~18 ~-100 minecraft:glass
setblock ~-100 ~18 ~-98 minecraft:glass
setblock ~-100 ~18 ~-96 minecraft:glass
setblock ~-100 ~18 ~-94 minecraft:glass
setblock ~-100 ~18 ~-92 minecraft:glass
setblock ~-100 ~18 ~-90 minecraft:glass
setblock ~-100 ~18 ~-88 minecraft:glass
setblock ~-100 ~18 ~-86 minecraft:glass
setblock ~-100 ~18 ~-84 minecraft:glass
setblock ~-100 ~18 ~-82 minecraft:glass
setblock ~-100 ~20 ~-112 minecraft:glass
setblock ~-100 ~20 ~-110 minecraft:glass
setblock ~-100 ~20 ~-108 minecraft:glass
setblock ~-100 ~20 ~-106 minecraft:glass
setblock ~-100 ~20 ~-104 minecraft:glass
setblock ~-100 ~20 ~-102 minecraft:glass
setblock ~-100 ~20 ~-100 minecraft:glass
setblock ~-100 ~20 ~-98 minecraft:glass
setblock ~-100 ~20 ~-96 minecraft:glass
setblock ~-100 ~20 ~-94 minecraft:glass
setblock ~-100 ~20 ~-92 minecraft:glass
setblock ~-100 ~20 ~-90 minecraft:glass
setblock ~-100 ~20 ~-88 minecraft:glass
setblock ~-100 ~20 ~-86 minecraft:glass
setblock ~-100 ~20 ~-84 minecraft:glass
setblock ~-100 ~20 ~-82 minecraft:glass
setblock ~-100 ~22 ~-112 minecraft:glass
setblock ~-100 ~22 ~-110 minecraft:glass
setblock ~-100 ~22 ~-108 minecraft:glass
setblock ~-100 ~22 ~-106 minecraft:glass
setblock ~-100 ~22 ~-104 minecraft:glass
setblock ~-100 ~22 ~-102 minecraft:glass
setblock ~-100 ~22 ~-100 minecraft:glass
setblock ~-100 ~22 ~-98 minecraft:glass
setblock ~-100 ~22 ~-96 minecraft:glass
setblock ~-100 ~22 ~-94 minecraft:glass
setblock ~-100 ~22 ~-92 minecraft:glass
setblock ~-100 ~22 ~-90 minecraft:glass
setblock ~-100 ~22 ~-88 minecraft:glass
setblock ~-100 ~22 ~-86 minecraft:glass
setblock ~-100 ~22 ~-84 minecraft:glass
setblock ~-100 ~22 ~-82 minecraft:glass
setblock ~-100 ~24 ~-112 minecraft:glass
setblock ~-100 ~24 ~-110 minecraft:glass
setblock ~-100 ~24 ~-108 minecraft:glass
setblock ~-100 ~24 ~-106 minecraft:glass
setblock ~-100 ~24 ~-104 minecraft:glass
setblock ~-100 ~24 ~-102 minecraft:glass
setblock ~-100 ~24 ~-100 minecraft:glass
setblock ~-100 ~24 ~-98 minecraft:glass
setblock ~-100 ~24 ~-96 minecraft:glass
setblock ~-100 ~24 ~-94 minecraft:glass
setblock ~-100 ~24 ~-92 minecraft:glass
setblock ~-100 ~24 ~-90 minecraft:glass
setblock ~-100 ~24 ~-88 minecraft:glass
setblock ~-100 ~24 ~-86 minecraft:glass
setblock ~-100 ~24 ~-84 minecraft:glass
setblock ~-100 ~24 ~-82 minecraft:glass
setblock ~-100 ~26 ~-112 minecraft:glass
setblock ~-100 ~26 ~-110 minecraft:glass
setblock ~-100 ~26 ~-108 minecraft:glass
setblock ~-100 ~26 ~-106 minecraft:glass
setblock ~-100 ~26 ~-104 minecraft:glass
setblock ~-100 ~26 ~-102 minecraft:glass
setblock ~-100 ~26 ~-100 minecraft:glass
setblock ~-100 ~26 ~-98 minecraft:glass
setblock ~-100 ~26 ~-96 minecraft:glass
setblock ~-100 ~26 ~-94 minecraft:glass
setblock ~-100 ~26 ~-92 minecraft:glass
setblock ~-100 ~26 ~-90 minecraft:glass
setblock ~-100 ~26 ~-88 minecraft:glass
setblock ~-100 ~26 ~-86 minecraft:glass
setblock ~-100 ~26 ~-84 minecraft:glass
setblock ~-100 ~26 ~-82 minecraft:glass
setblock ~-100 ~28 ~-112 minecraft:glass
setblock ~-100 ~28 ~-110 minecraft:glass
setblock ~-100 ~28 ~-108 minecraft:glass
setblock ~-100 ~28 ~-106 minecraft:glass
setblock ~-100 ~28 ~-104 minecraft:glass
setblock ~-100 ~28 ~-102 minecraft:glass
setblock ~-100 ~28 ~-100 minecraft:glass
setblock ~-100 ~28 ~-98 minecraft:glass
setblock ~-100 ~28 ~-96 minecraft:glass
setblock ~-100 ~28 ~-94 minecraft:glass
setblock ~-100 ~28 ~-92 minecraft:glass
setblock ~-100 ~28 ~-90 minecraft:glass
setblock ~-100 ~28 ~-88 minecraft:glass
setblock ~-100 ~28 ~-86 minecraft:glass
setblock ~-100 ~28 ~-84 minecraft:glass
setblock ~-100 ~28 ~-82 minecraft:glass
setblock ~-100 ~30 ~-112 minecraft:glass
setblock ~-100 ~30 ~-110 minecraft:glass
setblock ~-100 ~30 ~-108 minecraft:glass
setblock ~-100 ~30 ~-106 minecraft:glass
setblock ~-100 ~30 ~-104 minecraft:glass
setblock ~-100 ~30 ~-102 minecraft:glass
setblock ~-100 ~30 ~-100 minecraft:glass
setblock ~-100 ~30 ~-98 minecraft:glass
setblock ~-100 ~30 ~-96 minecraft:glass
setblock ~-100 ~30 ~-94 minecraft:glass
setblock ~-100 ~30 ~-92 minecraft:glass
setblock ~-100 ~30 ~-90 minecraft:glass
setblock ~-100 ~30 ~-88 minecraft:glass
setblock ~-100 ~30 ~-86 minecraft:glass
setblock ~-100 ~30 ~-84 minecraft:glass
setblock ~-100 ~30 ~-82 minecraft:glass
setblock ~-98 ~0 ~-112 minecraft:glass
setblock ~-98 ~0 ~-110 minecraft:glass
setblock ~-98 ~0 ~-108 minecraft:glass
setblock ~-98 ~0 ~-106 minecraft:glass
setblock ~-98 ~0 ~-104 minecraft:glass
setblock ~-98 ~0 ~-102 minecraft:glass
setblock ~-98 ~0 ~-100 minecraft:glass
setblock ~-98 ~0 ~-98 minecraft:glass
setblock ~-98 ~0 ~-96 minecraft:glass
setblock ~-98 ~0 ~-94 minecraft:glass
setblock ~-98 ~0 ~-92 minecraft:glass
setblock ~-98 ~0 ~-90 minecraft:glass
setblock ~-98 ~0 ~-88 minecraft:glass
setblock ~-98 ~0 ~-86 minecraft:glass
setblock ~-98 ~0 ~-84 minecraft:glass
setblock ~-98 ~0 ~-82 minecraft:glass
setblock ~-98 ~2 ~-112 minecraft:glass
setblock ~-98 ~2 ~-110 minecraft:glass
setblock ~-98 ~2 ~-108 minecraft:glass
setblock ~-98 ~2 ~-106 minecraft:glass
setblock ~-98 ~2 ~-104 minecraft:glass
setblock ~-98 ~2 ~-102 minecraft:glass
setblock ~-98 ~2 ~-100 minecraft:glass
setblock ~-98 ~2 ~-98 minecraft:glass
setblock ~-98 ~2 ~-96 minecraft:glass
setblock ~-98 ~2 ~-94 minecraft:glass
setblock ~-98 ~2 ~-92 minecraft:glass
setblock ~-98 ~2 ~-90 minecraft:glass
setblock ~-98 ~2 ~-88 minecraft:glass
setblock ~-98 ~2 ~-86 minecraft:glass
setblock ~-98 ~2 ~-84 minecraft:glass
setblock ~-98 ~2 ~-82 minecraft:glass
setblock ~-98 ~4 ~-112 minecraft:glass
setblock ~-98 ~4 ~-110 minecraft:glass
setblock ~-98 ~4 ~-108 minecraft:glass
setblock ~-98 ~4 ~-106 minecraft:glass
setblock ~-98 ~4 ~-104 minecraft:glass
setblock ~-98 ~4 ~-102 minecraft:glass
setblock ~-98 ~4 ~-100 minecraft:glass
setblock ~-98 ~4 ~-98 minecraft:glass
setblock ~-98 ~4 ~-96 minecraft:glass
setblock ~-98 ~4 ~-94 minecraft:glass
setblock ~-98 ~4 ~-92 minecraft:glass
setblock ~-98 ~4 ~-90 minecraft:glass
setblock ~-98 ~4 ~-88 minecraft:glass
setblock ~-98 ~4 ~-86 minecraft:glass
setblock ~-98 ~4 ~-84 minecraft:glass
setblock ~-98 ~4 ~-82 minecraft:glass
setblock ~-98 ~6 ~-112 minecraft:glass
setblock ~-98 ~6 ~-110 minecraft:glass
setblock ~-98 ~6 ~-108 minecraft:glass
setblock ~-98 ~6 ~-106 minecraft:glass
setblock ~-98 ~6 ~-104 minecraft:glass
setblock ~-98 ~6 ~-102 minecraft:glass
setblock ~-98 ~6 ~-100 minecraft:glass
setblock ~-98 ~6 ~-98 minecraft:glass
setblock ~-98 ~6 ~-96 minecraft:glass
setblock ~-98 ~6 ~-94 minecraft:glass
setblock ~-98 ~6 ~-92 minecraft:glass
setblock ~-98 ~6 ~-90 minecraft:glass
setblock ~-98 ~6 ~-88 minecraft:glass
setblock ~-98 ~6 ~-86 minecraft:glass
setblock ~-98 ~6 ~-84 minecraft:glass
setblock ~-98 ~6 ~-82 minecraft:glass
setblock ~-98 ~8 ~-112 minecraft:glass
setblock ~-98 ~8 ~-110 minecraft:glass
setblock ~-98 ~8 ~-108 minecraft:glass
setblock ~-98 ~8 ~-106 minecraft:glass
setblock ~-98 ~8 ~-104 minecraft:glass
setblock ~-98 ~8 ~-102 minecraft:glass
setblock ~-98 ~8 ~-100 minecraft:glass
setblock ~-98 ~8 ~-98 minecraft:glass
setblock ~-98 ~8 ~-96 minecraft:glass
setblock ~-98 ~8 ~-94 minecraft:glass
setblock ~-98 ~8 ~-92 minecraft:glass
setblock ~-98 ~8 ~-90 minecraft:glass
setblock ~-98 ~8 ~-88 minecraft:glass
setblock ~-98 ~8 ~-86 minecraft:glass
setblock ~-98 ~8 ~-84 minecraft:glass
setblock ~-98 ~8 ~-82 minecraft:glass
setblock ~-98 ~10 ~-112 minecraft:glass
setblock ~-98 ~10 ~-110 minecraft:glass
setblock ~-98 ~10 ~-108 minecraft:glass
setblock ~-98 ~10 ~-106 minecraft:glass
setblock ~-98 ~10 ~-104 minecraft:glass
setblock ~-98 ~10 ~-102 minecraft:glass
setblock ~-98 ~10 ~-100 minecraft:glass
setblock ~-98 ~10 ~-98 minecraft:glass
setblock ~-98 ~10 ~-96 minecraft:glass
setblock ~-98 ~10 ~-94 minecraft:glass
setblock ~-98 ~10 ~-92 minecraft:glass
setblock ~-98 ~10 ~-90 minecraft:glass
setblock ~-98 ~10 ~-88 minecraft:glass
setblock ~-98 ~10 ~-86 minecraft:glass
setblock ~-98 ~10 ~-84 minecraft:glass
setblock ~-98 ~10 ~-82 minecraft:glass
setblock ~-98 ~12 ~-112 minecraft:glass
setblock ~-98 ~12 ~-110 minecraft:glass
setblock ~-98 ~12 ~-108 minecraft:glass
setblock ~-98 ~12 ~-106 minecraft:glass
setblock ~-98 ~12 ~-104 minecraft:glass
setblock ~-98 ~12 ~-102 minecraft:glass
setblock ~-98 ~12 ~-100 minecraft:glass
setblock ~-98 ~12 ~-98 minecraft:glass
setblock ~-98 ~12 ~-96 minecraft:glass
setblock ~-98 ~12 ~-94 minecraft:glass
setblock ~-98 ~12 ~-92 minecraft:glass
setblock ~-98 ~12 ~-90 minecraft:glass
setblock ~-98 ~12 ~-88 minecraft:glass
setblock ~-98 ~12 ~-86 minecraft:glass
setblock ~-98 ~12 ~-84 minecraft:glass
setblock ~-98 ~12 ~-82 minecraft:glass
setblock ~-98 ~14 ~-112 minecraft:glass
setblock ~-98 ~14 ~-110 minecraft:glass
setblock ~-98 ~14 ~-108 minecraft:glass
setblock ~-98 ~14 ~-106 minecraft:glass
setblock ~-98 ~14 ~-104 minecraft:glass
setblock ~-98 ~14 ~-102 minecraft:glass
setblock ~-98 ~14 ~-100 minecraft:glass
setblock ~-98 ~14 ~-98 minecraft:glass
setblock ~-98 ~14 ~-96 minecraft:glass
setblock ~-98 ~14 ~-94 minecraft:glass
setblock ~-98 ~14 ~-92 minecraft:glass
setblock ~-98 ~14 ~-90 minecraft:glass
setblock ~-98 ~14 ~-88 minecraft:glass
setblock ~-98 ~14 ~-86 minecraft:glass
setblock ~-98 ~14 ~-84 minecraft:glass
setblock ~-98 ~14 ~-82 minecraft:glass
setblock ~-98 ~16 ~-112 minecraft:glass
setblock ~-98 ~16 ~-110 minecraft:glass
setblock ~-98 ~16 ~-108 minecraft:glass
setblock ~-98 ~16 ~-106 minecraft:glass
setblock ~-98 ~16 ~-104 minecraft:glass
setblock ~-98 ~16 ~-102 minecraft:glass
setblock ~-98 ~16 ~-100 minecraft:glass
setblock ~-98 ~16 ~-98 minecraft:glass
setblock ~-98 ~16 ~-96 minecraft:glass
setblock ~-98 ~16 ~-94 minecraft:glass
setblock ~-98 ~16 ~-92 minecraft:glass
setblock ~-98 ~16 ~-90 minecraft:glass
setblock ~-98 ~16 ~-88 minecraft:glass
setblock ~-98 ~16 ~-86 minecraft:glass
setblock ~-98 ~16 ~-84 minecraft:glass
setblock ~-98 ~16 ~-82 minecraft:glass
setblock ~-98 ~18 ~-112 minecraft:glass
setblock ~-98 ~18 ~-110 minecraft:glass
setblock ~-98 ~18 ~-108 minecraft:glass
setblock ~-98 ~18 ~-106 minecraft:glass
setblock ~-98 ~18 ~-104 minecraft:glass
setblock ~-98 ~18 ~-102 minecraft:glass
setblock ~-98 ~18 ~-100 minecraft:glass
setblock ~-98 ~18 ~-98 minecraft:glass
setblock ~-98 ~18 ~-96 minecraft:glass
setblock ~-98 ~18 ~-94 minecraft:glass
setblock ~-98 ~18 ~-92 minecraft:glass
setblock ~-98 ~18 ~-90 minecraft:glass
setblock ~-98 ~18 ~-88 minecraft:glass
setblock ~-98 ~18 ~-86 minecraft:glass
setblock ~-98 ~18 ~-84 minecraft:glass
setblock ~-98 ~18 ~-82 minecraft:glass
setblock ~-98 ~20 ~-112 minecraft:glass
setblock ~-98 ~20 ~-110 minecraft:glass
setblock ~-98 ~20 ~-108 minecraft:glass
setblock ~-98 ~20 ~-106 minecraft:glass
setblock ~-98 ~20 ~-104 minecraft:glass
setblock ~-98 ~20 ~-102 minecraft:glass
setblock ~-98 ~20 ~-100 minecraft:glass
setblock ~-98 ~20 ~-98 minecraft:glass
setblock ~-98 ~20 ~-96 minecraft:glass
setblock ~-98 ~20 ~-94 minecraft:glass
setblock ~-98 ~20 ~-92 minecraft:glass
setblock ~-98 ~20 ~-90 minecraft:glass
setblock ~-98 ~20 ~-88 minecraft:glass
setblock ~-98 ~20 ~-86 minecraft:glass
setblock ~-98 ~20 ~-84 minecraft:glass
setblock ~-98 ~20 ~-82 minecraft:glass
setblock ~-98 ~22 ~-112 minecraft:glass
setblock ~-98 ~22 ~-110 minecraft:glass
setblock ~-98 ~22 ~-108 minecraft:glass
setblock ~-98 ~22 ~-106 minecraft:glass
setblock ~-98 ~22 ~-104 minecraft:glass
setblock ~-98 ~22 ~-102 minecraft:glass
setblock ~-98 ~22 ~-100 minecraft:glass
setblock ~-98 ~22 ~-98 minecraft:glass
setblock ~-98 ~22 ~-96 minecraft:glass
setblock ~-98 ~22 ~-94 minecraft:glass
setblock ~-98 ~22 ~-92 minecraft:glass
setblock ~-98 ~22 ~-90 minecraft:glass
setblock ~-98 ~22 ~-88 minecraft:glass
setblock ~-98 ~22 ~-86 minecraft:glass
setblock ~-98 ~22 ~-84 minecraft:glass
setblock ~-98 ~22 ~-82 minecraft:glass
setblock ~-98 ~24 ~-112 minecraft:glass
setblock ~-98 ~24 ~-110 minecraft:glass
setblock ~-98 ~24 ~-108 minecraft:glass
setblock ~-98 ~24 ~-106 minecraft:glass
setblock ~-98 ~24 ~-104 minecraft:glass
setblock ~-98 ~24 ~-102 minecraft:glass
setblock ~-98 ~24 ~-100 minecraft:glass
setblock ~-98 ~24 ~-98 minecraft:glass
setblock ~-98 ~24 ~-96 minecraft:glass
setblock ~-98 ~24 ~-94 minecraft:glass
setblock ~-98 ~24 ~-92 minecraft:glass
setblock ~-98 ~24 ~-90 minecraft:glass
setblock ~-98 ~24 ~-88 minecraft:glass
setblock ~-98 ~24 ~-86 minecraft:glass
setblock ~-98 ~24 ~-84 minecraft:glass
setblock ~-98 ~24 ~-82 minecraft:glass
setblock ~-98 ~26 ~-112 minecraft:glass
setblock ~-98 ~26 ~-110 minecraft:glass
setblock ~-98 ~26 ~-108 minecraft:glass
setblock ~-98 ~26 ~-106 minecraft:glass
setblock ~-98 ~26 ~-104 minecraft:glass
setblock ~-98 ~26 ~-102 minecraft:glass
setblock ~-98 ~26 ~-100 minecraft:glass
setblock ~-98 ~26 ~-98 minecraft:glass
setblock ~-98 ~26 ~-96 minecraft:glass
setblock ~-98 ~26 ~-94 minecraft:glass
setblock ~-98 ~26 ~-92 minecraft:glass
setblock ~-98 ~26 ~-90 minecraft:glass
setblock ~-98 ~26 ~-88 minecraft:glass
setblock ~-98 ~26 ~-86 minecraft:glass
setblock ~-98 ~26 ~-84 minecraft:glass
setblock ~-98 ~26 ~-82 minecraft:glass
setblock ~-98 ~28 ~-112 minecraft:glass
setblock ~-98 ~28 ~-110 minecraft:glass
setblock ~-98 ~28 ~-108 minecraft:glass
setblock ~-98 ~28 ~-106 minecraft:glass
setblock ~-98 ~28 ~-104 minecraft:glass
setblock ~-98 ~28 ~-102 minecraft:glass
setblock ~-98 ~28 ~-100 minecraft:glass
setblock ~-98 ~28 ~-98 minecraft:glass
setblock ~-98 ~28 ~-96 minecraft:glass
setblock ~-98 ~28 ~-94 minecraft:glass
setblock ~-98 ~28 ~-92 minecraft:glass
setblock ~-98 ~28 ~-90 minecraft:glass
setblock ~-98 ~28 ~-88 minecraft:glass
setblock ~-98 ~28 ~-86 minecraft:glass
setblock ~-98 ~28 ~-84 minecraft:glass
setblock ~-98 ~28 ~-82 minecraft:glass
setblock ~-98 ~30 ~-112 minecraft:glass
setblock ~-98 ~30 ~-110 minecraft:glass
setblock ~-98 ~30 ~-108 minecraft:glass
setblock ~-98 ~30 ~-106 minecraft:glass
setblock ~-98 ~30 ~-104 minecraft:glass
setblock ~-98 ~30 ~-102 minecraft:glass
setblock ~-98 ~30 ~-100 minecraft:glass
setblock ~-98 ~30 ~-98 minecraft:glass
setblock ~-98 ~30 ~-96 minecraft:glass
setblock ~-98 ~30 ~-94 minecraft:glass
setblock ~-98 ~30 ~-92 minecraft:glass
setblock ~-98 ~30 ~-90 minecraft:glass
setblock ~-98 ~30 ~-88 minecraft:glass
setblock ~-98 ~30 ~-86 minecraft:glass
setblock ~-98 ~30 ~-84 minecraft:glass
setblock ~-98 ~30 ~-82 minecraft:glass
setblock ~-96 ~0 ~-112 minecraft:glass
setblock ~-96 ~0 ~-110 minecraft:glass
setblock ~-96 ~0 ~-108 minecraft:glass
setblock ~-96 ~0 ~-106 minecraft:glass
setblock ~-96 ~0 ~-104 minecraft:glass
setblock ~-96 ~0 ~-102 minecraft:glass
setblock ~-96 ~0 ~-100 minecraft:glass
setblock ~-96 ~0 ~-98 minecraft:glass
setblock ~-96 ~0 ~-96 minecraft:glass
setblock ~-96 ~0 ~-94 minecraft:glass
setblock ~-96 ~0 ~-92 minecraft:glass
setblock ~-96 ~0 ~-90 minecraft:glass
setblock ~-96 ~0 ~-88 minecraft:glass
setblock ~-96 ~0 ~-86 minecraft:glass
setblock ~-96 ~0 ~-84 minecraft:glass
setblock ~-96 ~0 ~-82 minecraft:glass
setblock ~-96 ~2 ~-112 minecraft:glass
setblock ~-96 ~2 ~-110 minecraft:glass
setblock ~-96 ~2 ~-108 minecraft:glass
setblock ~-96 ~2 ~-106 minecraft:glass
setblock ~-96 ~2 ~-104 minecraft:glass
setblock ~-96 ~2 ~-102 minecraft:glass
setblock ~-96 ~2 ~-100 minecraft:glass
setblock ~-96 ~2 ~-98 minecraft:glass
setblock ~-96 ~2 ~-96 minecraft:glass
setblock ~-96 ~2 ~-94 minecraft:glass
setblock ~-96 ~2 ~-92 minecraft:glass
setblock ~-96 ~2 ~-90 minecraft:glass
setblock ~-96 ~2 ~-88 minecraft:glass
setblock ~-96 ~2 ~-86 minecraft:glass
setblock ~-96 ~2 ~-84 minecraft:glass
setblock ~-96 ~2 ~-82 minecraft:glass
setblock ~-96 ~4 ~-112 minecraft:glass
setblock ~-96 ~4 ~-110 minecraft:glass
setblock ~-96 ~4 ~-108 minecraft:glass
setblock ~-96 ~4 ~-106 minecraft:glass
setblock ~-96 ~4 ~-104 minecraft:glass
setblock ~-96 ~4 ~-102 minecraft:glass
setblock ~-96 ~4 ~-100 minecraft:glass
setblock ~-96 ~4 ~-98 minecraft:glass
setblock ~-96 ~4 ~-96 minecraft:glass
setblock ~-96 ~4 ~-94 minecraft:glass
setblock ~-96 ~4 ~-92 minecraft:glass
setblock ~-96 ~4 ~-90 minecraft:glass
setblock ~-96 ~4 ~-88 minecraft:glass
setblock ~-96 ~4 ~-86 minecraft:glass
setblock ~-96 ~4 ~-84 minecraft:glass
setblock ~-96 ~4 ~-82 minecraft:glass
setblock ~-96 ~6 ~-112 minecraft:glass
setblock ~-96 ~6 ~-110 minecraft:glass
setblock ~-96 ~6 ~-108 minecraft:glass
setblock ~-96 ~6 ~-106 minecraft:glass
setblock ~-96 ~6 ~-104 minecraft:glass
setblock ~-96 ~6 ~-102 minecraft:glass
setblock ~-96 ~6 ~-100 minecraft:glass
setblock ~-96 ~6 ~-98 minecraft:glass
setblock ~-96 ~6 ~-96 minecraft:glass
setblock ~-96 ~6 ~-94 minecraft:glass
setblock ~-96 ~6 ~-92 minecraft:glass
setblock ~-96 ~6 ~-90 minecraft:glass
setblock ~-96 ~6 ~-88 minecraft:glass
setblock ~-96 ~6 ~-86 minecraft:glass
setblock ~-96 ~6 ~-84 minecraft:glass
setblock ~-96 ~6 ~-82 minecraft:glass
setblock ~-96 ~8 ~-112 minecraft:glass
setblock ~-96 ~8 ~-110 minecraft:glass
setblock ~-96 ~8 ~-108 minecraft:glass
setblock ~-96 ~8 ~-106 minecraft:glass
setblock ~-96 ~8 ~-104 minecraft:glass
setblock ~-96 ~8 ~-102 minecraft:glass
setblock ~-96 ~8 ~-100 minecraft:glass
setblock ~-96 ~8 ~-98 minecraft:glass
setblock ~-96 ~8 ~-96 minecraft:glass
setblock ~-96 ~8 ~-94 minecraft:glass
setblock ~-96 ~8 ~-92 minecraft:glass
setblock ~-96 ~8 ~-90 minecraft:glass
setblock ~-96 ~8 ~-88 minecraft:glass
setblock ~-96 ~8 ~-86 minecraft:glass
setblock ~-96 ~8 ~-84 minecraft:glass
setblock ~-96 ~8 ~-82 minecraft:glass
setblock ~-96 ~10 ~-112 minecraft:glass
setblock ~-96 ~10 ~-110 minecraft:glass
setblock ~-96 ~10 ~-108 minecraft:glass
setblock ~-96 ~10 ~-106 minecraft:glass
setblock ~-96 ~10 ~-104 minecraft:glass
setblock ~-96 ~10 ~-102 minecraft:glass
setblock ~-96 ~10 ~-100 minecraft:glass
setblock ~-96 ~10 ~-98 minecraft:glass
setblock ~-96 ~10 ~-96 minecraft:glass
setblock ~-96 ~10 ~-94 minecraft:glass
setblock ~-96 ~10 ~-92 minecraft:glass
setblock ~-96 ~10 ~-90 minecraft:glass
setblock ~-96 ~10 ~-88 minecraft:glass
setblock ~-96 ~10 ~-86 minecraft:glass
setblock ~-96 ~10 ~-84 minecraft:glass
setblock ~-96 ~10 ~-82 minecraft:glass
setblock ~-96 ~12 ~-112 minecraft:glass
setblock ~-96 ~12 ~-110 minecraft:glass
setblock ~-96 ~12 ~-108 minecraft:glass
setblock ~-96 ~12 ~-106 minecraft:glass
setblock ~-96 ~12 ~-104 minecraft:glass
setblock ~-96 ~12 ~-102 minecraft:glass
setblock ~-96 ~12 ~-100 minecraft:glass
setblock ~-96 ~12 ~-98 minecraft:glass
setblock ~-96 ~12 ~-96 minecraft:glass
setblock ~-96 ~12 ~-94 minecraft:glass
setblock ~-96 ~12 ~-92 minecraft:glass
setblock ~-96 ~12 ~-90 minecraft:glass
setblock ~-96 ~12 ~-88 minecraft:glass
setblock ~-96 ~12 ~-86 minecraft:glass
setblock ~-96 ~12 ~-84 minecraft:glass
setblock ~-96 ~12 ~-82 minecraft:glass
setblock ~-96 ~14 ~-112 minecraft:glass
setblock ~-96 ~14 ~-110 minecraft:glass
setblock ~-96 ~14 ~-108 minecraft:glass
setblock ~-96 ~14 ~-106 minecraft:glass
setblock ~-96 ~14 ~-104 minecraft:glass
setblock ~-96 ~14 ~-102 minecraft:glass
setblock ~-96 ~14 ~-100 minecraft:glass
setblock ~-96 ~14 ~-98 minecraft:glass
setblock ~-96 ~14 ~-96 minecraft:glass
setblock ~-96 ~14 ~-94 minecraft:glass
setblock ~-96 ~14 ~-92 minecraft:glass
setblock ~-96 ~14 ~-90 minecraft:glass
setblock ~-96 ~14 ~-88 minecraft:glass
setblock ~-96 ~14 ~-86 minecraft:glass
setblock ~-96 ~14 ~-84 minecraft:glass
setblock ~-96 ~14 ~-82 minecraft:glass
setblock ~-96 ~16 ~-112 minecraft:glass
setblock ~-96 ~16 ~-110 minecraft:glass
setblock ~-96 ~16 ~-108 minecraft:glass
setblock ~-96 ~16 ~-106 minecraft:glass
setblock ~-96 ~16 ~-104 minecraft:glass
setblock ~-96 ~16 ~-102 minecraft:glass
setblock ~-96 ~16 ~-100 minecraft:glass
setblock ~-96 ~16 ~-98 minecraft:glass
setblock ~-96 ~16 ~-96 minecraft:glass
setblock ~-96 ~16 ~-94 minecraft:glass
setblock ~-96 ~16 ~-92 minecraft:glass
setblock ~-96 ~16 ~-90 minecraft:glass
setblock ~-96 ~16 ~-88 minecraft:glass
setblock ~-96 ~16 ~-86 minecraft:glass
setblock ~-96 ~16 ~-84 minecraft:glass
setblock ~-96 ~16 ~-82 minecraft:glass
setblock ~-96 ~18 ~-112 minecraft:glass
setblock ~-96 ~18 ~-110 minecraft:glass
setblock ~-96 ~18 ~-108 minecraft:glass
setblock ~-96 ~18 ~-106 minecraft:glass
setblock ~-96 ~18 ~-104 minecraft:glass
setblock ~-96 ~18 ~-102 minecraft:glass
setblock ~-96 ~18 ~-100 minecraft:glass
setblock ~-96 ~18 ~-98 minecraft:glass
setblock ~-96 ~18 ~-96 minecraft:glass
setblock ~-96 ~18 ~-94 minecraft:glass
setblock ~-96 ~18 ~-92 minecraft:glass
setblock ~-96 ~18 ~-90 minecraft:glass
setblock ~-96 ~18 ~-88 minecraft:glass
setblock ~-96 ~18 ~-86 minecraft:glass
setblock ~-96 ~18 ~-84 minecraft:glass
setblock ~-96 ~18 ~-82 minecraft:glass
setblock ~-96 ~20 ~-112 minecraft:glass
setblock ~-96 ~20 ~-110 minecraft:glass
setblock ~-96 ~20 ~-108 minecraft:glass
setblock ~-96 ~20 ~-106 minecraft:glass
setblock ~-96 ~20 ~-104 minecraft:glass
setblock ~-96 ~20 ~-102 minecraft:glass
setblock ~-96 ~20 ~-100 minecraft:glass
setblock ~-96 ~20 ~-98 minecraft:glass
setblock ~-96 ~20 ~-96 minecraft:glass
setblock ~-96 ~20 ~-94 minecraft:glass
setblock ~-96 ~20 ~-92 minecraft:glass
setblock ~-96 ~20 ~-90 minecraft:glass
setblock ~-96 ~20 ~-88 minecraft:glass
setblock ~-96 ~20 ~-86 minecraft:glass
setblock ~-96 ~20 ~-84 minecraft:glass
setblock ~-96 ~20 ~-82 minecraft:glass
setblock ~-96 ~22 ~-112 minecraft:glass
setblock ~-96 ~22 ~-110 minecraft:glass
setblock ~-96 ~22 ~-108 minecraft:glass
setblock ~-96 ~22 ~-106 minecraft:glass
setblock ~-96 ~22 ~-104 minecraft:glass
setblock ~-96 ~22 ~-102 minecraft:glass
setblock ~-96 ~22 ~-100 minecraft:glass
setblock ~-96 ~22 ~-98 minecraft:glass
setblock ~-96 ~22 ~-96 minecraft:glass
setblock ~-96 ~22 ~-94 minecraft:glass
setblock ~-96 ~22 ~-92 minecraft:glass
setblock ~-96 ~22 ~-90 minecraft:glass
setblock ~-96 ~22 ~-88 minecraft:glass
setblock ~-96 ~22 ~-86 minecraft:glass
setblock ~-96 ~22 ~-84 minecraft:glass
setblock ~-96 ~22 ~-82 minecraft:glass
setblock ~-96 ~24 ~-112 minecraft:glass
setblock ~-96 ~24 ~-110 minecraft:glass
setblock ~-96 ~24 ~-108 minecraft:glass
setblock ~-96 ~24 ~-106 minecraft:glass
setblock ~-96 ~24 ~-104 minecraft:glass
setblock ~-96 ~24 ~-102 minecraft:glass
setblock ~-96 ~24 ~-100 minecraft:glass
setblock ~-96 ~24 ~-98 minecraft:glass
setblock ~-96 ~24 ~-96 minecraft:glass
setblock ~-96 ~24 ~-94 minecraft:glass
setblock ~-96 ~24 ~-92 minecraft:glass
setblock ~-96 ~24 ~-90 minecraft:glass
setblock ~-96 ~24 ~-88 minecraft:glass
setblock ~-96 ~24 ~-86 minecraft:glass
setblock ~-96 ~24 ~-84 minecraft:glass
setblock ~-96 ~24 ~-82 minecraft:glass
setblock ~-96 ~26 ~-112 minecraft:glass
setblock ~-96 ~26 ~-110 minecraft:glass
setblock ~-96 ~26 ~-108 minecraft:glass
setblock ~-96 ~26 ~-106 minecraft:glass
setblock ~-96 ~26 ~-104 minecraft:glass
setblock ~-96 ~26 ~-102 minecraft:glass
setblock ~-96 ~26 ~-100 minecraft:glass
setblock ~-96 ~26 ~-98 minecraft:glass
setblock ~-96 ~26 ~-96 minecraft:glass
setblock ~-96 ~26 ~-94 minecraft:glass
setblock ~-96 ~26 ~-92 minecraft:glass
setblock ~-96 ~26 ~-90 minecraft:glass
setblock ~-96 ~26 ~-88 minecraft:glass
setblock ~-96 ~26 ~-86 minecraft:glass
setblock ~-96 ~26 ~-84 minecraft:glass
setblock ~-96 ~26 ~-82 minecraft:glass
setblock ~-96 ~28 ~-112 minecraft:glass
setblock ~-96 ~28 ~-110 minecraft:glass
setblock ~-96 ~28 ~-108 minecraft:glass
setblock ~-96 ~28 ~-106 minecraft:glass
setblock ~-96 ~28 ~-104 minecraft:glass
setblock ~-96 ~28 ~-102 minecraft:glass
setblock ~-96 ~28 ~-100 minecraft:glass
setblock ~-96 ~28 ~-98 minecraft:glass
setblock ~-96 ~28 ~-96 minecraft:glass
setblock ~-96 ~28 ~-94 minecraft:glass
setblock ~-96 ~28 ~-92 minecraft:glass
setblock ~-96 ~28 ~-90 minecraft:glass
setblock ~-96 ~28 ~-88 minecraft:glass
setblock ~-96 ~28 ~-86 minecraft:glass
setblock ~-96 ~28 ~-84 minecraft:glass
setblock ~-96 ~28 ~-82 minecraft:glass
setblock ~-96 ~30 ~-112 minecraft:glass
setblock ~-96 ~30 ~-110 minecraft:glass
setblock ~-96 ~30 ~-108 minecraft:glass
setblock ~-96 ~30 ~-106 minecraft:glass
setblock ~-96 ~30 ~-104 minecraft:glass
setblock ~-96 ~30 ~-102 minecraft:glass
setblock ~-96 ~30 ~-100 minecraft:glass
setblock ~-96 ~30 ~-98 minecraft:glass
setblock ~-96 ~30 ~-96 minecraft:glass
setblock ~-96 ~30 ~-94 minecraft:glass
setblock ~-96 ~30 ~-92 minecraft:glass
setblock ~-96 ~30 ~-90 minecraft:glass
setblock ~-96 ~30 ~-88 minecraft:glass
setblock ~-96 ~30 ~-86 minecraft:glass
setblock ~-96 ~30 ~-84 minecraft:glass
setblock ~-96 ~30 ~-82 minecraft:glass
setblock ~-94 ~0 ~-112 minecraft:glass
setblock ~-94 ~0 ~-110 minecraft:glass
setblock ~-94 ~0 ~-108 minecraft:glass
setblock ~-94 ~0 ~-106 minecraft:glass
setblock ~-94 ~0 ~-104 minecraft:glass
setblock ~-94 ~0 ~-102 minecraft:glass
setblock ~-94 ~0 ~-100 minecraft:glass
setblock ~-94 ~0 ~-98 minecraft:glass
setblock ~-94 ~0 ~-96 minecraft:glass
setblock ~-94 ~0 ~-94 minecraft:glass
setblock ~-94 ~0 ~-92 minecraft:glass
setblock ~-94 ~0 ~-90 minecraft:glass
setblock ~-94 ~0 ~-88 minecraft:glass
setblock ~-94 ~0 ~-86 minecraft:glass
setblock ~-94 ~0 ~-84 minecraft:glass
setblock ~-94 ~0 ~-82 minecraft:glass
setblock ~-94 ~2 ~-112 minecraft:glass
setblock ~-94 ~2 ~-110 minecraft:glass
setblock ~-94 ~2 ~-108 minecraft:glass
setblock ~-94 ~2 ~-106 minecraft:glass
setblock ~-94 ~2 ~-104 minecraft:glass
setblock ~-94 ~2 ~-102 minecraft:glass
setblock ~-94 ~2 ~-100 minecraft:glass
setblock ~-94 ~2 ~-98 minecraft:glass
setblock ~-94 ~2 ~-96 minecraft:glass
setblock ~-94 ~2 ~-94 minecraft:glass
setblock ~-94 ~2 ~-92 minecraft:glass
setblock ~-94 ~2 ~-90 minecraft:glass
setblock ~-94 ~2 ~-88 minecraft:glass
setblock ~-94 ~2 ~-86 minecraft:glass
setblock ~-94 ~2 ~-84 minecraft:glass
setblock ~-94 ~2 ~-82 minecraft:glass
setblock ~-94 ~4 ~-112 minecraft:glass
setblock ~-94 ~4 ~-110 minecraft:glass
setblock ~-94 ~4 ~-108 minecraft:glass
setblock ~-94 ~4 ~-106 minecraft:glass
setblock ~-94 ~4 ~-104 minecraft:glass
setblock ~-94 ~4 ~-102 minecraft:glass
setblock ~-94 ~4 ~-100 minecraft:glass
setblock ~-94 ~4 ~-98 minecraft:glass
setblock ~-94 ~4 ~-96 minecraft:glass
setblock ~-94 ~4 ~-94 minecraft:glass
setblock ~-94 ~4 ~-92 minecraft:glass
setblock ~-94 ~4 ~-90 minecraft:glass
setblock ~-94 ~4 ~-88 minecraft:glass
setblock ~-94 ~4 ~-86 minecraft:glass
setblock ~-94 ~4 ~-84 minecraft:glass
setblock ~-94 ~4 ~-82 minecraft:glass
setblock ~-94 ~6 ~-112 minecraft:glass
setblock ~-94 ~6 ~-110 minecraft:glass
setblock ~-94 ~6 ~-108 minecraft:glass
setblock ~-94 ~6 ~-106 minecraft:glass
setblock ~-94 ~6 ~-104 minecraft:glass
setblock ~-94 ~6 ~-102 minecraft:glass
setblock ~-94 ~6 ~-100 minecraft:glass
setblock ~-94 ~6 ~-98 minecraft:glass
setblock ~-94 ~6 ~-96 minecraft:glass
setblock ~-94 ~6 ~-94 minecraft:glass
setblock ~-94 ~6 ~-92 minecraft:glass
setblock ~-94 ~6 ~-90 minecraft:glass
setblock ~-94 ~6 ~-88 minecraft:glass
setblock ~-94 ~6 ~-86 minecraft:glass
setblock ~-94 ~6 ~-84 minecraft:glass
setblock ~-94 ~6 ~-82 minecraft:glass
setblock ~-94 ~8 ~-112 minecraft:glass
setblock ~-94 ~8 ~-110 minecraft:glass
setblock ~-94 ~8 ~-108 minecraft:glass
setblock ~-94 ~8 ~-106 minecraft:glass
setblock ~-94 ~8 ~-104 minecraft:glass
setblock ~-94 ~8 ~-102 minecraft:glass
setblock ~-94 ~8 ~-100 minecraft:glass
setblock ~-94 ~8 ~-98 minecraft:glass
setblock ~-94 ~8 ~-96 minecraft:glass
setblock ~-94 ~8 ~-94 minecraft:glass
setblock ~-94 ~8 ~-92 minecraft:glass
setblock ~-94 ~8 ~-90 minecraft:glass
setblock ~-94 ~8 ~-88 minecraft:glass
setblock ~-94 ~8 ~-86 minecraft:glass
setblock ~-94 ~8 ~-84 minecraft:glass
setblock ~-94 ~8 ~-82 minecraft:glass
setblock ~-94 ~10 ~-112 minecraft:glass
setblock ~-94 ~10 ~-110 minecraft:glass
setblock ~-94 ~10 ~-108 minecraft:glass
setblock ~-94 ~10 ~-106 minecraft:glass
setblock ~-94 ~10 ~-104 minecraft:glass
setblock ~-94 ~10 ~-102 minecraft:glass
setblock ~-94 ~10 ~-100 minecraft:glass
setblock ~-94 ~10 ~-98 minecraft:glass
setblock ~-94 ~10 ~-96 minecraft:glass
setblock ~-94 ~10 ~-94 minecraft:glass
setblock ~-94 ~10 ~-92 minecraft:glass
setblock ~-94 ~10 ~-90 minecraft:glass
setblock ~-94 ~10 ~-88 minecraft:glass
setblock ~-94 ~10 ~-86 minecraft:glass
setblock ~-94 ~10 ~-84 minecraft:glass
setblock ~-94 ~10 ~-82 minecraft:glass
setblock ~-94 ~12 ~-112 minecraft:glass
setblock ~-94 ~12 ~-110 minecraft:glass
setblock ~-94 ~12 ~-108 minecraft:glass
setblock ~-94 ~12 ~-106 minecraft:glass
setblock ~-94 ~12 ~-104 minecraft:glass
setblock ~-94 ~12 ~-102 minecraft:glass
setblock ~-94 ~12 ~-100 minecraft:glass
setblock ~-94 ~12 ~-98 minecraft:glass
setblock ~-94 ~12 ~-96 minecraft:glass
setblock ~-94 ~12 ~-94 minecraft:glass
setblock ~-94 ~12 ~-92 minecraft:glass
setblock ~-94 ~12 ~-90 minecraft:glass
setblock ~-94 ~12 ~-88 minecraft:glass
setblock ~-94 ~12 ~-86 minecraft:glass
setblock ~-94 ~12 ~-84 minecraft:glass
setblock ~-94 ~12 ~-82 minecraft:glass
setblock ~-94 ~14 ~-112 minecraft:glass
setblock ~-94 ~14 ~-110 minecraft:glass
setblock ~-94 ~14 ~-108 minecraft:glass
setblock ~-94 ~14 ~-106 minecraft:glass
setblock ~-94 ~14 ~-104 minecraft:glass
setblock ~-94 ~14 ~-102 minecraft:glass
setblock ~-94 ~14 ~-100 minecraft:glass
setblock ~-94 ~14 ~-98 minecraft:glass
setblock ~-94 ~14 ~-96 minecraft:glass
setblock ~-94 ~14 ~-94 minecraft:glass
setblock ~-94 ~14 ~-92 minecraft:glass
setblock ~-94 ~14 ~-90 minecraft:glass
setblock ~-94 ~14 ~-88 minecraft:glass
setblock ~-94 ~14 ~-86 minecraft:glass
setblock ~-94 ~14 ~-84 minecraft:glass
setblock ~-94 ~14 ~-82 minecraft:glass
setblock ~-94 ~16 ~-112 minecraft:glass
setblock ~-94 ~16 ~-110 minecraft:glass
setblock ~-94 ~16 ~-108 minecraft:glass
setblock ~-94 ~16 ~-106 minecraft:glass
setblock ~-94 ~16 ~-104 minecraft:glass
setblock ~-94 ~16 ~-102 minecraft:glass
setblock ~-94 ~16 ~-100 minecraft:glass
setblock ~-94 ~16 ~-98 minecraft:glass
setblock ~-94 ~16 ~-96 minecraft:glass
setblock ~-94 ~16 ~-94 minecraft:glass
setblock ~-94 ~16 ~-92 minecraft:glass
setblock ~-94 ~16 ~-90 minecraft:glass
setblock ~-94 ~16 ~-88 minecraft:glass
setblock ~-94 ~16 ~-86 minecraft:glass
setblock ~-94 ~16 ~-84 minecraft:glass
setblock ~-94 ~16 ~-82 minecraft:glass
setblock ~-94 ~18 ~-112 minecraft:glass
setblock ~-94 ~18 ~-110 minecraft:glass
setblock ~-94 ~18 ~-108 minecraft:glass
setblock ~-94 ~18 ~-106 minecraft:glass
setblock ~-94 ~18 ~-104 minecraft:glass
setblock ~-94 ~18 ~-102 minecraft:glass
setblock ~-94 ~18 ~-100 minecraft:glass
setblock ~-94 ~18 ~-98 minecraft:glass
setblock ~-94 ~18 ~-96 minecraft:glass
setblock ~-94 ~18 ~-94 minecraft:glass
setblock ~-94 ~18 ~-92 minecraft:glass
setblock ~-94 ~18 ~-90 minecraft:glass
setblock ~-94 ~18 ~-88 minecraft:glass
setblock ~-94 ~18 ~-86 minecraft:glass
setblock ~-94 ~18 ~-84 minecraft:glass
setblock ~-94 ~18 ~-82 minecraft:glass
setblock ~-94 ~20 ~-112 minecraft:glass
setblock ~-94 ~20 ~-110 minecraft:glass
setblock ~-94 ~20 ~-108 minecraft:glass
setblock ~-94 ~20 ~-106 minecraft:glass
setblock ~-94 ~20 ~-104 minecraft:glass
setblock ~-94 ~20 ~-102 minecraft:glass
setblock ~-94 ~20 ~-100 minecraft:glass
setblock ~-94 ~20 ~-98 minecraft:glass
setblock ~-94 ~20 ~-96 minecraft:glass
setblock ~-94 ~20 ~-94 minecraft:glass
setblock ~-94 ~20 ~-92 minecraft:glass
setblock ~-94 ~20 ~-90 minecraft:glass
setblock ~-94 ~20 ~-88 minecraft:glass
setblock ~-94 ~20 ~-86 minecraft:glass
setblock ~-94 ~20 ~-84 minecraft:glass
setblock ~-94 ~20 ~-82 minecraft:glass
setblock ~-94 ~22 ~-112 minecraft:glass
setblock ~-94 ~22 ~-110 minecraft:glass
setblock ~-94 ~22 ~-108 minecraft:glass
setblock ~-94 ~22 ~-106 minecraft:glass
setblock ~-94 ~22 ~-104 minecraft:glass
setblock ~-94 ~22 ~-102 minecraft:glass
setblock ~-94 ~22 ~-100 minecraft:glass
setblock ~-94 ~22 ~-98 minecraft:glass
setblock ~-94 ~22 ~-96 minecraft:glass
setblock ~-94 ~22 ~-94 minecraft:glass
setblock ~-94 ~22 ~-92 minecraft:glass
setblock ~-94 ~22 ~-90 minecraft:glass
setblock ~-94 ~22 ~-88 minecraft:glass
setblock ~-94 ~22 ~-86 minecraft:glass
setblock ~-94 ~22 ~-84 minecraft:glass
setblock ~-94 ~22 ~-82 minecraft:glass
setblock ~-94 ~24 ~-112 minecraft:glass
setblock ~-94 ~24 ~-110 minecraft:glass
setblock ~-94 ~24 ~-108 minecraft:glass
setblock ~-94 ~24 ~-106 minecraft:glass
setblock ~-94 ~24 ~-104 minecraft:glass
setblock ~-94 ~24 ~-102 minecraft:glass
setblock ~-94 ~24 ~-100 minecraft:glass
setblock ~-94 ~24 ~-98 minecraft:glass
setblock ~-94 ~24 ~-96 minecraft:glass
setblock ~-94 ~24 ~-94 minecraft:glass
setblock ~-94 ~24 ~-92 minecraft:glass
setblock ~-94 ~24 ~-90 minecraft:glass
setblock ~-94 ~24 ~-88 minecraft:glass
setblock ~-94 ~24 ~-86 minecraft:glass
setblock ~-94 ~24 ~-84 minecraft:glass
setblock ~-94 ~24 ~-82 minecraft:glass
setblock ~-94 ~26 ~-112 minecraft:glass
setblock ~-94 ~26 ~-110 minecraft:glass
setblock ~-94 ~26 ~-108 minecraft:glass
setblock ~-94 ~26 ~-106 minecraft:glass
setblock ~-94 ~26 ~-104 minecraft:glass
setblock ~-94 ~26 ~-102 minecraft:glass
setblock ~-94 ~26 ~-100 minecraft:glass
setblock ~-94 ~26 ~-98 minecraft:glass
setblock ~-94 ~26 ~-96 minecraft:glass
setblock ~-94 ~26 ~-94 minecraft:glass
setblock ~-94 ~26 ~-92 minecraft:glass
setblock ~-94 ~26 ~-90 minecraft:glass
setblock ~-94 ~26 ~-88 minecraft:glass
setblock ~-94 ~26 ~-86 minecraft:glass
setblock ~-94 ~26 ~-84 minecraft:glass
setblock ~-94 ~26 ~-82 minecraft:glass
setblock ~-94 ~28 ~-112 minecraft:glass
setblock ~-94 ~28 ~-110 minecraft:glass
setblock ~-94 ~28 ~-108 minecraft:glass
setblock ~-94 ~28 ~-106 minecraft:glass
setblock ~-94 ~28 ~-104 minecraft:glass
setblock ~-94 ~28 ~-102 minecraft:glass
setblock ~-94 ~28 ~-100 minecraft:glass
setblock ~-94 ~28 ~-98 minecraft:glass
setblock ~-94 ~28 ~-96 minecraft:glass
setblock ~-94 ~28 ~-94 minecraft:glass
setblock ~-94 ~28 ~-92 minecraft:glass
setblock ~-94 ~28 ~-90 minecraft:glass
setblock ~-94 ~28 ~-88 minecraft:glass
setblock ~-94 ~28 ~-86 minecraft:glass
setblock ~-94 ~28 ~-84 minecraft:glass
setblock ~-94 ~28 ~-82 minecraft:glass
setblock ~-94 ~30 ~-112 minecraft:glass
setblock ~-94 ~30 ~-110 minecraft:glass
setblock ~-94 ~30 ~-108 minecraft:glass
setblock ~-94 ~30 ~-106 minecraft:glass
setblock ~-94 ~30 ~-104 minecraft:glass
setblock ~-94 ~30 ~-102 minecraft:glass
setblock ~-94 ~30 ~-100 minecraft:glass
setblock ~-94 ~30 ~-98 minecraft:glass
setblock ~-94 ~30 ~-96 minecraft:glass
setblock ~-94 ~30 ~-94 minecraft:glass
setblock ~-94 ~30 ~-92 minecraft:glass
setblock ~-94 ~30 ~-90 minecraft:glass
setblock ~-94 ~30 ~-88 minecraft:glass
setblock ~-94 ~30 ~-86 minecraft:glass
setblock ~-94 ~30 ~-84 minecraft:glass
setblock ~-94 ~30 ~-82 minecraft:glass
setblock ~-92 ~0 ~-112 minecraft:glass
setblock ~-92 ~0 ~-110 minecraft:glass
setblock ~-92 ~0 ~-108 minecraft:glass
setblock ~-92 ~0 ~-106 minecraft:glass
setblock ~-92 ~0 ~-104 minecraft:glass
setblock ~-92 ~0 ~-102 minecraft:glass
setblock ~-92 ~0 ~-100 minecraft:glass
setblock ~-92 ~0 ~-98 minecraft:glass
setblock ~-92 ~0 ~-96 minecraft:glass
setblock ~-92 ~0 ~-94 minecraft:glass
setblock ~-92 ~0 ~-92 minecraft:glass
setblock ~-92 ~0 ~-90 minecraft:glass
setblock ~-92 ~0 ~-88 minecraft:glass
setblock ~-92 ~0 ~-86 minecraft:glass
setblock ~-92 ~0 ~-84 minecraft:glass
setblock ~-92 ~0 ~-82 minecraft:glass
setblock ~-92 ~2 ~-112 minecraft:glass
setblock ~-92 ~2 ~-110 minecraft:glass
setblock ~-92 ~2 ~-108 minecraft:glass
setblock ~-92 ~2 ~-106 minecraft:glass
setblock ~-92 ~2 ~-104 minecraft:glass
setblock ~-92 ~2 ~-102 minecraft:glass
setblock ~-92 ~2 ~-100 minecraft:glass
setblock ~-92 ~2 ~-98 minecraft:glass
setblock ~-92 ~2 ~-96 minecraft:glass
setblock ~-92 ~2 ~-94 minecraft:glass
setblock ~-92 ~2 ~-92 minecraft:glass
setblock ~-92 ~2 ~-90 minecraft:glass
setblock ~-92 ~2 ~-88 minecraft:glass
setblock ~-92 ~2 ~-86 minecraft:glass
setblock ~-92 ~2 ~-84 minecraft:glass
setblock ~-92 ~2 ~-82 minecraft:glass
setblock ~-92 ~4 ~-112 minecraft:glass
setblock ~-92 ~4 ~-110 minecraft:glass
setblock ~-92 ~4 ~-108 minecraft:glass
setblock ~-92 ~4 ~-106 minecraft:glass
setblock ~-92 ~4 ~-104 minecraft:glass
setblock ~-92 ~4 ~-102 minecraft:glass
setblock ~-92 ~4 ~-100 minecraft:glass
setblock ~-92 ~4 ~-98 minecraft:glass
setblock ~-92 ~4 ~-96 minecraft:glass
setblock ~-92 ~4 ~-94 minecraft:glass
setblock ~-92 ~4 ~-92 minecraft:glass
setblock ~-92 ~4 ~-90 minecraft:glass
setblock ~-92 ~4 ~-88 minecraft:glass
setblock ~-92 ~4 ~-86 minecraft:glass
setblock ~-92 ~4 ~-84 minecraft:glass
setblock ~-92 ~4 ~-82 minecraft:glass
setblock ~-92 ~6 ~-112 minecraft:glass
setblock ~-92 ~6 ~-110 minecraft:glass
setblock ~-92 ~6 ~-108 minecraft:glass
setblock ~-92 ~6 ~-106 minecraft:glass
setblock ~-92 ~6 ~-104 minecraft:glass
setblock ~-92 ~6 ~-102 minecraft:glass
setblock ~-92 ~6 ~-100 minecraft:glass
setblock ~-92 ~6 ~-98 minecraft:glass
setblock ~-92 ~6 ~-96 minecraft:glass
setblock ~-92 ~6 ~-94 minecraft:glass
setblock ~-92 ~6 ~-92 minecraft:glass
setblock ~-92 ~6 ~-90 minecraft:glass
setblock ~-92 ~6 ~-88 minecraft:glass
setblock ~-92 ~6 ~-86 minecraft:glass
setblock ~-92 ~6 ~-84 minecraft:glass
setblock ~-92 ~6 ~-82 minecraft:glass
setblock ~-92 ~8 ~-112 minecraft:glass
setblock ~-92 ~8 ~-110 minecraft:glass
setblock ~-92 ~8 ~-108 minecraft:glass
setblock ~-92 ~8 ~-106 minecraft:glass
setblock ~-92 ~8 ~-104 minecraft:glass
setblock ~-92 ~8 ~-102 minecraft:glass
setblock ~-92 ~8 ~-100 minecraft:glass
setblock ~-92 ~8 ~-98 minecraft:glass
setblock ~-92 ~8 ~-96 minecraft:glass
setblock ~-92 ~8 ~-94 minecraft:glass
setblock ~-92 ~8 ~-92 minecraft:glass
setblock ~-92 ~8 ~-90 minecraft:glass
setblock ~-92 ~8 ~-88 minecraft:glass
setblock ~-92 ~8 ~-86 minecraft:glass
setblock ~-92 ~8 ~-84 minecraft:glass
setblock ~-92 ~8 ~-82 minecraft:glass
setblock ~-92 ~10 ~-112 minecraft:glass
setblock ~-92 ~10 ~-110 minecraft:glass
setblock ~-92 ~10 ~-108 minecraft:glass
setblock ~-92 ~10 ~-106 minecraft:glass
setblock ~-92 ~10 ~-104 minecraft:glass
setblock ~-92 ~10 ~-102 minecraft:glass
setblock ~-92 ~10 ~-100 minecraft:glass
setblock ~-92 ~10 ~-98 minecraft:glass
setblock ~-92 ~10 ~-96 minecraft:glass
setblock ~-92 ~10 ~-94 minecraft:glass
setblock ~-92 ~10 ~-92 minecraft:glass
setblock ~-92 ~10 ~-90 minecraft:glass
setblock ~-92 ~10 ~-88 minecraft:glass
setblock ~-92 ~10 ~-86 minecraft:glass
setblock ~-92 ~10 ~-84 minecraft:glass
setblock ~-92 ~10 ~-82 minecraft:glass
setblock ~-92 ~12 ~-112 minecraft:glass
setblock ~-92 ~12 ~-110 minecraft:glass
setblock ~-92 ~12 ~-108 minecraft:glass
setblock ~-92 ~12 ~-106 minecraft:glass
setblock ~-92 ~12 ~-104 minecraft:glass
setblock ~-92 ~12 ~-102 minecraft:glass
setblock ~-92 ~12 ~-100 minecraft:glass
setblock ~-92 ~12 ~-98 minecraft:glass
setblock ~-92 ~12 ~-96 minecraft:glass
setblock ~-92 ~12 ~-94 minecraft:glass
setblock ~-92 ~12 ~-92 minecraft:glass
setblock ~-92 ~12 ~-90 minecraft:glass
setblock ~-92 ~12 ~-88 minecraft:glass
setblock ~-92 ~12 ~-86 minecraft:glass
setblock ~-92 ~12 ~-84 minecraft:glass
setblock ~-92 ~12 ~-82 minecraft:glass
setblock ~-92 ~14 ~-112 minecraft:glass
setblock ~-92 ~14 ~-110 minecraft:glass
setblock ~-92 ~14 ~-108 minecraft:glass
setblock ~-92 ~14 ~-106 minecraft:glass
setblock ~-92 ~14 ~-104 minecraft:glass
setblock ~-92 ~14 ~-102 minecraft:glass
setblock ~-92 ~14 ~-100 minecraft:glass
setblock ~-92 ~14 ~-98 minecraft:glass
setblock ~-92 ~14 ~-96 minecraft:glass
setblock ~-92 ~14 ~-94 minecraft:glass
setblock ~-92 ~14 ~-92 minecraft:glass
setblock ~-92 ~14 ~-90 minecraft:glass
setblock ~-92 ~14 ~-88 minecraft:glass
setblock ~-92 ~14 ~-86 minecraft:glass
setblock ~-92 ~14 ~-84 minecraft:glass
setblock ~-92 ~14 ~-82 minecraft:glass
setblock ~-92 ~16 ~-112 minecraft:glass
setblock ~-92 ~16 ~-110 minecraft:glass
setblock ~-92 ~16 ~-108 minecraft:glass
setblock ~-92 ~16 ~-106 minecraft:glass
setblock ~-92 ~16 ~-104 minecraft:glass
setblock ~-92 ~16 ~-102 minecraft:glass
setblock ~-92 ~16 ~-100 minecraft:glass
setblock ~-92 ~16 ~-98 minecraft:glass
setblock ~-92 ~16 ~-96 minecraft:glass
setblock ~-92 ~16 ~-94 minecraft:glass
setblock ~-92 ~16 ~-92 minecraft:glass
setblock ~-92 ~16 ~-90 minecraft:glass
setblock ~-92 ~16 ~-88 minecraft:glass
setblock ~-92 ~16 ~-86 minecraft:glass
setblock ~-92 ~16 ~-84 minecraft:glass
setblock ~-92 ~16 ~-82 minecraft:glass
setblock ~-92 ~18 ~-112 minecraft:glass
setblock ~-92 ~18 ~-110 minecraft:glass
setblock ~-92 ~18 ~-108 minecraft:glass
setblock ~-92 ~18 ~-106 minecraft:glass
setblock ~-92 ~18 ~-104 minecraft:glass
setblock ~-92 ~18 ~-102 minecraft:glass
setblock ~-92 ~18 ~-100 minecraft:glass
setblock ~-92 ~18 ~-98 minecraft:glass
setblock ~-92 ~18 ~-96 minecraft:glass
setblock ~-92 ~18 ~-94 minecraft:glass
setblock ~-92 ~18 ~-92 minecraft:glass
setblock ~-92 ~18 ~-90 minecraft:glass
setblock ~-92 ~18 ~-88 minecraft:glass
setblock ~-92 ~18 ~-86 minecraft:glass
setblock ~-92 ~18 ~-84 minecraft:glass
setblock ~-92 ~18 ~-82 minecraft:glass
setblock ~-92 ~20 ~-112 minecraft:glass
setblock ~-92 ~20 ~-110 minecraft:glass
setblock ~-92 ~20 ~-108 minecraft:glass
setblock ~-92 ~20 ~-106 minecraft:glass
setblock ~-92 ~20 ~-104 minecraft:glass
setblock ~-92 ~20 ~-102 minecraft:glass
setblock ~-92 ~20 ~-100 minecraft:glass
setblock ~-92 ~20 ~-98 minecraft:glass
setblock ~-92 ~20 ~-96 minecraft:glass
setblock ~-92 ~20 ~-94 minecraft:glass
setblock ~-92 ~20 ~-92 minecraft:glass
setblock ~-92 ~20 ~-90 minecraft:glass
setblock ~-92 ~20 ~-88 minecraft:glass
setblock ~-92 ~20 ~-86 minecraft:glass
setblock ~-92 ~20 ~-84 minecraft:glass
setblock ~-92 ~20 ~-82 minecraft:glass
setblock ~-92 ~22 ~-112 minecraft:glass
setblock ~-92 ~22 ~-110 minecraft:glass
setblock ~-92 ~22 ~-108 minecraft:glass
setblock ~-92 ~22 ~-106 minecraft:glass
setblock ~-92 ~22 ~-104 minecraft:glass
setblock ~-92 ~22 ~-102 minecraft:glass
setblock ~-92 ~22 ~-100 minecraft:glass
setblock ~-92 ~22 ~-98 minecraft:glass
setblock ~-92 ~22 ~-96 minecraft:glass
setblock ~-92 ~22 ~-94 minecraft:glass
setblock ~-92 ~22 ~-92 minecraft:glass
setblock ~-92 ~22 ~-90 minecraft:glass
setblock ~-92 ~22 ~-88 minecraft:glass
setblock ~-92 ~22 ~-86 minecraft:glass
setblock ~-92 ~22 ~-84 minecraft:glass
setblock ~-92 ~22 ~-82 minecraft:glass
setblock ~-92 ~24 ~-112 minecraft:glass
setblock ~-92 ~24 ~-110 minecraft:glass
setblock ~-92 ~24 ~-108 minecraft:glass
setblock ~-92 ~24 ~-106 minecraft:glass
setblock ~-92 ~24 ~-104 minecraft:glass
setblock ~-92 ~24 ~-102 minecraft:glass
setblock ~-92 ~24 ~-100 minecraft:glass
setblock ~-92 ~24 ~-98 minecraft:glass
setblock ~-92 ~24 ~-96 minecraft:glass
setblock ~-92 ~24 ~-94 minecraft:glass
setblock ~-92 ~24 ~-92 minecraft:glass
setblock ~-92 ~24 ~-90 minecraft:glass
setblock ~-92 ~24 ~-88 minecraft:glass
setblock ~-92 ~24 ~-86 minecraft:glass
setblock ~-92 ~24 ~-84 minecraft:glass
setblock ~-92 ~24 ~-82 minecraft:glass
setblock ~-92 ~26 ~-112 minecraft:glass
setblock ~-92 ~26 ~-110 minecraft:glass
setblock ~-92 ~26 ~-108 minecraft:glass
setblock ~-92 ~26 ~-106 minecraft:glass
setblock ~-92 ~26 ~-104 minecraft:glass
setblock ~-92 ~26 ~-102 minecraft:glass
setblock ~-92 ~26 ~-100 minecraft:glass
setblock ~-92 ~26 ~-98 minecraft:glass
setblock ~-92 ~26 ~-96 minecraft:glass
setblock ~-92 ~26 ~-94 minecraft:glass
setblock ~-92 ~26 ~-92 minecraft:glass
setblock ~-92 ~26 ~-90 minecraft:glass
setblock ~-92 ~26 ~-88 minecraft:glass
setblock ~-92 ~26 ~-86 minecraft:glass
setblock ~-92 ~26 ~-84 minecraft:glass
setblock ~-92 ~26 ~-82 minecraft:glass
setblock ~-92 ~28 ~-112 minecraft:glass
setblock ~-92 ~28 ~-110 minecraft:glass
setblock ~-92 ~28 ~-108 minecraft:glass
setblock ~-92 ~28 ~-106 minecraft:glass
setblock ~-92 ~28 ~-104 minecraft:glass
setblock ~-92 ~28 ~-102 minecraft:glass
setblock ~-92 ~28 ~-100 minecraft:glass
setblock ~-92 ~28 ~-98 minecraft:glass
setblock ~-92 ~28 ~-96 minecraft:glass
setblock ~-92 ~28 ~-94 minecraft:glass
setblock ~-92 ~28 ~-92 minecraft:glass
setblock ~-92 ~28 ~-90 minecraft:glass
setblock ~-92 ~28 ~-88 minecraft:glass
setblock ~-92 ~28 ~-86 minecraft:glass
setblock ~-92 ~28 ~-84 minecraft:glass
setblock ~-92 ~28 ~-82 minecraft:glass
setblock ~-92 ~30 ~-112 minecraft:glass
setblock ~-92 ~30 ~-110 minecraft:glass
setblock ~-92 ~30 ~-108 minecraft:glass
setblock ~-92 ~30 ~-106 minecraft:glass
setblock ~-92 ~30 ~-104 minecraft:glass
setblock ~-92 ~30 ~-102 minecraft:glass
setblock ~-92 ~30 ~-100 minecraft:glass
setblock ~-92 ~30 ~-98 minecraft:glass
setblock ~-92 ~30 ~-96 minecraft:glass
setblock ~-92 ~30 ~-94 minecraft:glass
setblock ~-92 ~30 ~-92 minecraft:glass
setblock ~-92 ~30 ~-90 minecraft:glass
setblock ~-92 ~30 ~-88 minecraft:glass
setblock ~-92 ~30 ~-86 minecraft:glass
setblock ~-92 ~30 ~-84 minecraft:glass
setblock ~-92 ~30 ~-82 minecraft:glass
setblock ~-90 ~0 ~-112 minecraft:glass
setblock ~-90 ~0 ~-110 minecraft:glass
setblock ~-90 ~0 ~-108 minecraft:glass
setblock ~-90 ~0 ~-106 minecraft:glass
setblock ~-90 ~0 ~-104 minecraft:glass
setblock ~-90 ~0 ~-102 minecraft:glass
setblock ~-90 ~0 ~-100 minecraft:glass
setblock ~-90 ~0 ~-98 minecraft:glass
setblock ~-90 ~0 ~-96 minecraft:glass
setblock ~-90 ~0 ~-94 minecraft:glass
setblock ~-90 ~0 ~-92 minecraft:glass
setblock ~-90 ~0 ~-90 minecraft:glass
setblock ~-90 ~0 ~-88 minecraft:glass
setblock ~-90 ~0 ~-86 minecraft:glass
setblock ~-90 ~0 ~-84 minecraft:glass
setblock ~-90 ~0 ~-82 minecraft:glass
setblock ~-90 ~2 ~-112 minecraft:glass
setblock ~-90 ~2 ~-110 minecraft:glass
setblock ~-90 ~2 ~-108 minecraft:glass
setblock ~-90 ~2 ~-106 minecraft:glass
setblock ~-90 ~2 ~-104 minecraft:glass
setblock ~-90 ~2 ~-102 minecraft:glass
setblock ~-90 ~2 ~-100 minecraft:glass
setblock ~-90 ~2 ~-98 minecraft:glass
setblock ~-90 ~2 ~-96 minecraft:glass
setblock ~-90 ~2 ~-94 minecraft:glass
setblock ~-90 ~2 ~-92 minecraft:glass
setblock ~-90 ~2 ~-90 minecraft:glass
setblock ~-90 ~2 ~-88 minecraft:glass
setblock ~-90 ~2 ~-86 minecraft:glass
setblock ~-90 ~2 ~-84 minecraft:glass
setblock ~-90 ~2 ~-82 minecraft:glass
setblock ~-90 ~4 ~-112 minecraft:glass
setblock ~-90 ~4 ~-110 minecraft:glass
setblock ~-90 ~4 ~-108 minecraft:glass
setblock ~-90 ~4 ~-106 minecraft:glass
setblock ~-90 ~4 ~-104 minecraft:glass
setblock ~-90 ~4 ~-102 minecraft:glass
setblock ~-90 ~4 ~-100 minecraft:glass
setblock ~-90 ~4 ~-98 minecraft:glass
setblock ~-90 ~4 ~-96 minecraft:glass
setblock ~-90 ~4 ~-94 minecraft:glass
setblock ~-90 ~4 ~-92 minecraft:glass
setblock ~-90 ~4 ~-90 minecraft:glass
setblock ~-90 ~4 ~-88 minecraft:glass
setblock ~-90 ~4 ~-86 minecraft:glass
setblock ~-90 ~4 ~-84 minecraft:glass
setblock ~-90 ~4 ~-82 minecraft:glass
setblock ~-90 ~6 ~-112 minecraft:glass
setblock ~-90 ~6 ~-110 minecraft:glass
setblock ~-90 ~6 ~-108 minecraft:glass
setblock ~-90 ~6 ~-106 minecraft:glass
setblock ~-90 ~6 ~-104 minecraft:glass
setblock ~-90 ~6 ~-102 minecraft:glass
setblock ~-90 ~6 ~-100 minecraft:glass
setblock ~-90 ~6 ~-98 minecraft:glass
setblock ~-90 ~6 ~-96 minecraft:glass
setblock ~-90 ~6 ~-94 minecraft:glass
setblock ~-90 ~6 ~-92 minecraft:glass
setblock ~-90 ~6 ~-90 minecraft:glass
setblock ~-90 ~6 ~-88 minecraft:glass
setblock ~-90 ~6 ~-86 minecraft:glass
setblock ~-90 ~6 ~-84 minecraft:glass
setblock ~-90 ~6 ~-82 minecraft:glass
setblock ~-90 ~8 ~-112 minecraft:glass
setblock ~-90 ~8 ~-110 minecraft:glass
setblock ~-90 ~8 ~-108 minecraft:glass
setblock ~-90 ~8 ~-106 minecraft:glass
setblock ~-90 ~8 ~-104 minecraft:glass
setblock ~-90 ~8 ~-102 minecraft:glass
setblock ~-90 ~8 ~-100 minecraft:glass
setblock ~-90 ~8 ~-98 minecraft:glass
setblock ~-90 ~8 ~-96 minecraft:glass
setblock ~-90 ~8 ~-94 minecraft:glass
setblock ~-90 ~8 ~-92 minecraft:glass
setblock ~-90 ~8 ~-90 minecraft:glass
setblock ~-90 ~8 ~-88 minecraft:glass
setblock ~-90 ~8 ~-86 minecraft:glass
setblock ~-90 ~8 ~-84 minecraft:glass
setblock ~-90 ~8 ~-82 minecraft:glass
setblock ~-90 ~10 ~-112 minecraft:glass
setblock ~-90 ~10 ~-110 minecraft:glass
setblock ~-90 ~10 ~-108 minecraft:glass
setblock ~-90 ~10 ~-106 minecraft:glass
setblock ~-90 ~10 ~-104 minecraft:glass
setblock ~-90 ~10 ~-102 minecraft:glass
setblock ~-90 ~10 ~-100 minecraft:glass
setblock ~-90 ~10 ~-98 minecraft:glass
setblock ~-90 ~10 ~-96 minecraft:glass
setblock ~-90 ~10 ~-94 minecraft:glass
setblock ~-90 ~10 ~-92 minecraft:glass
setblock ~-90 ~10 ~-90 minecraft:glass
setblock ~-90 ~10 ~-88 minecraft:glass
setblock ~-90 ~10 ~-86 minecraft:glass
setblock ~-90 ~10 ~-84 minecraft:glass
setblock ~-90 ~10 ~-82 minecraft:glass
setblock ~-90 ~12 ~-112 minecraft:glass
setblock ~-90 ~12 ~-110 minecraft:glass
setblock ~-90 ~12 ~-108 minecraft:glass
setblock ~-90 ~12 ~-106 minecraft:glass
setblock ~-90 ~12 ~-104 minecraft:glass
setblock ~-90 ~12 ~-102 minecraft:glass
setblock ~-90 ~12 ~-100 minecraft:glass
setblock ~-90 ~12 ~-98 minecraft:glass
setblock ~-90 ~12 ~-96 minecraft:glass
setblock ~-90 ~12 ~-94 minecraft:glass
setblock ~-90 ~12 ~-92 minecraft:glass
setblock ~-90 ~12 ~-90 minecraft:glass
setblock ~-90 ~12 ~-88 minecraft:glass
setblock ~-90 ~12 ~-86 minecraft:glass
setblock ~-90 ~12 ~-84 minecraft:glass
setblock ~-90 ~12 ~-82 minecraft:glass
setblock ~-90 ~14 ~-112 minecraft:glass
setblock ~-90 ~14 ~-110 minecraft:glass
setblock ~-90 ~14 ~-108 minecraft:glass
setblock ~-90 ~14 ~-106 minecraft:glass
setblock ~-90 ~14 ~-104 minecraft:glass
setblock ~-90 ~14 ~-102 minecraft:glass
setblock ~-90 ~14 ~-100 minecraft:glass
setblock ~-90 ~14 ~-98 minecraft:glass
setblock ~-90 ~14 ~-96 minecraft:glass
setblock ~-90 ~14 ~-94 minecraft:glass
setblock ~-90 ~14 ~-92 minecraft:glass
setblock ~-90 ~14 ~-90 minecraft:glass
setblock ~-90 ~14 ~-88 minecraft:glass
setblock ~-90 ~14 ~-86 minecraft:glass
setblock ~-90 ~14 ~-84 minecraft:glass
setblock ~-90 ~14 ~-82 minecraft:glass
setblock ~-90 ~16 ~-112 minecraft:glass
setblock ~-90 ~16 ~-110 minecraft:glass
setblock ~-90 ~16 ~-108 minecraft:glass
setblock ~-90 ~16 ~-106 minecraft:glass
setblock ~-90 ~16 ~-104 minecraft:glass
setblock ~-90 ~16 ~-102 minecraft:glass
setblock ~-90 ~16 ~-100 minecraft:glass
setblock ~-90 ~16 ~-98 minecraft:glass
setblock ~-90 ~16 ~-96 minecraft:glass
setblock ~-90 ~16 ~-94 minecraft:glass
setblock ~-90 ~16 ~-92 minecraft:glass
setblock ~-90 ~16 ~-90 minecraft:glass
setblock ~-90 ~16 ~-88 minecraft:glass
setblock ~-90 ~16 ~-86 minecraft:glass
setblock ~-90 ~16 ~-84 minecraft:glass
setblock ~-90 ~16 ~-82 minecraft:glass
setblock ~-90 ~18 ~-112 minecraft:glass
setblock ~-90 ~18 ~-110 minecraft:glass
setblock ~-90 ~18 ~-108 minecraft:glass
setblock ~-90 ~18 ~-106 minecraft:glass
setblock ~-90 ~18 ~-104 minecraft:glass
setblock ~-90 ~18 ~-102 minecraft:glass
setblock ~-90 ~18 ~-100 minecraft:glass
setblock ~-90 ~18 ~-98 minecraft:glass
setblock ~-90 ~18 ~-96 minecraft:glass
setblock ~-90 ~18 ~-94 minecraft:glass
setblock ~-90 ~18 ~-92 minecraft:glass
setblock ~-90 ~18 ~-90 minecraft:glass
setblock ~-90 ~18 ~-88 minecraft:glass
setblock ~-90 ~18 ~-86 minecraft:glass
setblock ~-90 ~18 ~-84 minecraft:glass
setblock ~-90 ~18 ~-82 minecraft:glass
setblock ~-90 ~20 ~-112 minecraft:glass
setblock ~-90 ~20 ~-110 minecraft:glass
setblock ~-90 ~20 ~-108 minecraft:glass
setblock ~-90 ~20 ~-106 minecraft:glass
setblock ~-90 ~20 ~-104 minecraft:glass
setblock ~-90 ~20 ~-102 minecraft:glass
setblock ~-90 ~20 ~-100 minecraft:glass
setblock ~-90 ~20 ~-98 minecraft:glass
setblock ~-90 ~20 ~-96 minecraft:glass
setblock ~-90 ~20 ~-94 minecraft:glass
setblock ~-90 ~20 ~-92 minecraft:glass
setblock ~-90 ~20 ~-90 minecraft:glass
setblock ~-90 ~20 ~-88 minecraft:glass
setblock ~-90 ~20 ~-86 minecraft:glass
setblock ~-90 ~20 ~-84 minecraft:glass
setblock ~-90 ~20 ~-82 minecraft:glass
setblock ~-90 ~22 ~-112 minecraft:glass
setblock ~-90 ~22 ~-110 minecraft:glass
setblock ~-90 ~22 ~-108 minecraft:glass
setblock ~-90 ~22 ~-106 minecraft:glass
setblock ~-90 ~22 ~-104 minecraft:glass
setblock ~-90 ~22 ~-102 minecraft:glass
setblock ~-90 ~22 ~-100 minecraft:glass
setblock ~-90 ~22 ~-98 minecraft:glass
setblock ~-90 ~22 ~-96 minecraft:glass
setblock ~-90 ~22 ~-94 minecraft:glass
setblock ~-90 ~22 ~-92 minecraft:glass
setblock ~-90 ~22 ~-90 minecraft:glass
setblock ~-90 ~22 ~-88 minecraft:glass
setblock ~-90 ~22 ~-86 minecraft:glass
setblock ~-90 ~22 ~-84 minecraft:glass
setblock ~-90 ~22 ~-82 minecraft:glass
setblock ~-90 ~24 ~-112 minecraft:glass
setblock ~-90 ~24 ~-110 minecraft:glass
setblock ~-90 ~24 ~-108 minecraft:glass
setblock ~-90 ~24 ~-106 minecraft:glass
setblock ~-90 ~24 ~-104 minecraft:glass
setblock ~-90 ~24 ~-102 minecraft:glass
setblock ~-90 ~24 ~-100 minecraft:glass
setblock ~-90 ~24 ~-98 minecraft:glass
setblock ~-90 ~24 ~-96 minecraft:glass
setblock ~-90 ~24 ~-94 minecraft:glass
setblock ~-90 ~24 ~-92 minecraft:glass
setblock ~-90 ~24 ~-90 minecraft:glass
setblock ~-90 ~24 ~-88 minecraft:glass
setblock ~-90 ~24 ~-86 minecraft:glass
setblock ~-90 ~24 ~-84 minecraft:glass
setblock ~-90 ~24 ~-82 minecraft:glass
setblock ~-90 ~26 ~-112 minecraft:glass
setblock ~-90 ~26 ~-110 minecraft:glass
setblock ~-90 ~26 ~-108 minecraft:glass
setblock ~-90 ~26 ~-106 minecraft:glass
setblock ~-90 ~26 ~-104 minecraft:glass
setblock ~-90 ~26 ~-102 minecraft:glass
setblock ~-90 ~26 ~-100 minecraft:glass
setblock ~-90 ~26 ~-98 minecraft:glass
setblock ~-90 ~26 ~-96 minecraft:glass
setblock ~-90 ~26 ~-94 minecraft:glass
setblock ~-90 ~26 ~-92 minecraft:glass
setblock ~-90 ~26 ~-90 minecraft:glass
setblock ~-90 ~26 ~-88 minecraft:glass
setblock ~-90 ~26 ~-86 minecraft:glass
setblock ~-90 ~26 ~-84 minecraft:glass
setblock ~-90 ~26 ~-82 minecraft:glass
setblock ~-90 ~28 ~-112 minecraft:glass
setblock ~-90 ~28 ~-110 minecraft:glass
setblock ~-90 ~28 ~-108 minecraft:glass
setblock ~-90 ~28 ~-106 minecraft:glass
setblock ~-90 ~28 ~-104 minecraft:glass
setblock ~-90 ~28 ~-102 minecraft:glass
setblock ~-90 ~28 ~-100 minecraft:glass
setblock ~-90 ~28 ~-98 minecraft:glass
setblock ~-90 ~28 ~-96 minecraft:glass
setblock ~-90 ~28 ~-94 minecraft:glass
setblock ~-90 ~28 ~-92 minecraft:glass
setblock ~-90 ~28 ~-90 minecraft:glass
setblock ~-90 ~28 ~-88 minecraft:glass
setblock ~-90 ~28 ~-86 minecraft:glass
setblock ~-90 ~28 ~-84 minecraft:glass
setblock ~-90 ~28 ~-82 minecraft:glass
setblock ~-90 ~30 ~-112 minecraft:glass
setblock ~-90 ~30 ~-110 minecraft:glass
setblock ~-90 ~30 ~-108 minecraft:glass
setblock ~-90 ~30 ~-106 minecraft:glass
setblock ~-90 ~30 ~-104 minecraft:glass
setblock ~-90 ~30 ~-102 minecraft:glass
setblock ~-90 ~30 ~-100 minecraft:glass
setblock ~-90 ~30 ~-98 minecraft:glass
setblock ~-90 ~30 ~-96 minecraft:glass
setblock ~-90 ~30 ~-94 minecraft:glass
setblock ~-90 ~30 ~-92 minecraft:glass
setblock ~-90 ~30 ~-90 minecraft:glass
setblock ~-90 ~30 ~-88 minecraft:glass
setblock ~-90 ~30 ~-86 minecraft:glass
setblock ~-90 ~30 ~-84 minecraft:glass
setblock ~-90 ~30 ~-82 minecraft:glass
setblock ~-88 ~0 ~-112 minecraft:glass
setblock ~-88 ~0 ~-110 minecraft:glass
setblock ~-88 ~0 ~-108 minecraft:glass
setblock ~-88 ~0 ~-106 minecraft:glass
setblock ~-88 ~0 ~-104 minecraft:glass
setblock ~-88 ~0 ~-102 minecraft:glass
setblock ~-88 ~0 ~-100 minecraft:glass
setblock ~-88 ~0 ~-98 minecraft:glass
setblock ~-88 ~0 ~-96 minecraft:glass
setblock ~-88 ~0 ~-94 minecraft:glass
setblock ~-88 ~0 ~-92 minecraft:glass
setblock ~-88 ~0 ~-90 minecraft:glass
setblock ~-88 ~0 ~-88 minecraft:glass
setblock ~-88 ~0 ~-86 minecraft:glass
setblock ~-88 ~0 ~-84 minecraft:glass
setblock ~-88 ~0 ~-82 minecraft:glass
setblock ~-88 ~2 ~-112 minecraft:glass
setblock ~-88 ~2 ~-110 minecraft:glass
setblock ~-88 ~2 ~-108 minecraft:glass
setblock ~-88 ~2 ~-106 minecraft:glass
setblock ~-88 ~2 ~-104 minecraft:glass
setblock ~-88 ~2 ~-102 minecraft:glass
setblock ~-88 ~2 ~-100 minecraft:glass
setblock ~-88 ~2 ~-98 minecraft:glass
setblock ~-88 ~2 ~-96 minecraft:glass
setblock ~-88 ~2 ~-94 minecraft:glass
setblock ~-88 ~2 ~-92 minecraft:glass
setblock ~-88 ~2 ~-90 minecraft:glass
setblock ~-88 ~2 ~-88 minecraft:glass
setblock ~-88 ~2 ~-86 minecraft:glass
setblock ~-88 ~2 ~-84 minecraft:glass
setblock ~-88 ~2 ~-82 minecraft:glass
setblock ~-88 ~4 ~-112 minecraft:glass
setblock ~-88 ~4 ~-110 minecraft:glass
setblock ~-88 ~4 ~-108 minecraft:glass
setblock ~-88 ~4 ~-106 minecraft:glass
setblock ~-88 ~4 ~-104 minecraft:glass
setblock ~-88 ~4 ~-102 minecraft:glass
setblock ~-88 ~4 ~-100 minecraft:glass
setblock ~-88 ~4 ~-98 minecraft:glass
setblock ~-88 ~4 ~-96 minecraft:glass
setblock ~-88 ~4 ~-94 minecraft:glass
setblock ~-88 ~4 ~-92 minecraft:glass
setblock ~-88 ~4 ~-90 minecraft:glass
setblock ~-88 ~4 ~-88 minecraft:glass
setblock ~-88 ~4 ~-86 minecraft:glass
setblock ~-88 ~4 ~-84 minecraft:glass
setblock ~-88 ~4 ~-82 minecraft:glass
setblock ~-88 ~6 ~-112 minecraft:glass
setblock ~-88 ~6 ~-110 minecraft:glass
setblock ~-88 ~6 ~-108 minecraft:glass
setblock ~-88 ~6 ~-106 minecraft:glass
setblock ~-88 ~6 ~-104 minecraft:glass
setblock ~-88 ~6 ~-102 minecraft:glass
setblock ~-88 ~6 ~-100 minecraft:glass
setblock ~-88 ~6 ~-98 minecraft:glass
setblock ~-88 ~6 ~-96 minecraft:glass
setblock ~-88 ~6 ~-94 minecraft:glass
setblock ~-88 ~6 ~-92 minecraft:glass
setblock ~-88 ~6 ~-90 minecraft:glass
setblock ~-88 ~6 ~-88 minecraft:glass
setblock ~-88 ~6 ~-86 minecraft:glass
setblock ~-88 ~6 ~-84 minecraft:glass
setblock ~-88 ~6 ~-82 minecraft:glass
setblock ~-88 ~8 ~-112 minecraft:glass
setblock ~-88 ~8 ~-110 minecraft:glass
setblock ~-88 ~8 ~-108 minecraft:glass
setblock ~-88 ~8 ~-106 minecraft:glass
setblock ~-88 ~8 ~-104 minecraft:glass
setblock ~-88 ~8 ~-102 minecraft:glass
setblock ~-88 ~8 ~-100 minecraft:glass
setblock ~-88 ~8 ~-98 minecraft:glass
setblock ~-88 ~8 ~-96 minecraft:glass
setblock ~-88 ~8 ~-94 minecraft:glass
setblock ~-88 ~8 ~-92 minecraft:glass
setblock ~-88 ~8 ~-90 minecraft:glass
setblock ~-88 ~8 ~-88 minecraft:glass
setblock ~-88 ~8 ~-86 minecraft:glass
setblock ~-88 ~8 ~-84 minecraft:glass
setblock ~-88 ~8 ~-82 minecraft:glass
setblock ~-88 ~10 ~-112 minecraft:glass
setblock ~-88 ~10 ~-110 minecraft:glass
setblock ~-88 ~10 ~-108 minecraft:glass
setblock ~-88 ~10 ~-106 minecraft:glass
setblock ~-88 ~10 ~-104 minecraft:glass
setblock ~-88 ~10 ~-102 minecraft:glass
setblock ~-88 ~10 ~-100 minecraft:glass
setblock ~-88 ~10 ~-98 minecraft:glass
setblock ~-88 ~10 ~-96 minecraft:glass
setblock ~-88 ~10 ~-94 minecraft:glass
setblock ~-88 ~10 ~-92 minecraft:glass
setblock ~-88 ~10 ~-90 minecraft:glass
setblock ~-88 ~10 ~-88 minecraft:glass
setblock ~-88 ~10 ~-86 minecraft:glass
setblock ~-88 ~10 ~-84 minecraft:glass
setblock ~-88 ~10 ~-82 minecraft:glass
setblock ~-88 ~12 ~-112 minecraft:glass
setblock ~-88 ~12 ~-110 minecraft:glass
setblock ~-88 ~12 ~-108 minecraft:glass
setblock ~-88 ~12 ~-106 minecraft:glass
setblock ~-88 ~12 ~-104 minecraft:glass
setblock ~-88 ~12 ~-102 minecraft:glass
setblock ~-88 ~12 ~-100 minecraft:glass
setblock ~-88 ~12 ~-98 minecraft:glass
setblock ~-88 ~12 ~-96 minecraft:glass
setblock ~-88 ~12 ~-94 minecraft:glass
setblock ~-88 ~12 ~-92 minecraft:glass
setblock ~-88 ~12 ~-90 minecraft:glass
setblock ~-88 ~12 ~-88 minecraft:glass
setblock ~-88 ~12 ~-86 minecraft:glass
setblock ~-88 ~12 ~-84 minecraft:glass
setblock ~-88 ~12 ~-82 minecraft:glass
setblock ~-88 ~14 ~-112 minecraft:glass
setblock ~-88 ~14 ~-110 minecraft:glass
setblock ~-88 ~14 ~-108 minecraft:glass
setblock ~-88 ~14 ~-106 minecraft:glass
setblock ~-88 ~14 ~-104 minecraft:glass
setblock ~-88 ~14 ~-102 minecraft:glass
setblock ~-88 ~14 ~-100 minecraft:glass
setblock ~-88 ~14 ~-98 minecraft:glass
setblock ~-88 ~14 ~-96 minecraft:glass
setblock ~-88 ~14 ~-94 minecraft:glass
setblock ~-88 ~14 ~-92 minecraft:glass
setblock ~-88 ~14 ~-90 minecraft:glass
setblock ~-88 ~14 ~-88 minecraft:glass
setblock ~-88 ~14 ~-86 minecraft:glass
setblock ~-88 ~14 ~-84 minecraft:glass
setblock ~-88 ~14 ~-82 minecraft:glass
setblock ~-88 ~16 ~-112 minecraft:glass
setblock ~-88 ~16 ~-110 minecraft:glass
setblock ~-88 ~16 ~-108 minecraft:glass
setblock ~-88 ~16 ~-106 minecraft:glass
setblock ~-88 ~16 ~-104 minecraft:glass
setblock ~-88 ~16 ~-102 minecraft:glass
setblock ~-88 ~16 ~-100 minecraft:glass
setblock ~-88 ~16 ~-98 minecraft:glass
setblock ~-88 ~16 ~-96 minecraft:glass
setblock ~-88 ~16 ~-94 minecraft:glass
setblock ~-88 ~16 ~-92 minecraft:glass
setblock ~-88 ~16 ~-90 minecraft:glass
setblock ~-88 ~16 ~-88 minecraft:glass
setblock ~-88 ~16 ~-86 minecraft:glass
setblock ~-88 ~16 ~-84 minecraft:glass
setblock ~-88 ~16 ~-82 minecraft:glass
setblock ~-88 ~18 ~-112 minecraft:glass
setblock ~-88 ~18 ~-110 minecraft:glass
setblock ~-88 ~18 ~-108 minecraft:glass
setblock ~-88 ~18 ~-106 minecraft:glass
setblock ~-88 ~18 ~-104 minecraft:glass
setblock ~-88 ~18 ~-102 minecraft:glass
setblock ~-88 ~18 ~-100 minecraft:glass
setblock ~-88 ~18 ~-98 minecraft:glass
setblock ~-88 ~18 ~-96 minecraft:glass
setblock ~-88 ~18 ~-94 minecraft:glass
setblock ~-88 ~18 ~-92 minecraft:glass
setblock ~-88 ~18 ~-90 minecraft:glass
setblock ~-88 ~18 ~-88 minecraft:glass
setblock ~-88 ~18 ~-86 minecraft:glass
setblock ~-88 ~18 ~-84 minecraft:glass
setblock ~-88 ~18 ~-82 minecraft:glass
setblock ~-88 ~20 ~-112 minecraft:glass
setblock ~-88 ~20 ~-110 minecraft:glass
setblock ~-88 ~20 ~-108 minecraft:glass
setblock ~-88 ~20 ~-106 minecraft:glass
setblock ~-88 ~20 ~-104 minecraft:glass
setblock ~-88 ~20 ~-102 minecraft:glass
setblock ~-88 ~20 ~-100 minecraft:glass
setblock ~-88 ~20 ~-98 minecraft:glass
setblock ~-88 ~20 ~-96 minecraft:glass
setblock ~-88 ~20 ~-94 minecraft:glass
setblock ~-88 ~20 ~-92 minecraft:glass
setblock ~-88 ~20 ~-90 minecraft:glass
setblock ~-88 ~20 ~-88 minecraft:glass
setblock ~-88 ~20 ~-86 minecraft:glass
setblock ~-88 ~20 ~-84 minecraft:glass
setblock ~-88 ~20 ~-82 minecraft:glass
setblock ~-88 ~22 ~-112 minecraft:glass
setblock ~-88 ~22 ~-110 minecraft:glass
setblock ~-88 ~22 ~-108 minecraft:glass
setblock ~-88 ~22 ~-106 minecraft:glass
setblock ~-88 ~22 ~-104 minecraft:glass
setblock ~-88 ~22 ~-102 minecraft:glass
setblock ~-88 ~22 ~-100 minecraft:glass
setblock ~-88 ~22 ~-98 minecraft:glass
setblock ~-88 ~22 ~-96 minecraft:glass
setblock ~-88 ~22 ~-94 minecraft:glass
setblock ~-88 ~22 ~-92 minecraft:glass
setblock ~-88 ~22 ~-90 minecraft:glass
setblock ~-88 ~22 ~-88 minecraft:glass
setblock ~-88 ~22 ~-86 minecraft:glass
setblock ~-88 ~22 ~-84 minecraft:glass
setblock ~-88 ~22 ~-82 minecraft:glass
setblock ~-88 ~24 ~-112 minecraft:glass
setblock ~-88 ~24 ~-110 minecraft:glass
setblock ~-88 ~24 ~-108 minecraft:glass
setblock ~-88 ~24 ~-106 minecraft:glass
setblock ~-88 ~24 ~-104 minecraft:glass
setblock ~-88 ~24 ~-102 minecraft:glass
setblock ~-88 ~24 ~-100 minecraft:glass
setblock ~-88 ~24 ~-98 minecraft:glass
setblock ~-88 ~24 ~-96 minecraft:glass
setblock ~-88 ~24 ~-94 minecraft:glass
setblock ~-88 ~24 ~-92 minecraft:glass
setblock ~-88 ~24 ~-90 minecraft:glass
setblock ~-88 ~24 ~-88 minecraft:glass
setblock ~-88 ~24 ~-86 minecraft:glass
setblock ~-88 ~24 ~-84 minecraft:glass
setblock ~-88 ~24 ~-82 minecraft:glass
setblock ~-88 ~26 ~-112 minecraft:glass
setblock ~-88 ~26 ~-110 minecraft:glass
setblock ~-88 ~26 ~-108 minecraft:glass
setblock ~-88 ~26 ~-106 minecraft:glass
setblock ~-88 ~26 ~-104 minecraft:glass
setblock ~-88 ~26 ~-102 minecraft:glass
setblock ~-88 ~26 ~-100 minecraft:glass
setblock ~-88 ~26 ~-98 minecraft:glass
setblock ~-88 ~26 ~-96 minecraft:glass
setblock ~-88 ~26 ~-94 minecraft:glass
setblock ~-88 ~26 ~-92 minecraft:glass
setblock ~-88 ~26 ~-90 minecraft:glass
setblock ~-88 ~26 ~-88 minecraft:glass
setblock ~-88 ~26 ~-86 minecraft:glass
setblock ~-88 ~26 ~-84 minecraft:glass
setblock ~-88 ~26 ~-82 minecraft:glass
setblock ~-88 ~28 ~-112 minecraft:glass
setblock ~-88 ~28 ~-110 minecraft:glass
setblock ~-88 ~28 ~-108 minecraft:glass
setblock ~-88 ~28 ~-106 minecraft:glass
setblock ~-88 ~28 ~-104 minecraft:glass
setblock ~-88 ~28 ~-102 minecraft:glass
setblock ~-88 ~28 ~-100 minecraft:glass
setblock ~-88 ~28 ~-98 minecraft:glass
setblock ~-88 ~28 ~-96 minecraft:glass
setblock ~-88 ~28 ~-94 minecraft:glass
setblock ~-88 ~28 ~-92 minecraft:glass
setblock ~-88 ~28 ~-90 minecraft:glass
setblock ~-88 ~28 ~-88 minecraft:glass
setblock ~-88 ~28 ~-86 minecraft:glass
setblock ~-88 ~28 ~-84 minecraft:glass
setblock ~-88 ~28 ~-82 minecraft:glass
setblock ~-88 ~30 ~-112 minecraft:glass
setblock ~-88 ~30 ~-110 minecraft:glass
setblock ~-88 ~30 ~-108 minecraft:glass
setblock ~-88 ~30 ~-106 minecraft:glass
setblock ~-88 ~30 ~-104 minecraft:glass
setblock ~-88 ~30 ~-102 minecraft:glass
setblock ~-88 ~30 ~-100 minecraft:glass
setblock ~-88 ~30 ~-98 minecraft:glass
setblock ~-88 ~30 ~-96 minecraft:glass
setblock ~-88 ~30 ~-94 minecraft:glass
setblock ~-88 ~30 ~-92 minecraft:glass
setblock ~-88 ~30 ~-90 minecraft:glass
setblock ~-88 ~30 ~-88 minecraft:glass
setblock ~-88 ~30 ~-86 minecraft:glass
setblock ~-88 ~30 ~-84 minecraft:glass
setblock ~-88 ~30 ~-82 minecraft:glass
setblock ~-86 ~0 ~-112 minecraft:glass
setblock ~-86 ~0 ~-110 minecraft:glass
setblock ~-86 ~0 ~-108 minecraft:glass
setblock ~-86 ~0 ~-106 minecraft:glass
setblock ~-86 ~0 ~-104 minecraft:glass
setblock ~-86 ~0 ~-102 minecraft:glass
setblock ~-86 ~0 ~-100 minecraft:glass
setblock ~-86 ~0 ~-98 minecraft:glass
setblock ~-86 ~0 ~-96 minecraft:glass
setblock ~-86 ~0 ~-94 minecraft:glass
setblock ~-86 ~0 ~-92 minecraft:glass
setblock ~-86 ~0 ~-90 minecraft:glass
setblock ~-86 ~0 ~-88 minecraft:glass
setblock ~-86 ~0 ~-86 minecraft:glass
setblock ~-86 ~0 ~-84 minecraft:glass
setblock ~-86 ~0 ~-82 minecraft:glass
setblock ~-86 ~2 ~-112 minecraft:glass
setblock ~-86 ~2 ~-110 minecraft:glass
setblock ~-86 ~2 ~-108 minecraft:glass
setblock ~-86 ~2 ~-106 minecraft:glass
setblock ~-86 ~2 ~-104 minecraft:glass
setblock ~-86 ~2 ~-102 minecraft:glass
setblock ~-86 ~2 ~-100 minecraft:glass
setblock ~-86 ~2 ~-98 minecraft:glass
setblock ~-86 ~2 ~-96 minecraft:glass
setblock ~-86 ~2 ~-94 minecraft:glass
setblock ~-86 ~2 ~-92 minecraft:glass
setblock ~-86 ~2 ~-90 minecraft:glass
setblock ~-86 ~2 ~-88 minecraft:glass
setblock ~-86 ~2 ~-86 minecraft:glass
setblock ~-86 ~2 ~-84 minecraft:glass
setblock ~-86 ~2 ~-82 minecraft:glass
setblock ~-86 ~4 ~-112 minecraft:glass
setblock ~-86 ~4 ~-110 minecraft:glass
setblock ~-86 ~4 ~-108 minecraft:glass
setblock ~-86 ~4 ~-106 minecraft:glass
setblock ~-86 ~4 ~-104 minecraft:glass
setblock ~-86 ~4 ~-102 minecraft:glass
setblock ~-86 ~4 ~-100 minecraft:glass
setblock ~-86 ~4 ~-98 minecraft:glass
setblock ~-86 ~4 ~-96 minecraft:glass
setblock ~-86 ~4 ~-94 minecraft:glass
setblock ~-86 ~4 ~-92 minecraft:glass
setblock ~-86 ~4 ~-90 minecraft:glass
setblock ~-86 ~4 ~-88 minecraft:glass
setblock ~-86 ~4 ~-86 minecraft:glass
setblock ~-86 ~4 ~-84 minecraft:glass
setblock ~-86 ~4 ~-82 minecraft:glass
setblock ~-86 ~6 ~-112 minecraft:glass
setblock ~-86 ~6 ~-110 minecraft:glass
setblock ~-86 ~6 ~-108 minecraft:glass
setblock ~-86 ~6 ~-106 minecraft:glass
setblock ~-86 ~6 ~-104 minecraft:glass
setblock ~-86 ~6 ~-102 minecraft:glass
setblock ~-86 ~6 ~-100 minecraft:glass
setblock ~-86 ~6 ~-98 minecraft:glass
setblock ~-86 ~6 ~-96 minecraft:glass
setblock ~-86 ~6 ~-94 minecraft:glass
setblock ~-86 ~6 ~-92 minecraft:glass
setblock ~-86 ~6 ~-90 minecraft:glass
setblock ~-86 ~6 ~-88 minecraft:glass
setblock ~-86 ~6 ~-86 minecraft:glass
setblock ~-86 ~6 ~-84 minecraft:glass
setblock ~-86 ~6 ~-82 minecraft:glass
setblock ~-86 ~8 ~-112 minecraft:glass
setblock ~-86 ~8 ~-110 minecraft:glass
setblock ~-86 ~8 ~-108 minecraft:glass
setblock ~-86 ~8 ~-106 minecraft:glass
setblock ~-86 ~8 ~-104 minecraft:glass
setblock ~-86 ~8 ~-102 minecraft:glass
setblock ~-86 ~8 ~-100 minecraft:glass
setblock ~-86 ~8 ~-98 minecraft:glass
setblock ~-86 ~8 ~-96 minecraft:glass
setblock ~-86 ~8 ~-94 minecraft:glass
setblock ~-86 ~8 ~-92 minecraft:glass
setblock ~-86 ~8 ~-90 minecraft:glass
setblock ~-86 ~8 ~-88 minecraft:glass
setblock ~-86 ~8 ~-86 minecraft:glass
setblock ~-86 ~8 ~-84 minecraft:glass
setblock ~-86 ~8 ~-82 minecraft:glass
setblock ~-86 ~10 ~-112 minecraft:glass
setblock ~-86 ~10 ~-110 minecraft:glass
setblock ~-86 ~10 ~-108 minecraft:glass
setblock ~-86 ~10 ~-106 minecraft:glass
setblock ~-86 ~10 ~-104 minecraft:glass
setblock ~-86 ~10 ~-102 minecraft:glass
setblock ~-86 ~10 ~-100 minecraft:glass
setblock ~-86 ~10 ~-98 minecraft:glass
setblock ~-86 ~10 ~-96 minecraft:glass
setblock ~-86 ~10 ~-94 minecraft:glass
setblock ~-86 ~10 ~-92 minecraft:glass
setblock ~-86 ~10 ~-90 minecraft:glass
setblock ~-86 ~10 ~-88 minecraft:glass
setblock ~-86 ~10 ~-86 minecraft:glass
setblock ~-86 ~10 ~-84 minecraft:glass
setblock ~-86 ~10 ~-82 minecraft:glass
setblock ~-86 ~12 ~-112 minecraft:glass
setblock ~-86 ~12 ~-110 minecraft:glass
setblock ~-86 ~12 ~-108 minecraft:glass
setblock ~-86 ~12 ~-106 minecraft:glass
setblock ~-86 ~12 ~-104 minecraft:glass
setblock ~-86 ~12 ~-102 minecraft:glass
setblock ~-86 ~12 ~-100 minecraft:glass
setblock ~-86 ~12 ~-98 minecraft:glass
setblock ~-86 ~12 ~-96 minecraft:glass
setblock ~-86 ~12 ~-94 minecraft:glass
setblock ~-86 ~12 ~-92 minecraft:glass
setblock ~-86 ~12 ~-90 minecraft:glass
setblock ~-86 ~12 ~-88 minecraft:glass
setblock ~-86 ~12 ~-86 minecraft:glass
setblock ~-86 ~12 ~-84 minecraft:glass
setblock ~-86 ~12 ~-82 minecraft:glass
setblock ~-86 ~14 ~-112 minecraft:glass
setblock ~-86 ~14 ~-110 minecraft:glass
setblock ~-86 ~14 ~-108 minecraft:glass
setblock ~-86 ~14 ~-106 minecraft:glass
setblock ~-86 ~14 ~-104 minecraft:glass
setblock ~-86 ~14 ~-102 minecraft:glass
setblock ~-86 ~14 ~-100 minecraft:glass
setblock ~-86 ~14 ~-98 minecraft:glass
setblock ~-86 ~14 ~-96 minecraft:glass
setblock ~-86 ~14 ~-94 minecraft:glass
setblock ~-86 ~14 ~-92 minecraft:glass
setblock ~-86 ~14 ~-90 minecraft:glass
setblock ~-86 ~14 ~-88 minecraft:glass
setblock ~-86 ~14 ~-86 minecraft:glass
setblock ~-86 ~14 ~-84 minecraft:glass
setblock ~-86 ~14 ~-82 minecraft:glass
setblock ~-86 ~16 ~-112 minecraft:glass
setblock ~-86 ~16 ~-110 minecraft:glass
setblock ~-86 ~16 ~-108 minecraft:glass
setblock ~-86 ~16 ~-106 minecraft:glass
setblock ~-86 ~16 ~-104 minecraft:glass
setblock ~-86 ~16 ~-102 minecraft:glass
setblock ~-86 ~16 ~-100 minecraft:glass
setblock ~-86 ~16 ~-98 minecraft:glass
setblock ~-86 ~16 ~-96 minecraft:glass
setblock ~-86 ~16 ~-94 minecraft:glass
setblock ~-86 ~16 ~-92 minecraft:glass
setblock ~-86 ~16 ~-90 minecraft:glass
setblock ~-86 ~16 ~-88 minecraft:glass
setblock ~-86 ~16 ~-86 minecraft:glass
setblock ~-86 ~16 ~-84 minecraft:glass
setblock ~-86 ~16 ~-82 minecraft:glass
setblock ~-86 ~18 ~-112 minecraft:glass
setblock ~-86 ~18 ~-110 minecraft:glass
setblock ~-86 ~18 ~-108 minecraft:glass
setblock ~-86 ~18 ~-106 minecraft:glass
setblock ~-86 ~18 ~-104 minecraft:glass
setblock ~-86 ~18 ~-102 minecraft:glass
setblock ~-86 ~18 ~-100 minecraft:glass
setblock ~-86 ~18 ~-98 minecraft:glass
setblock ~-86 ~18 ~-96 minecraft:glass
setblock ~-86 ~18 ~-94 minecraft:glass
setblock ~-86 ~18 ~-92 minecraft:glass
setblock ~-86 ~18 ~-90 minecraft:glass
setblock ~-86 ~18 ~-88 minecraft:glass
setblock ~-86 ~18 ~-86 minecraft:glass
setblock ~-86 ~18 ~-84 minecraft:glass
setblock ~-86 ~18 ~-82 minecraft:glass
setblock ~-86 ~20 ~-112 minecraft:glass
setblock ~-86 ~20 ~-110 minecraft:glass
setblock ~-86 ~20 ~-108 minecraft:glass
setblock ~-86 ~20 ~-106 minecraft:glass
setblock ~-86 ~20 ~-104 minecraft:glass
setblock ~-86 ~20 ~-102 minecraft:glass
setblock ~-86 ~20 ~-100 minecraft:glass
setblock ~-86 ~20 ~-98 minecraft:glass
setblock ~-86 ~20 ~-96 minecraft:glass
setblock ~-86 ~20 ~-94 minecraft:glass
setblock ~-86 ~20 ~-92 minecraft:glass
setblock ~-86 ~20 ~-90 minecraft:glass
setblock ~-86 ~20 ~-88 minecraft:glass
setblock ~-86 ~20 ~-86 minecraft:glass
setblock ~-86 ~20 ~-84 minecraft:glass
setblock ~-86 ~20 ~-82 minecraft:glass
setblock ~-86 ~22 ~-112 minecraft:glass
setblock ~-86 ~22 ~-110 minecraft:glass
setblock ~-86 ~22 ~-108 minecraft:glass
setblock ~-86 ~22 ~-106 minecraft:glass
setblock ~-86 ~22 ~-104 minecraft:glass
setblock ~-86 ~22 ~-102 minecraft:glass
setblock ~-86 ~22 ~-100 minecraft:glass
setblock ~-86 ~22 ~-98 minecraft:glass
setblock ~-86 ~22 ~-96 minecraft:glass
setblock ~-86 ~22 ~-94 minecraft:glass
setblock ~-86 ~22 ~-92 minecraft:glass
setblock ~-86 ~22 ~-90 minecraft:glass
setblock ~-86 ~22 ~-88 minecraft:glass
setblock ~-86 ~22 ~-86 minecraft:glass
setblock ~-86 ~22 ~-84 minecraft:glass
setblock ~-86 ~22 ~-82 minecraft:glass
setblock ~-86 ~24 ~-112 minecraft:glass
setblock ~-86 ~24 ~-110 minecraft:glass
setblock ~-86 ~24 ~-108 minecraft:glass
setblock ~-86 ~24 ~-106 minecraft:glass
setblock ~-86 ~24 ~-104 minecraft:glass
setblock ~-86 ~24 ~-102 minecraft:glass
setblock ~-86 ~24 ~-100 minecraft:glass
setblock ~-86 ~24 ~-98 minecraft:glass
setblock ~-86 ~24 ~-96 minecraft:glass
setblock ~-86 ~24 ~-94 minecraft:glass
setblock ~-86 ~24 ~-92 minecraft:glass
setblock ~-86 ~24 ~-90 minecraft:glass
setblock ~-86 ~24 ~-88 minecraft:glass
setblock ~-86 ~24 ~-86 minecraft:glass
setblock ~-86 ~24 ~-84 minecraft:glass
setblock ~-86 ~24 ~-82 minecraft:glass
setblock ~-86 ~26 ~-112 minecraft:glass
setblock ~-86 ~26 ~-110 minecraft:glass
setblock ~-86 ~26 ~-108 minecraft:glass
setblock ~-86 ~26 ~-106 minecraft:glass
setblock ~-86 ~26 ~-104 minecraft:glass
setblock ~-86 ~26 ~-102 minecraft:glass
setblock ~-86 ~26 ~-100 minecraft:glass
setblock ~-86 ~26 ~-98 minecraft:glass
setblock ~-86 ~26 ~-96 minecraft:glass
setblock ~-86 ~26 ~-94 minecraft:glass
setblock ~-86 ~26 ~-92 minecraft:glass
setblock ~-86 ~26 ~-90 minecraft:glass
setblock ~-86 ~26 ~-88 minecraft:glass
setblock ~-86 ~26 ~-86 minecraft:glass
setblock ~-86 ~26 ~-84 minecraft:glass
setblock ~-86 ~26 ~-82 minecraft:glass
setblock ~-86 ~28 ~-112 minecraft:glass
setblock ~-86 ~28 ~-110 minecraft:glass
setblock ~-86 ~28 ~-108 minecraft:glass
setblock ~-86 ~28 ~-106 minecraft:glass
setblock ~-86 ~28 ~-104 minecraft:glass
setblock ~-86 ~28 ~-102 minecraft:glass
setblock ~-86 ~28 ~-100 minecraft:glass
setblock ~-86 ~28 ~-98 minecraft:glass
setblock ~-86 ~28 ~-96 minecraft:glass
setblock ~-86 ~28 ~-94 minecraft:glass
setblock ~-86 ~28 ~-92 minecraft:glass
setblock ~-86 ~28 ~-90 minecraft:glass
setblock ~-86 ~28 ~-88 minecraft:glass
setblock ~-86 ~28 ~-86 minecraft:glass
setblock ~-86 ~28 ~-84 minecraft:glass
setblock ~-86 ~28 ~-82 minecraft:glass
setblock ~-86 ~30 ~-112 minecraft:glass
setblock ~-86 ~30 ~-110 minecraft:glass
setblock ~-86 ~30 ~-108 minecraft:glass
setblock ~-86 ~30 ~-106 minecraft:glass
setblock ~-86 ~30 ~-104 minecraft:glass
setblock ~-86 ~30 ~-102 minecraft:glass
setblock ~-86 ~30 ~-100 minecraft:glass
setblock ~-86 ~30 ~-98 minecraft:glass
setblock ~-86 ~30 ~-96 minecraft:glass
setblock ~-86 ~30 ~-94 minecraft:glass
setblock ~-86 ~30 ~-92 minecraft:glass
setblock ~-86 ~30 ~-90 minecraft:glass
setblock ~-86 ~30 ~-88 minecraft:glass
setblock ~-86 ~30 ~-86 minecraft:glass
setblock ~-86 ~30 ~-84 minecraft:glass
setblock ~-86 ~30 ~-82 minecraft:glass
setblock ~-84 ~0 ~-112 minecraft:glass
setblock ~-84 ~0 ~-110 minecraft:glass
setblock ~-84 ~0 ~-108 minecraft:glass
setblock ~-84 ~0 ~-106 minecraft:glass
setblock ~-84 ~0 ~-104 minecraft:glass
setblock ~-84 ~0 ~-102 minecraft:glass
setblock ~-84 ~0 ~-100 minecraft:glass
setblock ~-84 ~0 ~-98 minecraft:glass
setblock ~-84 ~0 ~-96 minecraft:glass
setblock ~-84 ~0 ~-94 minecraft:glass
setblock ~-84 ~0 ~-92 minecraft:glass
setblock ~-84 ~0 ~-90 minecraft:glass
setblock ~-84 ~0 ~-88 minecraft:glass
setblock ~-84 ~0 ~-86 minecraft:glass
setblock ~-84 ~0 ~-84 minecraft:glass
setblock ~-84 ~0 ~-82 minecraft:glass
setblock ~-84 ~2 ~-112 minecraft:glass
setblock ~-84 ~2 ~-110 minecraft:glass
setblock ~-84 ~2 ~-108 minecraft:glass
setblock ~-84 ~2 ~-106 minecraft:glass
setblock ~-84 ~2 ~-104 minecraft:glass
setblock ~-84 ~2 ~-102 minecraft:glass
setblock ~-84 ~2 ~-100 minecraft:glass
setblock ~-84 ~2 ~-98 minecraft:glass
setblock ~-84 ~2 ~-96 minecraft:glass
setblock ~-84 ~2 ~-94 minecraft:glass
setblock ~-84 ~2 ~-92 minecraft:glass
setblock ~-84 ~2 ~-90 minecraft:glass
setblock ~-84 ~2 ~-88 minecraft:glass
setblock ~-84 ~2 ~-86 minecraft:glass
setblock ~-84 ~2 ~-84 minecraft:glass
setblock ~-84 ~2 ~-82 minecraft:glass
setblock ~-84 ~4 ~-112 minecraft:glass
setblock ~-84 ~4 ~-110 minecraft:glass
setblock ~-84 ~4 ~-108 minecraft:glass
setblock ~-84 ~4 ~-106 minecraft:glass
setblock ~-84 ~4 ~-104 minecraft:glass
setblock ~-84 ~4 ~-102 minecraft:glass
setblock ~-84 ~4 ~-100 minecraft:glass
setblock ~-84 ~4 ~-98 minecraft:glass
setblock ~-84 ~4 ~-96 minecraft:glass
setblock ~-84 ~4 ~-94 minecraft:glass
setblock ~-84 ~4 ~-92 minecraft:glass
setblock ~-84 ~4 ~-90 minecraft:glass
setblock ~-84 ~4 ~-88 minecraft:glass
setblock ~-84 ~4 ~-86 minecraft:glass
setblock ~-84 ~4 ~-84 minecraft:glass
setblock ~-84 ~4 ~-82 minecraft:glass
setblock ~-84 ~6 ~-112 minecraft:glass
setblock ~-84 ~6 ~-110 minecraft:glass
setblock ~-84 ~6 ~-108 minecraft:glass
setblock ~-84 ~6 ~-106 minecraft:glass
setblock ~-84 ~6 ~-104 minecraft:glass
setblock ~-84 ~6 ~-102 minecraft:glass
setblock ~-84 ~6 ~-100 minecraft:glass
setblock ~-84 ~6 ~-98 minecraft:glass
setblock ~-84 ~6 ~-96 minecraft:glass
setblock ~-84 ~6 ~-94 minecraft:glass
setblock ~-84 ~6 ~-92 minecraft:glass
setblock ~-84 ~6 ~-90 minecraft:glass
setblock ~-84 ~6 ~-88 minecraft:glass
setblock ~-84 ~6 ~-86 minecraft:glass
setblock ~-84 ~6 ~-84 minecraft:glass
setblock ~-84 ~6 ~-82 minecraft:glass
setblock ~-84 ~8 ~-112 minecraft:glass
setblock ~-84 ~8 ~-110 minecraft:glass
setblock ~-84 ~8 ~-108 minecraft:glass
setblock ~-84 ~8 ~-106 minecraft:glass
setblock ~-84 ~8 ~-104 minecraft:glass
setblock ~-84 ~8 ~-102 minecraft:glass
setblock ~-84 ~8 ~-100 minecraft:glass
setblock ~-84 ~8 ~-98 minecraft:glass
setblock ~-84 ~8 ~-96 minecraft:glass
setblock ~-84 ~8 ~-94 minecraft:glass
setblock ~-84 ~8 ~-92 minecraft:glass
setblock ~-84 ~8 ~-90 minecraft:glass
setblock ~-84 ~8 ~-88 minecraft:glass
setblock ~-84 ~8 ~-86 minecraft:glass
setblock ~-84 ~8 ~-84 minecraft:glass
setblock ~-84 ~8 ~-82 minecraft:glass
setblock ~-84 ~10 ~-112 minecraft:glass
setblock ~-84 ~10 ~-110 minecraft:glass
setblock ~-84 ~10 ~-108 minecraft:glass
setblock ~-84 ~10 ~-106 minecraft:glass
setblock ~-84 ~10 ~-104 minecraft:glass
setblock ~-84 ~10 ~-102 minecraft:glass
setblock ~-84 ~10 ~-100 minecraft:glass
setblock ~-84 ~10 ~-98 minecraft:glass
setblock ~-84 ~10 ~-96 minecraft:glass
setblock ~-84 ~10 ~-94 minecraft:glass
setblock ~-84 ~10 ~-92 minecraft:glass
setblock ~-84 ~10 ~-90 minecraft:glass
setblock ~-84 ~10 ~-88 minecraft:glass
setblock ~-84 ~10 ~-86 minecraft:glass
setblock ~-84 ~10 ~-84 minecraft:glass
setblock ~-84 ~10 ~-82 minecraft:glass
setblock ~-84 ~12 ~-112 minecraft:glass
setblock ~-84 ~12 ~-110 minecraft:glass
setblock ~-84 ~12 ~-108 minecraft:glass
setblock ~-84 ~12 ~-106 minecraft:glass
setblock ~-84 ~12 ~-104 minecraft:glass
setblock ~-84 ~12 ~-102 minecraft:glass
setblock ~-84 ~12 ~-100 minecraft:glass
setblock ~-84 ~12 ~-98 minecraft:glass
setblock ~-84 ~12 ~-96 minecraft:glass
setblock ~-84 ~12 ~-94 minecraft:glass
setblock ~-84 ~12 ~-92 minecraft:glass
setblock ~-84 ~12 ~-90 minecraft:glass
setblock ~-84 ~12 ~-88 minecraft:glass
setblock ~-84 ~12 ~-86 minecraft:glass
setblock ~-84 ~12 ~-84 minecraft:glass
setblock ~-84 ~12 ~-82 minecraft:glass
setblock ~-84 ~14 ~-112 minecraft:glass
setblock ~-84 ~14 ~-110 minecraft:glass
setblock ~-84 ~14 ~-108 minecraft:glass
setblock ~-84 ~14 ~-106 minecraft:glass
setblock ~-84 ~14 ~-104 minecraft:glass
setblock ~-84 ~14 ~-102 minecraft:glass
setblock ~-84 ~14 ~-100 minecraft:glass
setblock ~-84 ~14 ~-98 minecraft:glass
setblock ~-84 ~14 ~-96 minecraft:glass
setblock ~-84 ~14 ~-94 minecraft:glass
setblock ~-84 ~14 ~-92 minecraft:glass
setblock ~-84 ~14 ~-90 minecraft:glass
setblock ~-84 ~14 ~-88 minecraft:glass
setblock ~-84 ~14 ~-86 minecraft:glass
setblock ~-84 ~14 ~-84 minecraft:glass
setblock ~-84 ~14 ~-82 minecraft:glass
setblock ~-84 ~16 ~-112 minecraft:glass
setblock ~-84 ~16 ~-110 minecraft:glass
setblock ~-84 ~16 ~-108 minecraft:glass
setblock ~-84 ~16 ~-106 minecraft:glass
setblock ~-84 ~16 ~-104 minecraft:glass
setblock ~-84 ~16 ~-102 minecraft:glass
setblock ~-84 ~16 ~-100 minecraft:glass
setblock ~-84 ~16 ~-98 minecraft:glass
setblock ~-84 ~16 ~-96 minecraft:glass
setblock ~-84 ~16 ~-94 minecraft:glass
setblock ~-84 ~16 ~-92 minecraft:glass
setblock ~-84 ~16 ~-90 minecraft:glass
setblock ~-84 ~16 ~-88 minecraft:glass
setblock ~-84 ~16 ~-86 minecraft:glass
setblock ~-84 ~16 ~-84 minecraft:glass
setblock ~-84 ~16 ~-82 minecraft:glass
setblock ~-84 ~18 ~-112 minecraft:glass
setblock ~-84 ~18 ~-110 minecraft:glass
setblock ~-84 ~18 ~-108 minecraft:glass
setblock ~-84 ~18 ~-106 minecraft:glass
setblock ~-84 ~18 ~-104 minecraft:glass
setblock ~-84 ~18 ~-102 minecraft:glass
setblock ~-84 ~18 ~-100 minecraft:glass
setblock ~-84 ~18 ~-98 minecraft:glass
setblock ~-84 ~18 ~-96 minecraft:glass
setblock ~-84 ~18 ~-94 minecraft:glass
setblock ~-84 ~18 ~-92 minecraft:glass
setblock ~-84 ~18 ~-90 minecraft:glass
setblock ~-84 ~18 ~-88 minecraft:glass
setblock ~-84 ~18 ~-86 minecraft:glass
setblock ~-84 ~18 ~-84 minecraft:glass
setblock ~-84 ~18 ~-82 minecraft:glass
setblock ~-84 ~20 ~-112 minecraft:glass
setblock ~-84 ~20 ~-110 minecraft:glass
setblock ~-84 ~20 ~-108 minecraft:glass
setblock ~-84 ~20 ~-106 minecraft:glass
setblock ~-84 ~20 ~-104 minecraft:glass
setblock ~-84 ~20 ~-102 minecraft:glass
setblock ~-84 ~20 ~-100 minecraft:glass
setblock ~-84 ~20 ~-98 minecraft:glass
setblock ~-84 ~20 ~-96 minecraft:glass
setblock ~-84 ~20 ~-94 minecraft:glass
setblock ~-84 ~20 ~-92 minecraft:glass
setblock ~-84 ~20 ~-90 minecraft:glass
setblock ~-84 ~20 ~-88 minecraft:glass
setblock ~-84 ~20 ~-86 minecraft:glass
setblock ~-84 ~20 ~-84 minecraft:glass
setblock ~-84 ~20 ~-82 minecraft:glass
setblock ~-84 ~22 ~-112 minecraft:glass
setblock ~-84 ~22 ~-110 minecraft:glass
setblock ~-84 ~22 ~-108 minecraft:glass
setblock ~-84 ~22 ~-106 minecraft:glass
setblock ~-84 ~22 ~-104 minecraft:glass
setblock ~-84 ~22 ~-102 minecraft:glass
setblock ~-84 ~22 ~-100 minecraft:glass
setblock ~-84 ~22 ~-98 minecraft:glass
setblock ~-84 ~22 ~-96 minecraft:glass
setblock ~-84 ~22 ~-94 minecraft:glass
setblock ~-84 ~22 ~-92 minecraft:glass
setblock ~-84 ~22 ~-90 minecraft:glass
setblock ~-84 ~22 ~-88 minecraft:glass
setblock ~-84 ~22 ~-86 minecraft:glass
setblock ~-84 ~22 ~-84 minecraft:glass
setblock ~-84 ~22 ~-82 minecraft:glass
setblock ~-84 ~24 ~-112 minecraft:glass
setblock ~-84 ~24 ~-110 minecraft:glass
setblock ~-84 ~24 ~-108 minecraft:glass
setblock ~-84 ~24 ~-106 minecraft:glass
setblock ~-84 ~24 ~-104 minecraft:glass
setblock ~-84 ~24 ~-102 minecraft:glass
setblock ~-84 ~24 ~-100 minecraft:glass
setblock ~-84 ~24 ~-98 minecraft:glass
setblock ~-84 ~24 ~-96 minecraft:glass
setblock ~-84 ~24 ~-94 minecraft:glass
setblock ~-84 ~24 ~-92 minecraft:glass
setblock ~-84 ~24 ~-90 minecraft:glass
setblock ~-84 ~24 ~-88 minecraft:glass
setblock ~-84 ~24 ~-86 minecraft:glass
setblock ~-84 ~24 ~-84 minecraft:glass
setblock ~-84 ~24 ~-82 minecraft:glass
setblock ~-84 ~26 ~-112 minecraft:glass
setblock ~-84 ~26 ~-110 minecraft:glass
setblock ~-84 ~26 ~-108 minecraft:glass
setblock ~-84 ~26 ~-106 minecraft:glass
setblock ~-84 ~26 ~-104 minecraft:glass
setblock ~-84 ~26 ~-102 minecraft:glass
setblock ~-84 ~26 ~-100 minecraft:glass
setblock ~-84 ~26 ~-98 minecraft:glass
setblock ~-84 ~26 ~-96 minecraft:glass
setblock ~-84 ~26 ~-94 minecraft:glass
setblock ~-84 ~26 ~-92 minecraft:glass
setblock ~-84 ~26 ~-90 minecraft:glass
setblock ~-84 ~26 ~-88 minecraft:glass
setblock ~-84 ~26 ~-86 minecraft:glass
setblock ~-84 ~26 ~-84 minecraft:glass
setblock ~-84 ~26 ~-82 minecraft:glass
setblock ~-84 ~28 ~-112 minecraft:glass
setblock ~-84 ~28 ~-110 minecraft:glass
setblock ~-84 ~28 ~-108 minecraft:glass
setblock ~-84 ~28 ~-106 minecraft:glass
setblock ~-84 ~28 ~-104 minecraft:glass
setblock ~-84 ~28 ~-102 minecraft:glass
setblock ~-84 ~28 ~-100 minecraft:glass
setblock ~-84 ~28 ~-98 minecraft:glass
setblock ~-84 ~28 ~-96 minecraft:glass
setblock ~-84 ~28 ~-94 minecraft:glass
setblock ~-84 ~28 ~-92 minecraft:glass
setblock ~-84 ~28 ~-90 minecraft:glass
setblock ~-84 ~28 ~-88 minecraft:glass
setblock ~-84 ~28 ~-86 minecraft:glass
setblock ~-84 ~28 ~-84 minecraft:glass
setblock ~-84 ~28 ~-82 minecraft:glass
setblock ~-84 ~30 ~-112 minecraft:glass
setblock ~-84 ~30 ~-110 minecraft:glass
setblock ~-84 ~30 ~-108 minecraft:glass
setblock ~-84 ~30 ~-106 minecraft:glass
setblock ~-84 ~30 ~-104 minecraft:glass
setblock ~-84 ~30 ~-102 minecraft:glass
setblock ~-84 ~30 ~-100 minecraft:glass
setblock ~-84 ~30 ~-98 minecraft:glass
setblock ~-84 ~30 ~-96 minecraft:glass
setblock ~-84 ~30 ~-94 minecraft:glass
setblock ~-84 ~30 ~-92 minecraft:glass
setblock ~-84 ~30 ~-90 minecraft:glass
setblock ~-84 ~30 ~-88 minecraft:glass
setblock ~-84 ~30 ~-86 minecraft:glass
setblock ~-84 ~30 ~-84 minecraft:glass
setblock ~-84 ~30 ~-82 minecraft:glass
setblock ~-82 ~0 ~-112 minecraft:glass
setblock ~-82 ~0 ~-110 minecraft:glass
setblock ~-82 ~0 ~-108 minecraft:glass
setblock ~-82 ~0 ~-106 minecraft:glass
setblock ~-82 ~0 ~-104 minecraft:glass
setblock ~-82 ~0 ~-102 minecraft:glass
setblock ~-82 ~0 ~-100 minecraft:glass
setblock ~-82 ~0 ~-98 minecraft:glass
setblock ~-82 ~0 ~-96 minecraft:glass
setblock ~-82 ~0 ~-94 minecraft:glass
setblock ~-82 ~0 ~-92 minecraft:glass
setblock ~-82 ~0 ~-90 minecraft:glass
setblock ~-82 ~0 ~-88 minecraft:glass
setblock ~-82 ~0 ~-86 minecraft:glass
setblock ~-82 ~0 ~-84 minecraft:glass
setblock ~-82 ~0 ~-82 minecraft:glass
setblock ~-82 ~2 ~-112 minecraft:glass
setblock ~-82 ~2 ~-110 minecraft:glass
setblock ~-82 ~2 ~-108 minecraft:glass
setblock ~-82 ~2 ~-106 minecraft:glass
setblock ~-82 ~2 ~-104 minecraft:glass
setblock ~-82 ~2 ~-102 minecraft:glass
setblock ~-82 ~2 ~-100 minecraft:glass
setblock ~-82 ~2 ~-98 minecraft:glass
setblock ~-82 ~2 ~-96 minecraft:glass
setblock ~-82 ~2 ~-94 minecraft:glass
setblock ~-82 ~2 ~-92 minecraft:glass
setblock ~-82 ~2 ~-90 minecraft:glass
setblock ~-82 ~2 ~-88 minecraft:glass
setblock ~-82 ~2 ~-86 minecraft:glass
setblock ~-82 ~2 ~-84 minecraft:glass
setblock ~-82 ~2 ~-82 minecraft:glass
setblock ~-82 ~4 ~-112 minecraft:glass
setblock ~-82 ~4 ~-110 minecraft:glass
setblock ~-82 ~4 ~-108 minecraft:glass
setblock ~-82 ~4 ~-106 minecraft:glass
setblock ~-82 ~4 ~-104 minecraft:glass
setblock ~-82 ~4 ~-102 minecraft:glass
setblock ~-82 ~4 ~-100 minecraft:glass
setblock ~-82 ~4 ~-98 minecraft:glass
setblock ~-82 ~4 ~-96 minecraft:glass
setblock ~-82 ~4 ~-94 minecraft:glass
setblock ~-82 ~4 ~-92 minecraft:glass
setblock ~-82 ~4 ~-90 minecraft:glass
setblock ~-82 ~4 ~-88 minecraft:glass
setblock ~-82 ~4 ~-86 minecraft:glass
setblock ~-82 ~4 ~-84 minecraft:glass
setblock ~-82 ~4 ~-82 minecraft:glass
setblock ~-82 ~6 ~-112 minecraft:glass
setblock ~-82 ~6 ~-110 minecraft:glass
setblock ~-82 ~6 ~-108 minecraft:glass
setblock ~-82 ~6 ~-106 minecraft:glass
setblock ~-82 ~6 ~-104 minecraft:glass
setblock ~-82 ~6 ~-102 minecraft:glass
setblock ~-82 ~6 ~-100 minecraft:glass
setblock ~-82 ~6 ~-98 minecraft:glass
setblock ~-82 ~6 ~-96 minecraft:glass
setblock ~-82 ~6 ~-94 minecraft:glass
setblock ~-82 ~6 ~-92 minecraft:glass
setblock ~-82 ~6 ~-90 minecraft:glass
setblock ~-82 ~6 ~-88 minecraft:glass
setblock ~-82 ~6 ~-86 minecraft:glass
setblock ~-82 ~6 ~-84 minecraft:glass
setblock ~-82 ~6 ~-82 minecraft:glass
setblock ~-82 ~8 ~-112 minecraft:glass
setblock ~-82 ~8 ~-110 minecraft:glass
setblock ~-82 ~8 ~-108 minecraft:glass
setblock ~-82 ~8 ~-106 minecraft:glass
setblock ~-82 ~8 ~-104 minecraft:glass
setblock ~-82 ~8 ~-102 minecraft:glass
setblock ~-82 ~8 ~-100 minecraft:glass
setblock ~-82 ~8 ~-98 minecraft:glass
setblock ~-82 ~8 ~-96 minecraft:glass
setblock ~-82 ~8 ~-94 minecraft:glass
setblock ~-82 ~8 ~-92 minecraft:glass
setblock ~-82 ~8 ~-90 minecraft:glass
setblock ~-82 ~8 ~-88 minecraft:glass
setblock ~-82 ~8 ~-86 minecraft:glass
setblock ~-82 ~8 ~-84 minecraft:glass
setblock ~-82 ~8 ~-82 minecraft:glass
setblock ~-82 ~10 ~-112 minecraft:glass
setblock ~-82 ~10 ~-110 minecraft:glass
setblock ~-82 ~10 ~-108 minecraft:glass
setblock ~-82 ~10 ~-106 minecraft:glass
setblock ~-82 ~10 ~-104 minecraft:glass
setblock ~-82 ~10 ~-102 minecraft:glass
setblock ~-82 ~10 ~-100 minecraft:glass
setblock ~-82 ~10 ~-98 minecraft:glass
setblock ~-82 ~10 ~-96 minecraft:glass
setblock ~-82 ~10 ~-94 minecraft:glass
setblock ~-82 ~10 ~-92 minecraft:glass
setblock ~-82 ~10 ~-90 minecraft:glass
setblock ~-82 ~10 ~-88 minecraft:glass
setblock ~-82 ~10 ~-86 minecraft:glass
setblock ~-82 ~10 ~-84 minecraft:glass
setblock ~-82 ~10 ~-82 minecraft:glass
setblock ~-82 ~12 ~-112 minecraft:glass
setblock ~-82 ~12 ~-110 minecraft:glass
setblock ~-82 ~12 ~-108 minecraft:glass
setblock ~-82 ~12 ~-106 minecraft:glass
setblock ~-82 ~12 ~-104 minecraft:glass
setblock ~-82 ~12 ~-102 minecraft:glass
setblock ~-82 ~12 ~-100 minecraft:glass
setblock ~-82 ~12 ~-98 minecraft:glass
setblock ~-82 ~12 ~-96 minecraft:glass
setblock ~-82 ~12 ~-94 minecraft:glass
setblock ~-82 ~12 ~-92 minecraft:glass
setblock ~-82 ~12 ~-90 minecraft:glass
setblock ~-82 ~12 ~-88 minecraft:glass
setblock ~-82 ~12 ~-86 minecraft:glass
setblock ~-82 ~12 ~-84 minecraft:glass
setblock ~-82 ~12 ~-82 minecraft:glass
setblock ~-82 ~14 ~-112 minecraft:glass
setblock ~-82 ~14 ~-110 minecraft:glass
setblock ~-82 ~14 ~-108 minecraft:glass
setblock ~-82 ~14 ~-106 minecraft:glass
setblock ~-82 ~14 ~-104 minecraft:glass
setblock ~-82 ~14 ~-102 minecraft:glass
setblock ~-82 ~14 ~-100 minecraft:glass
setblock ~-82 ~14 ~-98 minecraft:glass
setblock ~-82 ~14 ~-96 minecraft:glass
setblock ~-82 ~14 ~-94 minecraft:glass
setblock ~-82 ~14 ~-92 minecraft:glass
setblock ~-82 ~14 ~-90 minecraft:glass
setblock ~-82 ~14 ~-88 minecraft:glass
setblock ~-82 ~14 ~-86 minecraft:glass
setblock ~-82 ~14 ~-84 minecraft:glass
setblock ~-82 ~14 ~-82 minecraft:glass
setblock ~-82 ~16 ~-112 minecraft:glass
setblock ~-82 ~16 ~-110 minecraft:glass
setblock ~-82 ~16 ~-108 minecraft:glass
setblock ~-82 ~16 ~-106 minecraft:glass
setblock ~-82 ~16 ~-104 minecraft:glass
setblock ~-82 ~16 ~-102 minecraft:glass
setblock ~-82 ~16 ~-100 minecraft:glass
setblock ~-82 ~16 ~-98 minecraft:glass
setblock ~-82 ~16 ~-96 minecraft:glass
setblock ~-82 ~16 ~-94 minecraft:glass
setblock ~-82 ~16 ~-92 minecraft:glass
setblock ~-82 ~16 ~-90 minecraft:glass
setblock ~-82 ~16 ~-88 minecraft:glass
setblock ~-82 ~16 ~-86 minecraft:glass
setblock ~-82 ~16 ~-84 minecraft:glass
setblock ~-82 ~16 ~-82 minecraft:glass
setblock ~-82 ~18 ~-112 minecraft:glass
setblock ~-82 ~18 ~-110 minecraft:glass
setblock ~-82 ~18 ~-108 minecraft:glass
setblock ~-82 ~18 ~-106 minecraft:glass
setblock ~-82 ~18 ~-104 minecraft:glass
setblock ~-82 ~18 ~-102 minecraft:glass
setblock ~-82 ~18 ~-100 minecraft:glass
setblock ~-82 ~18 ~-98 minecraft:glass
setblock ~-82 ~18 ~-96 minecraft:glass
setblock ~-82 ~18 ~-94 minecraft:glass
setblock ~-82 ~18 ~-92 minecraft:glass
setblock ~-82 ~18 ~-90 minecraft:glass
setblock ~-82 ~18 ~-88 minecraft:glass
setblock ~-82 ~18 ~-86 minecraft:glass
setblock ~-82 ~18 ~-84 minecraft:glass
setblock ~-82 ~18 ~-82 minecraft:glass
setblock ~-82 ~20 ~-112 minecraft:glass
setblock ~-82 ~20 ~-110 minecraft:glass
setblock ~-82 ~20 ~-108 minecraft:glass
setblock ~-82 ~20 ~-106 minecraft:glass
setblock ~-82 ~20 ~-104 minecraft:glass
setblock ~-82 ~20 ~-102 minecraft:glass
setblock ~-82 ~20 ~-100 minecraft:glass
setblock ~-82 ~20 ~-98 minecraft:glass
setblock ~-82 ~20 ~-96 minecraft:glass
setblock ~-82 ~20 ~-94 minecraft:glass
setblock ~-82 ~20 ~-92 minecraft:glass
setblock ~-82 ~20 ~-90 minecraft:glass
setblock ~-82 ~20 ~-88 minecraft:glass
setblock ~-82 ~20 ~-86 minecraft:glass
setblock ~-82 ~20 ~-84 minecraft:glass
setblock ~-82 ~20 ~-82 minecraft:glass
setblock ~-82 ~22 ~-112 minecraft:glass
setblock ~-82 ~22 ~-110 minecraft:glass
setblock ~-82 ~22 ~-108 minecraft:glass
setblock ~-82 ~22 ~-106 minecraft:glass
setblock ~-82 ~22 ~-104 minecraft:glass
setblock ~-82 ~22 ~-102 minecraft:glass
setblock ~-82 ~22 ~-100 minecraft:glass
setblock ~-82 ~22 ~-98 minecraft:glass
setblock ~-82 ~22 ~-96 minecraft:glass
setblock ~-82 ~22 ~-94 minecraft:glass
setblock ~-82 ~22 ~-92 minecraft:glass
setblock ~-82 ~22 ~-90 minecraft:glass
setblock ~-82 ~22 ~-88 minecraft:glass
setblock ~-82 ~22 ~-86 minecraft:glass
setblock ~-82 ~22 ~-84 minecraft:glass
setblock ~-82 ~22 ~-82 minecraft:glass
setblock ~-82 ~24 ~-112 minecraft:glass
setblock ~-82 ~24 ~-110 minecraft:glass
setblock ~-82 ~24 ~-108 minecraft:glass
setblock ~-82 ~24 ~-106 minecraft:glass
setblock ~-82 ~24 ~-104 minecraft:glass
setblock ~-82 ~24 ~-102 minecraft:glass
setblock ~-82 ~24 ~-100 minecraft:glass
setblock ~-82 ~24 ~-98 minecraft:glass
setblock ~-82 ~24 ~-96 minecraft:glass
setblock ~-82 ~24 ~-94 minecraft:glass
setblock ~-82 ~24 ~-92 minecraft:glass
setblock ~-82 ~24 ~-90 minecraft:glass
setblock ~-82 ~24 ~-88 minecraft:glass
setblock ~-82 ~24 ~-86 minecraft:glass
setblock ~-82 ~24 ~-84 minecraft:glass
setblock ~-82 ~24 ~-82 minecraft:glass
setblock ~-82 ~26 ~-112 minecraft:glass
setblock ~-82 ~26 ~-110 minecraft:glass
setblock ~-82 ~26 ~-108 minecraft:glass
setblock ~-82 ~26 ~-106 minecraft:glass
setblock ~-82 ~26 ~-104 minecraft:glass
setblock ~-82 ~26 ~-102 minecraft:glass
setblock ~-82 ~26 ~-100 minecraft:glass
setblock ~-82 ~26 ~-98 minecraft:glass
setblock ~-82 ~26 ~-96 minecraft:glass
setblock ~-82 ~26 ~-94 minecraft:glass
setblock ~-82 ~26 ~-92 minecraft:glass
setblock ~-82 ~26 ~-90 minecraft:glass
setblock ~-82 ~26 ~-88 minecraft:glass
setblock ~-82 ~26 ~-86 minecraft:glass
setblock ~-82 ~26 ~-84 minecraft:glass
setblock ~-82 ~26 ~-82 minecraft:glass
setblock ~-82 ~28 ~-112 minecraft:glass
setblock ~-82 ~28 ~-110 minecraft:glass
setblock ~-82 ~28 ~-108 minecraft:glass
setblock ~-82 ~28 ~-106 minecraft:glass
setblock ~-82 ~28 ~-104 minecraft:glass
setblock ~-82 ~28 ~-102 minecraft:glass
setblock ~-82 ~28 ~-100 minecraft:glass
setblock ~-82 ~28 ~-98 minecraft:glass
setblock ~-82 ~28 ~-96 minecraft:glass
setblock ~-82 ~28 ~-94 minecraft:glass
setblock ~-82 ~28 ~-92 minecraft:glass
setblock ~-82 ~28 ~-90 minecraft:glass
setblock ~-82 ~28 ~-88 minecraft:glass
setblock ~-82 ~28 ~-86 minecraft:glass
setblock ~-82 ~28 ~-84 minecraft:glass
setblock ~-82 ~28 ~-82 minecraft:glass
setblock ~-82 ~30 ~-112 minecraft:glass
setblock ~-82 ~30 ~-110 minecraft:glass
setblock ~-82 ~30 ~-108 minecraft:glass
setblock ~-82 ~30 ~-106 minecraft:glass
setblock ~-82 ~30 ~-104 minecraft:glass
setblock ~-82 ~30 ~-102 minecraft:glass
setblock ~-82 ~30 ~-100 minecraft:glass
setblock ~-82 ~30 ~-98 minecraft:glass
setblock ~-82 ~30 ~-96 minecraft:glass
setblock ~-82 ~30 ~-94 minecraft:glass
setblock ~-82 ~30 ~-92 minecraft:glass
setblock ~-82 ~30 ~-90 minecraft:glass
setblock ~-82 ~30 ~-88 minecraft:glass
setblock ~-82 ~30 ~-86 minecraft:glass
setblock ~-82 ~30 ~-84 minecraft:glass
setblock ~-82 ~30 ~-82 minecraft:glass
setblock ~-104 ~17 ~-90 minecraft:lantern[hanging=true]
setblock ~-112 ~27 ~-82 minecraft:lantern[hanging=true]
setblock ~-82 ~1 ~-104 minecraft:lantern
setblock ~-88 ~11 ~-88 minecraft:lantern[hanging=true]
setblock ~-96 ~23 ~-106 minecraft:lantern
setblock ~-96 ~7 ~-86 minecraft:lantern[hanging=true]
setblock ~-84 ~17 ~-84 minecraft:lantern
setblock ~-100 ~9 ~-82 minecraft:lantern[hanging=true]
setblock ~-100 ~29 ~-108 minecraft:lantern[hanging=true]
setblock ~-112 ~17 ~-90 minecraft:lantern
setblock ~-82 ~21 ~-102 minecraft:lantern[hanging=true]
setblock ~-108 ~11 ~-84 minecraft:lantern[hanging=true]
setblock ~-108 ~21 ~-90 minecraft:lantern[hanging=true]
setblock ~-86 ~19 ~-98 minecraft:lantern[hanging=true]
setblock ~-98 ~1 ~-90 minecraft:lantern
setblock ~-84 ~5 ~-94 minecraft:lantern[hanging=true]
setblock ~-106 ~3 ~-84 minecraft:lantern
setblock ~-102 ~27 ~-94 minecraft:lantern[hanging=true]
setblock ~-98 ~15 ~-96 minecraft:lantern[hanging=true]
setblock ~-92 ~23 ~-98 minecraft:lantern[hanging=true]
setblock ~-112 ~1 ~-104 minecraft:lantern
setblock ~-112 ~17 ~-88 minecraft:lantern
setblock ~-94 ~9 ~-104 minecraft:lantern[hanging=true]
setblock ~-100 ~19 ~-110 minecraft:lantern[hanging=true]
setblock ~-98 ~15 ~-110 minecraft:lantern
setblock ~-112 ~5 ~-86 minecraft:lantern
setblock ~-104 ~1 ~-90 minecraft:lantern[hanging=true]
setblock ~-110 ~5 ~-88 minecraft:lantern[hanging=true]
setblock ~-108 ~27 ~-94 minecraft:lantern[hanging=true]
setblock ~-96 ~7 ~-102 minecraft:lantern[hanging=true]
setblock ~-106 ~29 ~-112 minecraft:lantern[hanging=true]
setblock ~-92 ~21 ~-112 minecraft:lantern
setblock ~-104 ~21 ~-106 minecraft:lantern[hanging=true]
setblock ~-96 ~11 ~-110 minecraft:lantern[hanging=true]
setblock ~-86 ~9 ~-106 minecraft:lantern
setblock ~-96 ~15 ~-88 minecraft:lantern[hanging=true]
setblock ~-98 ~3 ~-98 minecraft:lantern
setblock ~-108 ~3 ~-98 minecraft:lantern
setblock ~-84 ~19 ~-96 minecraft:lantern[hanging=true]
setblock ~-112 ~17 ~-94 minecraft:lantern[hanging=true]
setblock ~-82 ~11 ~-112 minecraft:lantern[hanging=true]
setblock ~-92 ~17 ~-100 minecraft:lantern
setblock ~-82 ~9 ~-108 minecraft:lantern[hanging=true]
setblock ~-100 ~13 ~-86 minecraft:lantern[hanging=true]
setblock ~-110 ~17 ~-102 minecraft:lantern
setblock ~-94 ~25 ~-100 minecraft:lantern
setblock ~-100 ~23 ~-110 minecraft:lantern[hanging=true]
setblock ~-90 ~13 ~-86 minecraft:lantern
setblock ~-82 ~7 ~-98 minecraft:lantern[hanging=true]
setblock ~-82 ~1 ~-92 minecraft:lantern[hanging=true]
setblock ~-100 ~7 ~-90 minecraft:lantern
setblock ~-94 ~9 ~-106 minecraft:lantern[hanging=true]
setblock ~-108 ~7 ~-90 minecraft:lantern[hanging=true]
setblock ~-108 ~13 ~-100 minecraft:lantern
setblock ~-100 ~23 ~-92 minecraft:lantern
setblock ~-96 ~27 ~-106 minecraft:lantern[hanging=true]
setblock ~-90 ~13 ~-98 minecraft:lantern
setblock ~-94 ~1 ~-90 minecraft:lantern
setblock ~-88 ~1 ~-110 minecraft:lantern[hanging=true]
setblock ~-106 ~1 ~-82 minecraft:lantern
setblock ~-104 ~23 ~-92 minecraft:lantern
setblock ~-110 ~17 ~-90 minecraft:lantern[hanging=true]
setblock ~-102 ~15 ~-98 minecraft:lantern[hanging=true]
setblock ~-106 ~5 ~-106 minecraft:lantern
setblock ~-86 ~13 ~-94 minecraft:lantern[hanging=true]
setblock ~-90 ~27 ~-96 minecraft:lantern
setblock ~-98 ~7 ~-100 minecraft:lantern[hanging=true]
setblock ~-86 ~25 ~-82 minecraft:lantern[hanging=true]
setblock ~-94 ~19 ~-112 minecraft:lantern[hanging=true]
setblock ~-90 ~7 ~-110 minecraft:lantern[hanging=true]
setblock ~-88 ~7 ~-106 minecraft:lantern[hanging=true]
setblock ~-98 ~9 ~-106 minecraft:lantern[hanging=true]
setblock ~-92 ~7 ~-104 minecraft:lantern
setblock ~-112 ~15 ~-104 minecraft:lantern[hanging=true]
setblock ~-106 ~13 ~-92 minecraft:lantern
setblock ~-112 ~3 ~-110 minecraft:lantern
setblock ~-106 ~15 ~-102 minecraft:lantern[hanging=true]
setblock ~-90 ~5 ~-92 minecraft:lantern[hanging=true]
setblock ~-88 ~9 ~-96 minecraft:lantern[hanging=true]
setblock ~-94 ~1 ~-94 minecraft:lantern[hanging=true]
setblock ~-98 ~23 ~-84 minecraft:lantern[hanging=true]
setblock ~-108 ~9 ~-106 minecraft:lantern
setblock ~-108 ~27 ~-84 minecraft:lantern[hanging=true]
setblock ~-88 ~11 ~-108 minecraft:lantern
setblock ~-108 ~3 ~-94 minecraft:lantern[hanging=true]
setblock ~-86 ~1 ~-110 minecraft:lantern[hanging=true]
setblock ~-106 ~3 ~-110 minecraft:lantern
setblock ~-110 ~15 ~-102 minecraft:lantern
setblock ~-108 ~5 ~-84 minecraft:lantern[hanging=true]
setblock ~-92 ~7 ~-98 minecraft:lantern[hanging=true]
setblock ~-106 ~21 ~-86 minecraft:lantern
setblock ~-102 ~7 ~-94 minecraft:lantern[hanging=true]
setblock ~-106 ~13 ~-106 minecraft:lantern
setblock ~-94 ~15 ~-112 minecraft:lantern[hanging=true]
setblock ~-94 ~21 ~-86 minecraft:lantern[hanging=true]
setblock ~-98 ~9 ~-84 minecraft:lantern[hanging=true]
setblock ~-110 ~7 ~-94 minecraft:lantern
setblock ~-94 ~11 ~-104 minecraft:lantern
setblock ~-108 ~27 ~-104 minecraft:lantern[hanging=true]
setblock ~-88 ~21 ~-96 minecraft:lantern[hanging=true]
setblock ~-88 ~5 ~-104 minecraft:lantern
setblock ~-86 ~9 ~-88 minecraft:lantern
setblock ~-106 ~19 ~-94 minecraft:lantern
setblock ~-108 ~17 ~-102 minecraft:lantern
setblock ~-96 ~17 ~-86 minecraft:lantern
setblock ~-84 ~5 ~-82 minecraft:lantern
setblock ~-84 ~17 ~-100 minecraft:lantern[hanging=true]
setblock ~-106 ~29 ~-108 minecraft:lantern[hanging=true]
setblock ~-86 ~29 ~-84 minecraft:lantern[hanging=true]
setblock ~-94 ~19 ~-106 minecraft:lantern[hanging=true]
setblock ~-98 ~21 ~-82 minecraft:lantern[hanging=true]
setblock ~-92 ~5 ~-84 minecraft:lantern
setblock ~-108 ~19 ~-104 minecraft:lantern
setblock ~-82 ~13 ~-108 minecraft:lantern
setblock ~-104 ~3 ~-108 minecraft:lantern[hanging=true]
setblock ~-96 ~29 ~-86 minecraft:lantern
setblock ~-90 ~21 ~-86 minecraft:lantern[hanging=true]
setblock ~-84 ~3 ~-102 minecraft:lantern[hanging=true]
setblock ~-84 ~15 ~-100 minecraft:lantern
setblock ~-90 ~15 ~-104 minecraft:lantern[hanging=true]
setblock ~-88 ~25 ~-90 minecraft:lantern[hanging=true]
setblock ~-82 ~23 ~-110 minecraft:lantern
setblock ~-82 ~11 ~-104 minecraft:lantern
setblock ~-100 ~19 ~-82 minecraft:lantern
setblock ~-94 ~1 ~-98 minecraft:lantern
setblock ~-82 ~21 ~-110 minecraft:lantern[hanging=true]
setblock ~-106 ~13 ~-96 minecraft:lantern[hanging=true]
setblock ~-110 ~9 ~-98 minecraft:lantern
setblock ~-90 ~13 ~-90 minecraft:lantern
setblock ~-90 ~9 ~-82 minecraft:lantern
setblock ~-86 ~29 ~-82 minecraft:lantern[hanging=true]
setblock ~-108 ~15 ~-98 minecraft:lantern[hanging=true]
setblock ~-112 ~21 ~-88 minecraft:lantern
setblock ~-88 ~11 ~-100 minecraft:lantern
setblock ~-92 ~19 ~-104 minecraft:lantern
setblock ~-82 ~11 ~-82 minecraft:lantern
setblock ~-112 ~3 ~-112 minecraft:lantern[hanging=true]
setblock ~-100 ~11 ~-110 minecraft:lantern[hanging=true]
setblock ~-104 ~15 ~-112 minecraft:lantern
setblock ~-110 ~5 ~-82 minecraft:lantern[hanging=true]
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-112 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-80 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-48 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~-16 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~16 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~48 ~192 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~0 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~32 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~64 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~96 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~128 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~160 ~80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~-112
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~-80
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~-48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~-16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~16
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~48
clone ~-112 ~0 ~-112 ~-81 ~31 ~-81 ~80 ~192 ~80
