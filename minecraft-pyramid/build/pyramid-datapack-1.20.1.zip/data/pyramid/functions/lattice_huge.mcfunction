# Решётка 224x224x224. Шаг 1: грузим чанки и ставим маркер.
kill @e[type=marker,tag=lat_huge]
forceload add ~-114 ~-114 ~114 ~114
summon marker ~ ~ ~ {Tags:["lat_huge"]}
tellraw @a {"text":"Готовлю место под куб 224x224x224... (2 сек)","color":"gold"}
schedule function pyramid:lattice_huge_go 40t
