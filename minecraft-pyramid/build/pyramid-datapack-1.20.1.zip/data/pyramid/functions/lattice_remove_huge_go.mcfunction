execute as @e[type=marker,tag=lat_huge_rm,limit=1] at @s run function pyramid:lattice_remove_huge_do
execute as @e[type=marker,tag=lat_huge_rm,limit=1] at @s run forceload remove ~-114 ~-114 ~114 ~114
kill @e[type=marker,tag=lat_huge_rm]
tellraw @a {"text":"Решётка удалена","color":"yellow"}
