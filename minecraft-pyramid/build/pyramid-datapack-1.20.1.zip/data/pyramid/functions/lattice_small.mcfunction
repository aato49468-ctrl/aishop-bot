# Решётка 64x64x64. Шаг 1: грузим чанки и ставим маркер.
kill @e[type=marker,tag=lat_small]
forceload add ~-34 ~-34 ~34 ~34
summon marker ~ ~ ~ {Tags:["lat_small"]}
tellraw @a {"text":"Готовлю место под куб 64x64x64... (2 сек)","color":"gold"}
schedule function pyramid:lattice_small_go 40t
