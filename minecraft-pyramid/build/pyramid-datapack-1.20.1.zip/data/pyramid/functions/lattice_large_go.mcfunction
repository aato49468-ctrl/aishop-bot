execute as @e[type=marker,tag=lat_large,limit=1] at @s run function pyramid:lattice_large_build
execute as @e[type=marker,tag=lat_large,limit=1] at @s run forceload remove ~-98 ~-98 ~98 ~98
kill @e[type=marker,tag=lat_large]
tellraw @a {"text":"Готово! Свет может догружаться несколько секунд.","color":"green"}
