# Пирамида: основание 81x81, высота 41. Центр — там, где стоит игрок.
tellraw @s {"text":"Строю пирамиду...","color":"gold"}
fill ~-40 ~-1 ~-40 ~40 ~-1 ~40 minecraft:black_concrete
fill ~-40 ~0 ~-40 ~40 ~0 ~40 minecraft:glass
fill ~-39 ~0 ~-39 ~39 ~0 ~39 minecraft:air
fill ~-39 ~1 ~-39 ~39 ~1 ~39 minecraft:glass
fill ~-38 ~1 ~-38 ~38 ~1 ~38 minecraft:air
fill ~-38 ~2 ~-38 ~38 ~2 ~38 minecraft:glass
fill ~-37 ~2 ~-37 ~37 ~2 ~37 minecraft:air
fill ~-37 ~3 ~-37 ~37 ~3 ~37 minecraft:glass
fill ~-36 ~3 ~-36 ~36 ~3 ~36 minecraft:air
fill ~-36 ~4 ~-36 ~36 ~4 ~36 minecraft:glass
fill ~-35 ~4 ~-35 ~35 ~4 ~35 minecraft:air
fill ~-35 ~5 ~-35 ~35 ~5 ~35 minecraft:glass
fill ~-34 ~5 ~-34 ~34 ~5 ~34 minecraft:air
fill ~-34 ~6 ~-34 ~34 ~6 ~34 minecraft:glass
fill ~-33 ~6 ~-33 ~33 ~6 ~33 minecraft:air
fill ~-33 ~7 ~-33 ~33 ~7 ~33 minecraft:glass
fill ~-32 ~7 ~-32 ~32 ~7 ~32 minecraft:air
fill ~-32 ~8 ~-32 ~32 ~8 ~32 minecraft:glass
fill ~-31 ~8 ~-31 ~31 ~8 ~31 minecraft:air
fill ~-31 ~9 ~-31 ~31 ~9 ~31 minecraft:glass
fill ~-30 ~9 ~-30 ~30 ~9 ~30 minecraft:air
fill ~-30 ~10 ~-30 ~30 ~10 ~30 minecraft:glass
fill ~-29 ~10 ~-29 ~29 ~10 ~29 minecraft:air
fill ~-29 ~11 ~-29 ~29 ~11 ~29 minecraft:glass
fill ~-28 ~11 ~-28 ~28 ~11 ~28 minecraft:air
fill ~-28 ~12 ~-28 ~28 ~12 ~28 minecraft:glass
fill ~-27 ~12 ~-27 ~27 ~12 ~27 minecraft:air
fill ~-27 ~13 ~-27 ~27 ~13 ~27 minecraft:glass
fill ~-26 ~13 ~-26 ~26 ~13 ~26 minecraft:air
fill ~-26 ~14 ~-26 ~26 ~14 ~26 minecraft:glass
fill ~-25 ~14 ~-25 ~25 ~14 ~25 minecraft:air
fill ~-25 ~15 ~-25 ~25 ~15 ~25 minecraft:glass
fill ~-24 ~15 ~-24 ~24 ~15 ~24 minecraft:air
fill ~-24 ~16 ~-24 ~24 ~16 ~24 minecraft:glass
fill ~-23 ~16 ~-23 ~23 ~16 ~23 minecraft:air
fill ~-23 ~17 ~-23 ~23 ~17 ~23 minecraft:glass
fill ~-22 ~17 ~-22 ~22 ~17 ~22 minecraft:air
fill ~-22 ~18 ~-22 ~22 ~18 ~22 minecraft:glass
fill ~-21 ~18 ~-21 ~21 ~18 ~21 minecraft:air
fill ~-21 ~19 ~-21 ~21 ~19 ~21 minecraft:glass
fill ~-20 ~19 ~-20 ~20 ~19 ~20 minecraft:air
fill ~-20 ~20 ~-20 ~20 ~20 ~20 minecraft:glass
fill ~-19 ~20 ~-19 ~19 ~20 ~19 minecraft:air
fill ~-19 ~21 ~-19 ~19 ~21 ~19 minecraft:glass
fill ~-18 ~21 ~-18 ~18 ~21 ~18 minecraft:air
fill ~-18 ~22 ~-18 ~18 ~22 ~18 minecraft:glass
fill ~-17 ~22 ~-17 ~17 ~22 ~17 minecraft:air
fill ~-17 ~23 ~-17 ~17 ~23 ~17 minecraft:glass
fill ~-16 ~23 ~-16 ~16 ~23 ~16 minecraft:air
fill ~-16 ~24 ~-16 ~16 ~24 ~16 minecraft:glass
fill ~-15 ~24 ~-15 ~15 ~24 ~15 minecraft:air
fill ~-15 ~25 ~-15 ~15 ~25 ~15 minecraft:glass
fill ~-14 ~25 ~-14 ~14 ~25 ~14 minecraft:air
fill ~-14 ~26 ~-14 ~14 ~26 ~14 minecraft:glass
fill ~-13 ~26 ~-13 ~13 ~26 ~13 minecraft:air
fill ~-13 ~27 ~-13 ~13 ~27 ~13 minecraft:glass
fill ~-12 ~27 ~-12 ~12 ~27 ~12 minecraft:air
fill ~-12 ~28 ~-12 ~12 ~28 ~12 minecraft:glass
fill ~-11 ~28 ~-11 ~11 ~28 ~11 minecraft:air
fill ~-11 ~29 ~-11 ~11 ~29 ~11 minecraft:glass
fill ~-10 ~29 ~-10 ~10 ~29 ~10 minecraft:air
fill ~-10 ~30 ~-10 ~10 ~30 ~10 minecraft:glass
fill ~-9 ~30 ~-9 ~9 ~30 ~9 minecraft:air
fill ~-9 ~31 ~-9 ~9 ~31 ~9 minecraft:glass
fill ~-8 ~31 ~-8 ~8 ~31 ~8 minecraft:air
fill ~-8 ~32 ~-8 ~8 ~32 ~8 minecraft:glass
fill ~-7 ~32 ~-7 ~7 ~32 ~7 minecraft:air
fill ~-7 ~33 ~-7 ~7 ~33 ~7 minecraft:glass
fill ~-6 ~33 ~-6 ~6 ~33 ~6 minecraft:air
fill ~-6 ~34 ~-6 ~6 ~34 ~6 minecraft:glass
fill ~-5 ~34 ~-5 ~5 ~34 ~5 minecraft:air
fill ~-5 ~35 ~-5 ~5 ~35 ~5 minecraft:glass
fill ~-4 ~35 ~-4 ~4 ~35 ~4 minecraft:air
fill ~-4 ~36 ~-4 ~4 ~36 ~4 minecraft:glass
fill ~-3 ~36 ~-3 ~3 ~36 ~3 minecraft:air
fill ~-3 ~37 ~-3 ~3 ~37 ~3 minecraft:glass
fill ~-2 ~37 ~-2 ~2 ~37 ~2 minecraft:air
fill ~-2 ~38 ~-2 ~2 ~38 ~2 minecraft:glass
fill ~-1 ~38 ~-1 ~1 ~38 ~1 minecraft:air
fill ~-1 ~39 ~-1 ~1 ~39 ~1 minecraft:glass
fill ~-0 ~39 ~-0 ~0 ~39 ~0 minecraft:air
fill ~-0 ~40 ~-0 ~0 ~40 ~0 minecraft:glass
setblock ~-39 ~0 ~-39 minecraft:lantern
setblock ~-39 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-39 minecraft:lantern
setblock ~39 ~0 ~-39 minecraft:lantern
setblock ~-37 ~0 ~-39 minecraft:lantern
setblock ~-37 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-37 minecraft:lantern
setblock ~39 ~0 ~-37 minecraft:lantern
setblock ~-35 ~0 ~-39 minecraft:lantern
setblock ~-35 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-35 minecraft:lantern
setblock ~39 ~0 ~-35 minecraft:lantern
setblock ~-33 ~0 ~-39 minecraft:lantern
setblock ~-33 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-33 minecraft:lantern
setblock ~39 ~0 ~-33 minecraft:lantern
setblock ~-31 ~0 ~-39 minecraft:lantern
setblock ~-31 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-31 minecraft:lantern
setblock ~39 ~0 ~-31 minecraft:lantern
setblock ~-29 ~0 ~-39 minecraft:lantern
setblock ~-29 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-29 minecraft:lantern
setblock ~39 ~0 ~-29 minecraft:lantern
setblock ~-27 ~0 ~-39 minecraft:lantern
setblock ~-27 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-27 minecraft:lantern
setblock ~39 ~0 ~-27 minecraft:lantern
setblock ~-25 ~0 ~-39 minecraft:lantern
setblock ~-25 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-25 minecraft:lantern
setblock ~39 ~0 ~-25 minecraft:lantern
setblock ~-23 ~0 ~-39 minecraft:lantern
setblock ~-23 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-23 minecraft:lantern
setblock ~39 ~0 ~-23 minecraft:lantern
setblock ~-21 ~0 ~-39 minecraft:lantern
setblock ~-21 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-21 minecraft:lantern
setblock ~39 ~0 ~-21 minecraft:lantern
setblock ~-19 ~0 ~-39 minecraft:lantern
setblock ~-19 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-19 minecraft:lantern
setblock ~39 ~0 ~-19 minecraft:lantern
setblock ~-17 ~0 ~-39 minecraft:lantern
setblock ~-17 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-17 minecraft:lantern
setblock ~39 ~0 ~-17 minecraft:lantern
setblock ~-15 ~0 ~-39 minecraft:lantern
setblock ~-15 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-15 minecraft:lantern
setblock ~39 ~0 ~-15 minecraft:lantern
setblock ~-13 ~0 ~-39 minecraft:lantern
setblock ~-13 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-13 minecraft:lantern
setblock ~39 ~0 ~-13 minecraft:lantern
setblock ~-11 ~0 ~-39 minecraft:lantern
setblock ~-11 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-11 minecraft:lantern
setblock ~39 ~0 ~-11 minecraft:lantern
setblock ~-9 ~0 ~-39 minecraft:lantern
setblock ~-9 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-9 minecraft:lantern
setblock ~39 ~0 ~-9 minecraft:lantern
setblock ~-7 ~0 ~-39 minecraft:lantern
setblock ~-7 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-7 minecraft:lantern
setblock ~39 ~0 ~-7 minecraft:lantern
setblock ~-5 ~0 ~-39 minecraft:lantern
setblock ~-5 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-5 minecraft:lantern
setblock ~39 ~0 ~-5 minecraft:lantern
setblock ~-3 ~0 ~-39 minecraft:lantern
setblock ~-3 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-3 minecraft:lantern
setblock ~39 ~0 ~-3 minecraft:lantern
setblock ~-1 ~0 ~-39 minecraft:lantern
setblock ~-1 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~-1 minecraft:lantern
setblock ~39 ~0 ~-1 minecraft:lantern
setblock ~1 ~0 ~-39 minecraft:lantern
setblock ~1 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~1 minecraft:lantern
setblock ~39 ~0 ~1 minecraft:lantern
setblock ~3 ~0 ~-39 minecraft:lantern
setblock ~3 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~3 minecraft:lantern
setblock ~39 ~0 ~3 minecraft:lantern
setblock ~5 ~0 ~-39 minecraft:lantern
setblock ~5 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~5 minecraft:lantern
setblock ~39 ~0 ~5 minecraft:lantern
setblock ~7 ~0 ~-39 minecraft:lantern
setblock ~7 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~7 minecraft:lantern
setblock ~39 ~0 ~7 minecraft:lantern
setblock ~9 ~0 ~-39 minecraft:lantern
setblock ~9 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~9 minecraft:lantern
setblock ~39 ~0 ~9 minecraft:lantern
setblock ~11 ~0 ~-39 minecraft:lantern
setblock ~11 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~11 minecraft:lantern
setblock ~39 ~0 ~11 minecraft:lantern
setblock ~13 ~0 ~-39 minecraft:lantern
setblock ~13 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~13 minecraft:lantern
setblock ~39 ~0 ~13 minecraft:lantern
setblock ~15 ~0 ~-39 minecraft:lantern
setblock ~15 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~15 minecraft:lantern
setblock ~39 ~0 ~15 minecraft:lantern
setblock ~17 ~0 ~-39 minecraft:lantern
setblock ~17 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~17 minecraft:lantern
setblock ~39 ~0 ~17 minecraft:lantern
setblock ~19 ~0 ~-39 minecraft:lantern
setblock ~19 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~19 minecraft:lantern
setblock ~39 ~0 ~19 minecraft:lantern
setblock ~21 ~0 ~-39 minecraft:lantern
setblock ~21 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~21 minecraft:lantern
setblock ~39 ~0 ~21 minecraft:lantern
setblock ~23 ~0 ~-39 minecraft:lantern
setblock ~23 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~23 minecraft:lantern
setblock ~39 ~0 ~23 minecraft:lantern
setblock ~25 ~0 ~-39 minecraft:lantern
setblock ~25 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~25 minecraft:lantern
setblock ~39 ~0 ~25 minecraft:lantern
setblock ~27 ~0 ~-39 minecraft:lantern
setblock ~27 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~27 minecraft:lantern
setblock ~39 ~0 ~27 minecraft:lantern
setblock ~29 ~0 ~-39 minecraft:lantern
setblock ~29 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~29 minecraft:lantern
setblock ~39 ~0 ~29 minecraft:lantern
setblock ~31 ~0 ~-39 minecraft:lantern
setblock ~31 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~31 minecraft:lantern
setblock ~39 ~0 ~31 minecraft:lantern
setblock ~33 ~0 ~-39 minecraft:lantern
setblock ~33 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~33 minecraft:lantern
setblock ~39 ~0 ~33 minecraft:lantern
setblock ~35 ~0 ~-39 minecraft:lantern
setblock ~35 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~35 minecraft:lantern
setblock ~39 ~0 ~35 minecraft:lantern
setblock ~37 ~0 ~-39 minecraft:lantern
setblock ~37 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~37 minecraft:lantern
setblock ~39 ~0 ~37 minecraft:lantern
setblock ~39 ~0 ~-39 minecraft:lantern
setblock ~39 ~0 ~39 minecraft:lantern
setblock ~-39 ~0 ~39 minecraft:lantern
setblock ~39 ~0 ~39 minecraft:lantern
setblock ~-36 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-36 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-36 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-36 minecraft:lantern[hanging=true]
setblock ~-32 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-32 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-32 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-32 minecraft:lantern[hanging=true]
setblock ~-28 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-28 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-28 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-28 minecraft:lantern[hanging=true]
setblock ~-24 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-24 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-24 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-24 minecraft:lantern[hanging=true]
setblock ~-20 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-20 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-20 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-20 minecraft:lantern[hanging=true]
setblock ~-16 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-16 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-16 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-16 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~-8 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-8 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-8 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~-4 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~-4 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~0 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~0 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~4 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~4 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~8 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~8 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~8 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~16 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~16 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~16 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~16 minecraft:lantern[hanging=true]
setblock ~20 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~20 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~20 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~20 minecraft:lantern[hanging=true]
setblock ~24 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~24 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~24 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~24 minecraft:lantern[hanging=true]
setblock ~28 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~28 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~28 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~28 minecraft:lantern[hanging=true]
setblock ~32 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~32 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~32 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~32 minecraft:lantern[hanging=true]
setblock ~36 ~2 ~-37 minecraft:lantern[hanging=true]
setblock ~36 ~2 ~37 minecraft:lantern[hanging=true]
setblock ~-37 ~2 ~36 minecraft:lantern[hanging=true]
setblock ~37 ~2 ~36 minecraft:lantern[hanging=true]
setblock ~-33 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-33 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-33 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-33 minecraft:lantern[hanging=true]
setblock ~-29 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-29 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-29 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-29 minecraft:lantern[hanging=true]
setblock ~-25 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-25 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-25 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-25 minecraft:lantern[hanging=true]
setblock ~-21 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-21 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-21 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-21 minecraft:lantern[hanging=true]
setblock ~-17 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-17 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-17 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-17 minecraft:lantern[hanging=true]
setblock ~-13 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-13 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-13 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-13 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-5 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-5 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~-1 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~-1 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~3 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~3 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~7 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~7 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~7 minecraft:lantern[hanging=true]
setblock ~11 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~11 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~11 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~11 minecraft:lantern[hanging=true]
setblock ~15 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~15 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~15 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~15 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~19 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~19 minecraft:lantern[hanging=true]
setblock ~23 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~23 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~23 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~23 minecraft:lantern[hanging=true]
setblock ~27 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~27 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~27 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~27 minecraft:lantern[hanging=true]
setblock ~31 ~5 ~-34 minecraft:lantern[hanging=true]
setblock ~31 ~5 ~34 minecraft:lantern[hanging=true]
setblock ~-34 ~5 ~31 minecraft:lantern[hanging=true]
setblock ~34 ~5 ~31 minecraft:lantern[hanging=true]
setblock ~-30 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-30 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-30 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-30 minecraft:lantern[hanging=true]
setblock ~-26 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-26 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-26 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-26 minecraft:lantern[hanging=true]
setblock ~-22 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-22 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-22 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-22 minecraft:lantern[hanging=true]
setblock ~-18 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-18 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-18 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-18 minecraft:lantern[hanging=true]
setblock ~-14 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-14 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-14 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-14 minecraft:lantern[hanging=true]
setblock ~-10 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-10 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-10 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-10 minecraft:lantern[hanging=true]
setblock ~-6 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-6 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-6 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~-2 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~-2 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~2 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~2 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~6 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~6 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~6 minecraft:lantern[hanging=true]
setblock ~10 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~10 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~10 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~10 minecraft:lantern[hanging=true]
setblock ~14 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~14 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~14 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~14 minecraft:lantern[hanging=true]
setblock ~18 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~18 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~18 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~18 minecraft:lantern[hanging=true]
setblock ~22 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~22 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~22 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~22 minecraft:lantern[hanging=true]
setblock ~26 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~26 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~26 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~26 minecraft:lantern[hanging=true]
setblock ~30 ~8 ~-31 minecraft:lantern[hanging=true]
setblock ~30 ~8 ~31 minecraft:lantern[hanging=true]
setblock ~-31 ~8 ~30 minecraft:lantern[hanging=true]
setblock ~31 ~8 ~30 minecraft:lantern[hanging=true]
setblock ~-27 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-27 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-27 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-27 minecraft:lantern[hanging=true]
setblock ~-23 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-23 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-23 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-23 minecraft:lantern[hanging=true]
setblock ~-19 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-19 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-19 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-19 minecraft:lantern[hanging=true]
setblock ~-15 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-15 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-15 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-15 minecraft:lantern[hanging=true]
setblock ~-11 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-11 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-11 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-11 minecraft:lantern[hanging=true]
setblock ~-7 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-7 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-7 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-7 minecraft:lantern[hanging=true]
setblock ~-3 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~-3 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~-3 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~1 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~1 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~1 minecraft:lantern[hanging=true]
setblock ~5 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~5 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~5 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~5 minecraft:lantern[hanging=true]
setblock ~9 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~9 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~9 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~9 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~13 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~13 minecraft:lantern[hanging=true]
setblock ~17 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~17 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~17 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~17 minecraft:lantern[hanging=true]
setblock ~21 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~21 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~21 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~21 minecraft:lantern[hanging=true]
setblock ~25 ~11 ~-28 minecraft:lantern[hanging=true]
setblock ~25 ~11 ~28 minecraft:lantern[hanging=true]
setblock ~-28 ~11 ~25 minecraft:lantern[hanging=true]
setblock ~28 ~11 ~25 minecraft:lantern[hanging=true]
setblock ~-24 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-24 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-24 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-24 minecraft:lantern[hanging=true]
setblock ~-20 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-20 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-20 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-20 minecraft:lantern[hanging=true]
setblock ~-16 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-16 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-16 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-16 minecraft:lantern[hanging=true]
setblock ~-12 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-12 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-12 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-12 minecraft:lantern[hanging=true]
setblock ~-8 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-8 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-8 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~-4 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~-4 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~0 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~0 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~4 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~4 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~8 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~8 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~8 minecraft:lantern[hanging=true]
setblock ~12 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~12 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~12 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~12 minecraft:lantern[hanging=true]
setblock ~16 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~16 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~16 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~16 minecraft:lantern[hanging=true]
setblock ~20 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~20 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~20 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~20 minecraft:lantern[hanging=true]
setblock ~24 ~14 ~-25 minecraft:lantern[hanging=true]
setblock ~24 ~14 ~25 minecraft:lantern[hanging=true]
setblock ~-25 ~14 ~24 minecraft:lantern[hanging=true]
setblock ~25 ~14 ~24 minecraft:lantern[hanging=true]
setblock ~-21 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-21 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-21 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-21 minecraft:lantern[hanging=true]
setblock ~-17 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-17 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-17 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-17 minecraft:lantern[hanging=true]
setblock ~-13 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-13 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-13 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-13 minecraft:lantern[hanging=true]
setblock ~-9 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-9 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-9 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-5 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-5 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~-1 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~-1 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~3 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~3 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~7 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~7 minecraft:lantern[hanging=true]
setblock ~11 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~11 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~11 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~11 minecraft:lantern[hanging=true]
setblock ~15 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~15 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~15 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~15 minecraft:lantern[hanging=true]
setblock ~19 ~17 ~-22 minecraft:lantern[hanging=true]
setblock ~19 ~17 ~22 minecraft:lantern[hanging=true]
setblock ~-22 ~17 ~19 minecraft:lantern[hanging=true]
setblock ~22 ~17 ~19 minecraft:lantern[hanging=true]
setblock ~-18 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~-18 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~-18 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~-18 minecraft:lantern[hanging=true]
setblock ~-14 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~-14 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~-14 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~-14 minecraft:lantern[hanging=true]
setblock ~-10 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~-10 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~-10 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~-10 minecraft:lantern[hanging=true]
setblock ~-6 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~-6 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~-6 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~-2 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~-2 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~2 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~2 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~6 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~6 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~6 minecraft:lantern[hanging=true]
setblock ~10 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~10 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~10 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~10 minecraft:lantern[hanging=true]
setblock ~14 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~14 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~14 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~14 minecraft:lantern[hanging=true]
setblock ~18 ~20 ~-19 minecraft:lantern[hanging=true]
setblock ~18 ~20 ~19 minecraft:lantern[hanging=true]
setblock ~-19 ~20 ~18 minecraft:lantern[hanging=true]
setblock ~19 ~20 ~18 minecraft:lantern[hanging=true]
setblock ~-15 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~-15 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~-15 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~-15 minecraft:lantern[hanging=true]
setblock ~-11 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~-11 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~-11 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~-11 minecraft:lantern[hanging=true]
setblock ~-7 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~-7 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~-7 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~-7 minecraft:lantern[hanging=true]
setblock ~-3 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~-3 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~-3 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~1 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~1 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~1 minecraft:lantern[hanging=true]
setblock ~5 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~5 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~5 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~5 minecraft:lantern[hanging=true]
setblock ~9 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~9 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~9 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~9 minecraft:lantern[hanging=true]
setblock ~13 ~23 ~-16 minecraft:lantern[hanging=true]
setblock ~13 ~23 ~16 minecraft:lantern[hanging=true]
setblock ~-16 ~23 ~13 minecraft:lantern[hanging=true]
setblock ~16 ~23 ~13 minecraft:lantern[hanging=true]
setblock ~-12 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~-12 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~-12 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~-12 minecraft:lantern[hanging=true]
setblock ~-8 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~-8 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~-8 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~-4 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~-4 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~0 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~0 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~4 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~4 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~8 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~8 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~8 minecraft:lantern[hanging=true]
setblock ~12 ~26 ~-13 minecraft:lantern[hanging=true]
setblock ~12 ~26 ~13 minecraft:lantern[hanging=true]
setblock ~-13 ~26 ~12 minecraft:lantern[hanging=true]
setblock ~13 ~26 ~12 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~-10 minecraft:lantern[hanging=true]
setblock ~-9 ~29 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~10 ~29 ~-9 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~-10 minecraft:lantern[hanging=true]
setblock ~-5 ~29 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~10 ~29 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~-10 minecraft:lantern[hanging=true]
setblock ~-1 ~29 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~10 ~29 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~-10 minecraft:lantern[hanging=true]
setblock ~3 ~29 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~10 ~29 ~3 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~-10 minecraft:lantern[hanging=true]
setblock ~7 ~29 ~10 minecraft:lantern[hanging=true]
setblock ~-10 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~10 ~29 ~7 minecraft:lantern[hanging=true]
setblock ~-6 ~32 ~-7 minecraft:lantern[hanging=true]
setblock ~-6 ~32 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~32 ~-6 minecraft:lantern[hanging=true]
setblock ~7 ~32 ~-6 minecraft:lantern[hanging=true]
setblock ~-2 ~32 ~-7 minecraft:lantern[hanging=true]
setblock ~-2 ~32 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~32 ~-2 minecraft:lantern[hanging=true]
setblock ~7 ~32 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~32 ~-7 minecraft:lantern[hanging=true]
setblock ~2 ~32 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~32 ~2 minecraft:lantern[hanging=true]
setblock ~7 ~32 ~2 minecraft:lantern[hanging=true]
setblock ~6 ~32 ~-7 minecraft:lantern[hanging=true]
setblock ~6 ~32 ~7 minecraft:lantern[hanging=true]
setblock ~-7 ~32 ~6 minecraft:lantern[hanging=true]
setblock ~7 ~32 ~6 minecraft:lantern[hanging=true]
setblock ~-3 ~35 ~-4 minecraft:lantern[hanging=true]
setblock ~-3 ~35 ~4 minecraft:lantern[hanging=true]
setblock ~-4 ~35 ~-3 minecraft:lantern[hanging=true]
setblock ~4 ~35 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~35 ~-4 minecraft:lantern[hanging=true]
setblock ~1 ~35 ~4 minecraft:lantern[hanging=true]
setblock ~-4 ~35 ~1 minecraft:lantern[hanging=true]
setblock ~4 ~35 ~1 minecraft:lantern[hanging=true]
setblock ~0 ~39 ~0 minecraft:chain
setblock ~0 ~38 ~0 minecraft:chain
setblock ~0 ~37 ~0 minecraft:chain
setblock ~0 ~36 ~0 minecraft:chain
setblock ~0 ~35 ~0 minecraft:chain
setblock ~0 ~34 ~0 minecraft:chain
setblock ~0 ~33 ~0 minecraft:chain
setblock ~0 ~32 ~0 minecraft:chain
setblock ~0 ~31 ~0 minecraft:chain
setblock ~0 ~30 ~0 minecraft:chain
setblock ~0 ~29 ~0 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
