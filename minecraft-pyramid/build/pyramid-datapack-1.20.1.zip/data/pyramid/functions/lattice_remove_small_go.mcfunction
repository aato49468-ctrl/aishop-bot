execute as @e[type=marker,tag=lat_small_rm,limit=1] at @s run function pyramid:lattice_remove_small_do
execute as @e[type=marker,tag=lat_small_rm,limit=1] at @s run forceload remove ~-34 ~-34 ~34 ~34
kill @e[type=marker,tag=lat_small_rm]
tellraw @a {"text":"Решётка удалена","color":"yellow"}
