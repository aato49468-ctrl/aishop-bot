execute as @e[type=marker,tag=lat_huge,limit=1] at @s run function pyramid:lattice_huge_build
execute as @e[type=marker,tag=lat_huge,limit=1] at @s run forceload remove ~-114 ~-114 ~114 ~114
kill @e[type=marker,tag=lat_huge]
tellraw @a {"text":"Готово! Свет может догружаться несколько секунд.","color":"green"}
