# Пирамида: основание 31x31, высота 16. Центр — там, где стоит игрок.
tellraw @s {"text":"Строю пирамиду...","color":"gold"}
fill ~-15 ~-1 ~-15 ~15 ~-1 ~15 minecraft:black_concrete
fill ~-15 ~0 ~-15 ~15 ~0 ~15 minecraft:glass
fill ~-14 ~0 ~-14 ~14 ~0 ~14 minecraft:air
fill ~-14 ~1 ~-14 ~14 ~1 ~14 minecraft:glass
fill ~-13 ~1 ~-13 ~13 ~1 ~13 minecraft:air
fill ~-13 ~2 ~-13 ~13 ~2 ~13 minecraft:glass
fill ~-12 ~2 ~-12 ~12 ~2 ~12 minecraft:air
fill ~-12 ~3 ~-12 ~12 ~3 ~12 minecraft:glass
fill ~-11 ~3 ~-11 ~11 ~3 ~11 minecraft:air
fill ~-11 ~4 ~-11 ~11 ~4 ~11 minecraft:glass
fill ~-10 ~4 ~-10 ~10 ~4 ~10 minecraft:air
fill ~-10 ~5 ~-10 ~10 ~5 ~10 minecraft:glass
fill ~-9 ~5 ~-9 ~9 ~5 ~9 minecraft:air
fill ~-9 ~6 ~-9 ~9 ~6 ~9 minecraft:glass
fill ~-8 ~6 ~-8 ~8 ~6 ~8 minecraft:air
fill ~-8 ~7 ~-8 ~8 ~7 ~8 minecraft:glass
fill ~-7 ~7 ~-7 ~7 ~7 ~7 minecraft:air
fill ~-7 ~8 ~-7 ~7 ~8 ~7 minecraft:glass
fill ~-6 ~8 ~-6 ~6 ~8 ~6 minecraft:air
fill ~-6 ~9 ~-6 ~6 ~9 ~6 minecraft:glass
fill ~-5 ~9 ~-5 ~5 ~9 ~5 minecraft:air
fill ~-5 ~10 ~-5 ~5 ~10 ~5 minecraft:glass
fill ~-4 ~10 ~-4 ~4 ~10 ~4 minecraft:air
fill ~-4 ~11 ~-4 ~4 ~11 ~4 minecraft:glass
fill ~-3 ~11 ~-3 ~3 ~11 ~3 minecraft:air
fill ~-3 ~12 ~-3 ~3 ~12 ~3 minecraft:glass
fill ~-2 ~12 ~-2 ~2 ~12 ~2 minecraft:air
fill ~-2 ~13 ~-2 ~2 ~13 ~2 minecraft:glass
fill ~-1 ~13 ~-1 ~1 ~13 ~1 minecraft:air
fill ~-1 ~14 ~-1 ~1 ~14 ~1 minecraft:glass
fill ~-0 ~14 ~-0 ~0 ~14 ~0 minecraft:air
fill ~-0 ~15 ~-0 ~0 ~15 ~0 minecraft:glass
setblock ~-14 ~0 ~-14 minecraft:lantern
setblock ~-14 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-14 minecraft:lantern
setblock ~14 ~0 ~-14 minecraft:lantern
setblock ~-12 ~0 ~-14 minecraft:lantern
setblock ~-12 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-12 minecraft:lantern
setblock ~14 ~0 ~-12 minecraft:lantern
setblock ~-10 ~0 ~-14 minecraft:lantern
setblock ~-10 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-10 minecraft:lantern
setblock ~14 ~0 ~-10 minecraft:lantern
setblock ~-8 ~0 ~-14 minecraft:lantern
setblock ~-8 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-8 minecraft:lantern
setblock ~14 ~0 ~-8 minecraft:lantern
setblock ~-6 ~0 ~-14 minecraft:lantern
setblock ~-6 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-6 minecraft:lantern
setblock ~14 ~0 ~-6 minecraft:lantern
setblock ~-4 ~0 ~-14 minecraft:lantern
setblock ~-4 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-4 minecraft:lantern
setblock ~14 ~0 ~-4 minecraft:lantern
setblock ~-2 ~0 ~-14 minecraft:lantern
setblock ~-2 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~-2 minecraft:lantern
setblock ~14 ~0 ~-2 minecraft:lantern
setblock ~0 ~0 ~-14 minecraft:lantern
setblock ~0 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~0 minecraft:lantern
setblock ~14 ~0 ~0 minecraft:lantern
setblock ~2 ~0 ~-14 minecraft:lantern
setblock ~2 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~2 minecraft:lantern
setblock ~14 ~0 ~2 minecraft:lantern
setblock ~4 ~0 ~-14 minecraft:lantern
setblock ~4 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~4 minecraft:lantern
setblock ~14 ~0 ~4 minecraft:lantern
setblock ~6 ~0 ~-14 minecraft:lantern
setblock ~6 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~6 minecraft:lantern
setblock ~14 ~0 ~6 minecraft:lantern
setblock ~8 ~0 ~-14 minecraft:lantern
setblock ~8 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~8 minecraft:lantern
setblock ~14 ~0 ~8 minecraft:lantern
setblock ~10 ~0 ~-14 minecraft:lantern
setblock ~10 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~10 minecraft:lantern
setblock ~14 ~0 ~10 minecraft:lantern
setblock ~12 ~0 ~-14 minecraft:lantern
setblock ~12 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~12 minecraft:lantern
setblock ~14 ~0 ~12 minecraft:lantern
setblock ~14 ~0 ~-14 minecraft:lantern
setblock ~14 ~0 ~14 minecraft:lantern
setblock ~-14 ~0 ~14 minecraft:lantern
setblock ~14 ~0 ~14 minecraft:lantern
setblock ~-11 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~-11 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~-11 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~-11 minecraft:lantern[hanging=true]
setblock ~-7 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~-7 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~-7 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~-7 minecraft:lantern[hanging=true]
setblock ~-3 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~-3 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~-3 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~-3 minecraft:lantern[hanging=true]
setblock ~1 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~1 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~1 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~1 minecraft:lantern[hanging=true]
setblock ~5 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~5 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~5 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~5 minecraft:lantern[hanging=true]
setblock ~9 ~2 ~-12 minecraft:lantern[hanging=true]
setblock ~9 ~2 ~12 minecraft:lantern[hanging=true]
setblock ~-12 ~2 ~9 minecraft:lantern[hanging=true]
setblock ~12 ~2 ~9 minecraft:lantern[hanging=true]
setblock ~-8 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~-8 ~5 ~9 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~-8 minecraft:lantern[hanging=true]
setblock ~9 ~5 ~-8 minecraft:lantern[hanging=true]
setblock ~-4 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~-4 ~5 ~9 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~-4 minecraft:lantern[hanging=true]
setblock ~9 ~5 ~-4 minecraft:lantern[hanging=true]
setblock ~0 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~0 ~5 ~9 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~0 minecraft:lantern[hanging=true]
setblock ~9 ~5 ~0 minecraft:lantern[hanging=true]
setblock ~4 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~4 ~5 ~9 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~4 minecraft:lantern[hanging=true]
setblock ~9 ~5 ~4 minecraft:lantern[hanging=true]
setblock ~8 ~5 ~-9 minecraft:lantern[hanging=true]
setblock ~8 ~5 ~9 minecraft:lantern[hanging=true]
setblock ~-9 ~5 ~8 minecraft:lantern[hanging=true]
setblock ~9 ~5 ~8 minecraft:lantern[hanging=true]
setblock ~-5 ~8 ~-6 minecraft:lantern[hanging=true]
setblock ~-5 ~8 ~6 minecraft:lantern[hanging=true]
setblock ~-6 ~8 ~-5 minecraft:lantern[hanging=true]
setblock ~6 ~8 ~-5 minecraft:lantern[hanging=true]
setblock ~-1 ~8 ~-6 minecraft:lantern[hanging=true]
setblock ~-1 ~8 ~6 minecraft:lantern[hanging=true]
setblock ~-6 ~8 ~-1 minecraft:lantern[hanging=true]
setblock ~6 ~8 ~-1 minecraft:lantern[hanging=true]
setblock ~3 ~8 ~-6 minecraft:lantern[hanging=true]
setblock ~3 ~8 ~6 minecraft:lantern[hanging=true]
setblock ~-6 ~8 ~3 minecraft:lantern[hanging=true]
setblock ~6 ~8 ~3 minecraft:lantern[hanging=true]
setblock ~-2 ~11 ~-3 minecraft:lantern[hanging=true]
setblock ~-2 ~11 ~3 minecraft:lantern[hanging=true]
setblock ~-3 ~11 ~-2 minecraft:lantern[hanging=true]
setblock ~3 ~11 ~-2 minecraft:lantern[hanging=true]
setblock ~2 ~11 ~-3 minecraft:lantern[hanging=true]
setblock ~2 ~11 ~3 minecraft:lantern[hanging=true]
setblock ~-3 ~11 ~2 minecraft:lantern[hanging=true]
setblock ~3 ~11 ~2 minecraft:lantern[hanging=true]
setblock ~0 ~14 ~0 minecraft:chain
setblock ~0 ~13 ~0 minecraft:chain
setblock ~0 ~12 ~0 minecraft:chain
setblock ~0 ~11 ~0 minecraft:lantern[hanging=true]
tellraw @s {"text":"Готово!","color":"green"}
