# Удаление решётки 224x224x224. Встаньте туда же, где строили.
kill @e[type=marker,tag=lat_huge_rm]
forceload add ~-114 ~-114 ~114 ~114
summon marker ~ ~ ~ {Tags:["lat_huge_rm"]}
schedule function pyramid:lattice_remove_huge_go 40t
