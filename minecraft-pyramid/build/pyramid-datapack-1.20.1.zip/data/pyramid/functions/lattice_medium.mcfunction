# Решётка 128x128x128. Шаг 1: грузим чанки и ставим маркер.
kill @e[type=marker,tag=lat_medium]
forceload add ~-66 ~-66 ~66 ~66
summon marker ~ ~ ~ {Tags:["lat_medium"]}
tellraw @a {"text":"Готовлю место под куб 128x128x128... (2 сек)","color":"gold"}
schedule function pyramid:lattice_medium_go 40t
