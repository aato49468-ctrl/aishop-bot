# Решётка 192x192x192. Шаг 1: грузим чанки и ставим маркер.
kill @e[type=marker,tag=lat_large]
forceload add ~-98 ~-98 ~98 ~98
summon marker ~ ~ ~ {Tags:["lat_large"]}
tellraw @a {"text":"Готовлю место под куб 192x192x192... (2 сек)","color":"gold"}
schedule function pyramid:lattice_large_go 40t
