# Удаляет пирамиду размера R=25 вокруг игрока (стоять там же, где строили)
fill ~-25 ~0 ~-25 ~25 ~25 ~25 minecraft:air
fill ~-25 ~-1 ~-25 ~25 ~-1 ~25 minecraft:grass_block
tellraw @s {"text":"Пирамида удалена","color":"yellow"}
