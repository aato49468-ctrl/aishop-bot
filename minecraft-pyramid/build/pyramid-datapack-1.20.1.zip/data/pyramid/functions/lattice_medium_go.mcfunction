execute as @e[type=marker,tag=lat_medium,limit=1] at @s run function pyramid:lattice_medium_build
execute as @e[type=marker,tag=lat_medium,limit=1] at @s run forceload remove ~-66 ~-66 ~66 ~66
kill @e[type=marker,tag=lat_medium]
tellraw @a {"text":"Готово! Свет может догружаться несколько секунд.","color":"green"}
