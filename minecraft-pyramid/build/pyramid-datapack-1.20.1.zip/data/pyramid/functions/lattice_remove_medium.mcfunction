# Удаление решётки 128x128x128. Встаньте туда же, где строили.
kill @e[type=marker,tag=lat_medium_rm]
forceload add ~-66 ~-66 ~66 ~66
summon marker ~ ~ ~ {Tags:["lat_medium_rm"]}
schedule function pyramid:lattice_remove_medium_go 40t
